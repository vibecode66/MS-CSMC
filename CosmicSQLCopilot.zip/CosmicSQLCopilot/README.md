# SQL Copilot — Natural Language Database Query for M365 Copilot & Teams

A Microsoft 365 Copilot declarative agent and Teams bot that lets users query Azure SQL databases using natural language and receive rich Adaptive Card results — including charts, KPI cards, and data tables — directly in Microsoft Teams and M365 Copilot.

## ✨ Features

| Feature | Description |
|---------|-------------|
| **Natural Language to SQL** | Ask questions in plain English; Azure OpenAI converts them to T-SQL |
| **Self-Healing SQL** | If a generated query fails, the error is automatically fed back to the LLM for correction (up to 3 retries) |
| **Rich Visualizations** | Bar, pie, line, doughnut, and horizontal bar charts via QuickChart.io |
| **KPI Cards** | Bold big-number display for aggregation results (COUNT, SUM, AVG) with smart formatting |
| **Smart Formatting** | Currency ($1.2M), percentages (45.2%), large numbers (1.2M), human-readable column labels |
| **Read-Only Safety** | Triple-layer protection: LLM prompt rules + code validation + read-uncommitted transactions |
| **Managed Identity** | Passwordless Azure SQL authentication via DefaultAzureCredential |
| **Passwordless Bot** | UserAssignedMSI bot type — no MicrosoftAppPassword required |
| **Schema Caching** | Database schema cached in memory with configurable TTL and /refresh command |
| **Message Size Protection** | Auto-trims results to stay under Teams' 28KB limit with summary fallback |
| **Swagger UI** | Interactive API documentation at /swagger |
| **Structured Logging** | ILogger-based logging with structured parameters throughout all services |
| **Conversation Trace Logging** | Per-turn NDJSON interaction traces written locally, with optional upload to Azure Blob Storage |
| **Custom Exceptions** | Strongly-typed exception hierarchy for precise error handling |
| **Sample Data Context** | Fetches 3 sample rows per table so the LLM understands actual data values |

## Architecture

`
┌─────────────────────┐    ┌──────────────────────────────────────────────┐
│  M365 Copilot /     │    │             SqlCopilot.Web                   │
│  Microsoft Teams    │◄──►│  ┌──────────────┐  ┌─────────────────────┐  │
│                     │    │  │ BotController │  │ QueryController     │  │
│  (Adaptive Cards)   │    │  │ /api/messages │  │ /api/query (plugin) │  │
└─────────────────────┘    │  └──────┬───────┘  └──────────┬──────────┘  │
                           │         │                     │             │
                           │  ┌──────▼─────────────────────▼──────────┐  │
                           │  │          SqlCopilotBot                │  │
                           │  │    (TeamsActivityHandler)             │  │
                           │  └──────────────┬────────────────────────┘  │
                           └─────────────────┼───────────────────────────┘
                                             │
                           ┌─────────────────▼───────────────────────────┐
                           │           SqlCopilot.Core                   │
                           │                                             │
                           │  ┌──────────────────┐  ┌────────────────┐  │
                           │  │SchemaDiscovery    │  │SqlGenerator    │  │
                           │  │Service            │  │Service         │  │
                           │  │(INFORMATION_SCHEMA│  │(Azure OpenAI + │  │
                           │  │ + sample data)    │  │ self-healing)  │  │
                           │  └────────┬─────────┘  └───────┬────────┘  │
                           │           │                     │           │
                           │  ┌────────▼─────────┐  ┌───────▼────────┐  │
                           │  │QueryExecution     │  │AdaptiveCard    │  │
                           │  │Service            │  │Service         │  │
                           │  │(Read-only SQL     │  │(Table, KPI,    │  │
                           │  │ + row limits)     │  │ Chart, K/V)    │  │
                           │  └──────────────────┘  └───────┬────────┘  │
                           │                                │           │
                           │  ┌─────────────────┐  ┌───────▼────────┐  │
                           │  │SqlConnection     │  │ChartService    │  │
                           │  │Factory           │  │(QuickChart.io) │  │
                           │  │(Managed Identity)│  │                │  │
                           │  └──────────────────┘  └────────────────┘  │
                           │                                             │
                           │  ┌──────────────────────────────────────┐  │
                           │  │ Exceptions/SqlCopilotException.cs    │  │
                           │  │ (Custom exception hierarchy)         │  │
                           │  └──────────────────────────────────────┘  │
                           └─────────────────────────────────────────────┘
                                    │                     │
                           ┌────────▼──────┐    ┌────────▼──────┐
                           │  Azure SQL    │    │ Azure OpenAI  │
                           │  Database     │    │ (GPT-4.1)     │
                           │  (via MI)     │    │ (via API key) │
                           └───────────────┘    └───────────────┘
`

## Request Flow

1. **User** types a natural language question in Teams or M365 Copilot
2. **Bot** receives the message and fetches the cached database schema (tables, columns, PKs, FKs, sample data)
3. **SqlGeneratorService** sends the schema + question to Azure OpenAI, which returns:
   - A T-SQL SELECT query
   - An explanation of what the query does
   - A suggested chart type (bar, pie, line, table, etc.)
4. **Self-Healing Loop**: the query is executed; if it fails, the error is fed back to the LLM for correction (up to 3 retries)
5. **AdaptiveCardService** selects the best card type based on result shape:
   - **KPI card** — single-value or few-metric aggregations (big bold numbers)
   - **Chart card** — bar/pie/line/doughnut chart image + toggleable data table
   - **Table card** — multi-row, multi-column data grid
   - **Key-Value card** — two-column fact-set
   - **Single-Record card** — detail view for one row
   - **Summary card** — fallback when results exceed the 25KB size limit
6. **Bot** sends the Adaptive Card back to the user

## Card Types

### KPI Card (aggregations)
> *"How many cases were created this month?"*

Displays a large accent-colored number centered on the card with the metric label below.
Multi-metric queries show values side by side in columns.

### Chart Card (visualizations)
> *"Show cases by status"* → 🥧 Pie Chart
> *"Monthly case trend"* → 📈 Line Chart
> *"Top 10 programs by case count"* → 📊 Bar Chart

Chart images rendered via QuickChart.io with toggleable data table and SQL.

### Table Card (data grids)
> *"List the latest 10 cases"*

Column headers with data rows, metadata footer, and expandable SQL query.

## Prerequisites

- [.NET 8.0 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- [Visual Studio 2022](https://visualstudio.microsoft.com/) (17.8+)
- [Azure Subscription](https://azure.microsoft.com/free/)
- [Azure SQL Database](https://learn.microsoft.com/azure/azure-sql/)
- [Azure OpenAI Service](https://learn.microsoft.com/azure/ai-services/openai/) with a GPT-4 series deployment
- [Azure Bot registration](https://learn.microsoft.com/azure/bot-service/bot-service-quickstart-registration) (UserAssignedMSI type recommended)

## Setup

### 1. Clone and Open

`ash
git clone <this-repo>
cd SqlCopilot
start SqlCopilot.sln   # Opens in Visual Studio 2022
`

### 2. Azure SQL Database

Ensure your database is provisioned. For **Managed Identity** access (recommended):

`sql
-- Run on the target Azure SQL Database
-- Replace <identity-name> with your App Service or User-Assigned MI name
CREATE USER [<identity-name>] FROM EXTERNAL PROVIDER;
ALTER ROLE db_datareader ADD MEMBER [<identity-name>];
`

For traditional SQL auth (not recommended for production):
`sql
CREATE USER [sqlcopilot_reader] WITH PASSWORD = 'YourSecurePassword!';
ALTER ROLE db_datareader ADD MEMBER [sqlcopilot_reader];
`

### 3. Azure OpenAI

1. Create an Azure OpenAI resource in the Azure Portal
2. Deploy a **GPT-4.1** (or GPT-4o) model
3. Note the **Endpoint**, **API Key**, and **Deployment Name**

### 4. Bot Registration (Passwordless)

1. Go to [Azure Portal](https://portal.azure.com) → Create a resource → **Azure Bot**
2. Choose **User-Assigned Managed Identity** as the bot type
3. Link to your User-Assigned Managed Identity
4. Set the messaging endpoint to: https://<your-app-service>.azurewebsites.net/api/messages
5. Enable the **Microsoft Teams** channel

> **Note:** No MicrosoftAppPassword is needed with UserAssignedMSI. Your organization's security policy is respected.

### 5. Configuration

Edit src/SqlCopilot.Web/appsettings.json:

`json
{
  "MicrosoftAppType": "UserAssignedMSI",
  "MicrosoftAppId": "<YOUR_BOT_APP_ID>",
  "MicrosoftAppTenantId": "<YOUR_TENANT_ID>",

  "AzureSql": {
    "ConnectionString": "Server=tcp:<server>.database.windows.net,1433;Initial Catalog=<database>;Encrypt=True;TrustServerCertificate=False;",
    "UseManagedIdentity": true,
    "ManagedIdentityClientId": "<USER_ASSIGNED_MI_CLIENT_ID>",
    "QueryTimeoutSeconds": 30,
    "MaxRowsReturned": 100,
    "SchemaCacheMinutes": 60
  },

  "AzureOpenAI": {
    "Endpoint": "https://<resource>.openai.azure.com/",
    "ApiKey": "<your-api-key>",
    "DeploymentName": "gpt-4.1",
    "Temperature": 0.0,
    "MaxTokens": 2048
  },

  "ConversationTrace": {
    "Enabled": true,
    "LocalDirectory": "sqlcopilot-traces",
    "KeepLastFiles": 5,
    "IncludeDbPreview": true,
    "Blob": {
      "Enabled": true,
      "StorageAccount": "<storage-account-name>",
      "Container": "sqlcopilot-traces",
      "Prefix": "sqlcopilotweb/",
      "ConnectionString": "",
      "ManagedIdentityClientId": "<optional-user-assigned-mi-client-id>"
    }
  }
}
`

> **⚠️ Security:** Never commit API keys or passwords. Use Azure Key Vault, App Service Configuration, or environment variables in production.

### 6. Run Locally

`ash
cd src/SqlCopilot.Web
dotnet run
`

The bot listens on https://localhost:5001:
- /api/messages — Bot Framework endpoint
- /api/query — REST API for M365 Copilot plugin
- /swagger — Swagger UI
- / — Health check

Use [Bot Framework Emulator](https://github.com/Microsoft/BotFramework-Emulator) or [Dev Tunnel](https://learn.microsoft.com/azure/developer/dev-tunnels/) + Teams for local testing.

### 7. Deploy to Azure App Service

`ash
# Build and publish
dotnet publish src/SqlCopilot.Web -c Release -o ./publish

# Deploy to Azure App Service
az webapp deploy --resource-group <rg> --name <app-name> --src-path ./publish
`

After deployment:
1. Configure all appsettings values in **App Service → Configuration → Application settings**
2. Assign the User-Assigned Managed Identity to the App Service
3. Grant the MI db_datareader access on your Azure SQL Database

### 8. Install in Teams / M365 Copilot

1. Update ppPackage/manifest.json:
   - Set id and ots[0].botId to your Bot's Microsoft App ID
   - Set alidDomains to your App Service domain (e.g., myapp.azurewebsites.net)
2. Ensure icon files exist: color.png (192×192) and outline.png (32×32)
3. Zip the ppPackage folder contents (manifest.json, icons, declarativeAgent.json, ai-plugin.json, apiSpecificationFile/)
4. Upload via [Teams Admin Center](https://admin.teams.microsoft.com) → **Manage apps** → **Upload new app**
5. For M365 Copilot: the declarative agent is automatically available once the Teams app is installed and approved

## Bot Commands

| Command | Description |
|---------|-------------|
| Any natural language question | Generates SQL, executes, and returns results |
| help or /help | Shows welcome card with example questions |
| /refresh | Forces a refresh of the cached database schema |

## Security

| Layer | Protection |
|-------|-----------|
| **LLM Prompt** | System prompt explicitly forbids INSERT/UPDATE/DELETE/DROP and all DML/DDL |
| **Code Validation** | ValidateReadOnly() scans for 20+ dangerous keywords before execution |
| **Transaction** | Queries run in READ UNCOMMITTED transactions — no write locks possible |
| **Query Timeout** | Configurable execution timeout prevents runaway queries (default: 30s) |
| **Row Limits** | Results capped at configurable maximum (default: 100 rows) |
| **Message Size** | Cards auto-trimmed to 25KB with summary fallback for Teams' 28KB limit |
| **Managed Identity** | No passwords stored for SQL access — uses Azure AD tokens |
| **Passwordless Bot** | UserAssignedMSI bot type — no MicrosoftAppPassword needed |
| **Schema Caching** | Reduces database introspection calls (default: 60 min TTL) |

## Exception Handling

The solution uses a custom exception hierarchy (SqlCopilot.Core/Exceptions/):

`
SqlCopilotException (base)
  ├── SchemaDiscoveryException   — failed to read database schema
  ├── SqlGenerationException     — Azure OpenAI failed to produce valid SQL
  ├── QueryExecutionException    — SQL query execution failed
  ├── ConnectionFactoryException — could not establish Azure SQL connection
  └── CardRenderingException     — Adaptive Card construction failed
`

Each exception carries domain-specific context (database name, SQL query, MI status, etc.) for easier troubleshooting.

## Logging

All services use ILogger<T> with structured logging:

| Level | Usage |
|-------|-------|
| Debug | Internal details (token expiry, column lists, card sizes) |
| Information | Operation lifecycle (schema discovered, query executed, card rendered) |
| Warning | Recoverable issues (self-healing retries, chart fallbacks, size trimming) |
| Error | Failures (SQL errors, OpenAI errors, connection failures) |
| Critical | Last-resort errors (error card failed, adapter crash) |

All log entries use structured parameters (e.g., {TableCount}, {ElapsedMs}, {ErrorNumber}) for filtering in Azure Monitor / Application Insights.

## Interaction Trace Logging (NDJSON + Blob)

In addition to runtime ILogger logs, the app supports conversation-level tracing through `IConversationTraceSink`.

- Every turn can be captured as a local NDJSON file (receive, intermediate steps, final response)
- Local trace retention is controlled by `ConversationTrace:KeepLastFiles`
- When `ConversationTrace:Blob:Enabled=true`, each completed turn is also uploaded to Azure Blob Storage
- Blob upload supports either `ConnectionString` (local/dev) or Managed Identity
- If `ConversationTrace:Blob:StorageAccount` or `Container` is omitted, upload falls back to `CasePrediction` storage settings

### Trace configuration keys

| Key | Description |
|-----|-------------|
| `ConversationTrace:Enabled` | Master on/off switch for interaction tracing |
| `ConversationTrace:LocalDirectory` | Local folder for per-turn NDJSON files |
| `ConversationTrace:KeepLastFiles` | Number of local trace files to retain |
| `ConversationTrace:IncludeDbPreview` | Includes small DB result preview in trace events |
| `ConversationTrace:Blob:Enabled` | Enables blob upload at end of each turn |
| `ConversationTrace:Blob:StorageAccount` | Target storage account (optional if CasePrediction settings exist) |
| `ConversationTrace:Blob:Container` | Target container (optional if CasePrediction settings exist) |
| `ConversationTrace:Blob:Prefix` | Blob path prefix (for logical grouping) |
| `ConversationTrace:Blob:ConnectionString` | Optional connection-string auth |
| `ConversationTrace:Blob:ManagedIdentityClientId` | Optional user-assigned MI client ID for blob auth |

## Project Structure

`
SqlCopilot/
├── SqlCopilot.sln
├── README.md
├── src/
│   ├── SqlCopilot.Core/                    # Business logic (no web dependencies)
│   │   ├── Exceptions/
│   │   │   └── SqlCopilotException.cs      # Custom exception hierarchy
│   │   ├── Interfaces/
│   │   │   ├── ISchemaDiscoveryService.cs  # Schema discovery contract
│   │   │   ├── ISqlGeneratorService.cs     # NL→SQL conversion contract
│   │   │   ├── IQueryExecutionService.cs   # Query execution contract
│   │   │   ├── IAdaptiveCardService.cs     # Card rendering contract
│   │   │   ├── IChartService.cs            # Chart generation contract
│   │   │   └── ISqlConnectionFactory.cs    # Connection factory contract
│   │   ├── Models/
│   │   │   ├── AppOptions.cs               # AzureSqlOptions, AzureOpenAIOptions
│   │   │   ├── NL2SqlRequest.cs            # Request/response + ChartType enum
│   │   │   ├── QueryResult.cs              # Result model + QueryResultType enum
│   │   │   └── TableSchema.cs              # Schema models + ToSchemaPrompt()
│   │   └── Services/
│   │       ├── SqlConnectionFactory.cs     # MI/SQL auth connection creation
│   │       ├── SchemaDiscoveryService.cs   # INFORMATION_SCHEMA + sample data
│   │       ├── SqlGeneratorService.cs      # Azure OpenAI + self-healing retry
│   │       ├── QueryExecutionService.cs    # Safe read-only execution
│   │       ├── AdaptiveCardService.cs      # Table/KPI/Chart/Error cards
│   │       └── ChartService.cs             # QuickChart.io URL generation
│   └── SqlCopilot.Web/                     # ASP.NET Core host
│       ├── Bot/
│       │   ├── SqlCopilotBot.cs            # Teams bot handler
│       │   └── AdapterWithErrorHandler.cs  # Global error handler
│       ├── Controllers/
│       │   ├── BotController.cs            # POST /api/messages
│       │   └── QueryController.cs          # POST /api/query
│       ├── Program.cs                      # DI + middleware + endpoints
│       ├── appsettings.json                # Configuration
│       └── appPackage/                     # Teams/M365 Copilot manifest
│           ├── manifest.json               # Teams app manifest (v1.19)
│           ├── declarativeAgent.json        # M365 Copilot agent config
│           ├── ai-plugin.json              # OpenAI plugin specification
│           ├── color.png                   # App icon (192×192)
│           ├── outline.png                 # App icon (32×32)
│           └── apiSpecificationFile/
│               └── openapi.yaml            # OpenAPI spec for plugin
`

## NuGet Packages

| Package | Version | Purpose |
|---------|---------|---------|
| Azure.AI.OpenAI | 2.1.0 | Azure OpenAI client for NL→SQL |
| Azure.Identity | 1.13.2 | DefaultAzureCredential for Managed Identity |
| Microsoft.Data.SqlClient | 5.2.2 | Azure SQL Database connectivity |
| Microsoft.Bot.Builder.Integration.AspNet.Core | 4.22.9 | Bot Framework SDK |
| AdaptiveCards | 3.1.0 | Adaptive Card schema types |
| Swashbuckle.AspNetCore | 6.9.0 | Swagger UI for API docs |
| Microsoft.Extensions.Caching.Memory | 8.0.1 | In-memory schema caching |

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "No tables found" | Check SQL connection string, MI permissions, and firewall rules |
| "Failed to generate SQL" | Verify Azure OpenAI endpoint, API key, and deployment name |
| "Azure AD authentication failed" | Ensure the Managed Identity is granted access to the SQL database |
| "SQL Error #-2: Timeout" | Increase QueryTimeoutSeconds or add TOP/WHERE to narrow the query |
| "Message size too large" | The service auto-trims, but you can reduce MaxRowsReturned |
| Bot doesn't respond | Check Bot registration messaging endpoint URL matches your App Service |
| Schema is stale | Send /refresh to the bot or restart the App Service |
| Charts not showing | Ensure outbound HTTPS to quickchart.io is allowed |
| "invalid BotId" in manifest | Ensure id and otId in manifest.json match your Entra App ID |
| 403 Forbidden on App Service | Check App Service authentication settings and IP restrictions |

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | / | Health check (returns { status: "healthy" }) |
| POST | /api/messages | Bot Framework activity endpoint (Teams) |
| POST | /api/query | REST API for M365 Copilot plugin |
| GET | /swagger | Swagger UI for API documentation |

### POST /api/query

`json
// Request
{ "query": "How many cases were created this month?" }

// Response
{
  "success": true,
  "explanation": "Counts cases created in the current month",
  "sql": "SELECT COUNT(*) AS TotalCases FROM dbo.Cases WHERE ...",
  "columns": [{ "name": "TotalCases", "dataType": "int" }],
  "rows": [{ "TotalCases": 142 }],
  "totalRows": 1,
  "executionTimeMs": 45.2,
  "isTruncated": false,
  "error": null
}
`

## License

MIT
