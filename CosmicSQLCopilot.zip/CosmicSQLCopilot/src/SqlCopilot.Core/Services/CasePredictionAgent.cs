// ============================================================================
// CasePredictionAgent.cs — “Clarify vs predict” decisioning for SLA prediction
//
// This component turns messy user text (or partial structured input) into a decision:
// - Ask a clarifying question if required fields are missing/ambiguous, OR
// - Produce a normalized `CasePredictionRecord` suitable for the prediction API.
//
// Important nuance:
// - We blend lightweight deterministic parsing (regex hints like "today", "4pm", ROC tokens)
//   with an LLM JSON contract so the experience is flexible but still parseable.
// - The decision is *not* a prediction itself; it prepares inputs and policy.
//
// See also:
// - Orchestration and pending-state caching: `Services/ConversationOrchestratorService.cs`
// - API invocation: `Services/CasePredictionClient.cs`
// - Optional DB feature enrichment: `Services/CaseFeatureService.cs`
// - Data contracts: `Models/CasePredictionApiModels.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using SqlCopilot.Core.Agent;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

public sealed class CasePredictionAgent
{
    private static readonly string[] RequiredKeys =
    {
        "createdon",
        "msdyn_countryprocessedidname",
        "msdyn_businessfunctionidname",
        "msdyn_casesubtypeidname",
        "msdyn_casesubreasonidname"
    };

    private static readonly Regex RocRegex = new(@"\b(AOC|EOC|APOC)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex TodayRegex = new(@"\btoday\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex TomorrowRegex = new(@"\btomorrow\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex YesterdayRegex = new(@"\byesterday\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex NowRegex = new(@"\bnow\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    // Examples: "4pm", "4 pm", "4:30pm", "16:30", "16:30:00"
    private static readonly Regex TimeRegex = new(
        @"(?:(?<h>\d{1,2})(?::(?<m>\d{2}))?(?::(?<s>\d{2}))?\s*(?<ampm>am|pm)\b)|(?:\b(?<h24>\d{1,2}):(?<m24>\d{2})(?::(?<s24>\d{2}))?\b)",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex RegionHintRegex = new(
        @"\b(asia\s*pacific|apac|europe|emea|america|americas|north\s*america|united\s*states|india)\b",
        RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private readonly IJsonLlmClient _jsonLlm;
    private readonly ILogger<CasePredictionAgent> _logger;

    public CasePredictionAgent(IJsonLlmClient jsonLlm, ILogger<CasePredictionAgent> logger)
    {
        _jsonLlm = jsonLlm ?? throw new ArgumentNullException(nameof(jsonLlm));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<CasePredictionAgentDecision> DecideAsync(
        string userText,
        CasePredictionRecord? pendingRecord,
        DateTimeOffset nowUtc,
        CancellationToken cancellationToken = default)
    {
        userText = (userText ?? "").Trim();
        if (userText.Length == 0)
        {
            return CasePredictionAgentDecision.Clarify(
                "Please describe the case you want to predict (created time, region/country, subtype, business function, and subreason).",
                RequiredKeys,
                pendingRecord ?? new CasePredictionRecord());
        }

        var prompt = BuildPrompt(userText, pendingRecord, nowUtc);
        var el = await _jsonLlm.CallJsonAsync(prompt, cancellationToken);

        var type = el.TryGetProperty("type", out var t) ? (t.GetString() ?? "") : "";
        type = type.Trim().ToLowerInvariant();

        if (type == "call_api")
        {
            if (!el.TryGetProperty("record", out var recEl) || recEl.ValueKind != JsonValueKind.Object)
            {
                return CasePredictionAgentDecision.Clarify(
                    "I couldn’t extract the case details. Please share the case fields (created time, region/country, subtype, business function, subreason).",
                    RequiredKeys,
                    pendingRecord ?? new CasePredictionRecord());
            }

            var record = ParseRecord(recEl, pendingRecord);
            record = ResolveCreatedOn(record, userText, nowUtc);

            var missing = MissingRequired(record);
            if (missing.Count > 0)
            {
                return CasePredictionAgentDecision.Clarify(
                    BuildClarifyQuestion(missing),
                    missing,
                    record);
            }

            EnsureSyntheticId(record);
            return CasePredictionAgentDecision.CallApi(record);
        }

        // Default to clarify (strict behavior)
        string question = "Please provide the missing details so I can run prediction.";
        var missingList = new List<string>(RequiredKeys);
        CasePredictionRecord partial = pendingRecord ?? new CasePredictionRecord();

        if (el.ValueKind == JsonValueKind.Object)
        {
            if (el.TryGetProperty("missing", out var m) && m.ValueKind == JsonValueKind.Array)
                missingList = m.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => (x.GetString() ?? "").Trim()).Where(s => s.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (el.TryGetProperty("question", out var q) && q.ValueKind == JsonValueKind.String)
                question = (q.GetString() ?? "").Trim();
            if (el.TryGetProperty("partialRecord", out var pr) && pr.ValueKind == JsonValueKind.Object)
                partial = ParseRecord(pr, pendingRecord);
        }

        partial = ResolveCreatedOn(partial, userText, nowUtc);
        var missing2 = MissingRequired(partial);
        if (missing2.Count > 0)
        {
            missingList = missing2;
            if (string.IsNullOrWhiteSpace(question))
                question = BuildClarifyQuestion(missing2);
        }

        if (string.IsNullOrWhiteSpace(question))
            question = BuildClarifyQuestion(missingList);

        return CasePredictionAgentDecision.Clarify(question, missingList, partial);
    }

    private static string BuildPrompt(string userText, CasePredictionRecord? pendingRecord, DateTimeOffset nowUtc)
    {
        var pendingJson = pendingRecord is null ? "{}" : JsonSerializer.Serialize(new
        {
            TicketNumber = pendingRecord.TicketNumber,
            createdon = pendingRecord.CreatedOn,
            msdyn_caserocname = pendingRecord.MsdynCaseRocName,
            msdyn_businessfunctionidname = pendingRecord.MsdynBusinessFunctionIdName,
            msdyn_lineofbusinessidname = pendingRecord.MsdynLineOfBusinessIdName,
            msdyn_programidname = pendingRecord.MsdynProgramIdName,
            msdyn_casetypeidname = pendingRecord.MsdynCaseTypeIdName,
            msdyn_casesubtypeidname = pendingRecord.MsdynCaseSubTypeIdName,
            msdyn_casereasonidname = pendingRecord.MsdynCaseReasonIdName,
            msdyn_casesubreasonidname = pendingRecord.MsdynCaseSubReasonIdName,
            prioritycodename = pendingRecord.PriorityCodeName,
            msdyn_complexityname = pendingRecord.MsdynComplexityName,
            msdyn_countrysubmitteridname = pendingRecord.MsdynCountrySubmitterIdName,
            msdyn_countryprocessedidname = pendingRecord.MsdynCountryProcessedIdName,
            statuscodename = pendingRecord.StatusCodeName,
            onholdtime = pendingRecord.OnHoldTime
        });

        var sb = new StringBuilder();
        sb.AppendLine("You are a CasePredictionAgent for a Teams bot.");
        sb.AppendLine("Your job: extract a case record to call a LightGBM inference API. Do NOT invent values.");
        sb.AppendLine();
        sb.AppendLine("The API requires these record keys to exist (ask user if missing):");
        sb.AppendLine("- createdon (date/time of case creation)");
        sb.AppendLine("- msdyn_countryprocessedidname (region/country where case is processed)");
        sb.AppendLine("- msdyn_businessfunctionidname");
        sb.AppendLine("- msdyn_casesubtypeidname");
        sb.AppendLine("- msdyn_casesubreasonidname");
        sb.AppendLine();
        sb.AppendLine("TicketNumber is NOT required; if absent the system will generate a synthetic GUID.");
        sb.AppendLine("If TicketNumber is present but other required fields are missing, the system may have already fetched them into PENDING_PARTIAL_RECORD_JSON (from the database).");
        sb.AppendLine("If PENDING_PARTIAL_RECORD_JSON already contains ALL required keys, return type=call_api even if the user message is only a ticket number.");
        sb.AppendLine();
        sb.AppendLine("Time handling:");
        sb.AppendLine("- If user gives an explicit timestamp, use it as createdon.");
        sb.AppendLine("- If user uses relative time like \"today 4pm\", keep createdon empty and ensure msdyn_caserocname is set to one of [AOC,EOC,APOC].");
        sb.AppendLine();
        sb.AppendLine($"Current UTC time: {nowUtc:yyyy-MM-dd HH:mm:ss}.");
        sb.AppendLine();
        sb.AppendLine("You must return ONLY valid JSON in one of these forms:");
        sb.AppendLine("1) {\"type\":\"call_api\",\"record\":{...}}");
        sb.AppendLine("2) {\"type\":\"clarify\",\"question\":\"...\",\"missing\":[...],\"partialRecord\":{...}}");
        sb.AppendLine();
        sb.AppendLine("Record keys must match exactly (example subset):");
        sb.AppendLine("{\"TicketNumber\":\"\",\"createdon\":\"\",\"msdyn_caserocname\":\"\",\"msdyn_countryprocessedidname\":\"\",\"msdyn_businessfunctionidname\":\"\",\"msdyn_casesubtypeidname\":\"\",\"msdyn_casesubreasonidname\":\"\"}");
        sb.AppendLine();
        sb.AppendLine("If multiple fields are missing, ask ONE concise question listing them.");
        sb.AppendLine();
        sb.AppendLine("PENDING_PARTIAL_RECORD_JSON:");
        sb.AppendLine(pendingJson);
        sb.AppendLine();
        sb.AppendLine("USER_MESSAGE:");
        sb.AppendLine(userText);
        return sb.ToString();
    }

    private static CasePredictionRecord ParseRecord(JsonElement recEl, CasePredictionRecord? pending)
    {
        var record = pending is null ? new CasePredictionRecord() : Clone(pending);

        string? get(string name)
            => recEl.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

        var ticket = (get("TicketNumber") ?? get("ticketNumber") ?? "").Trim();
        if (ticket.Length > 0) record.TicketNumber = ticket;

        record.CreatedOn = TrimToNull(get("createdon")) ?? record.CreatedOn;
        record.MsdynCaseRocName = TrimToNull(get("msdyn_caserocname")) ?? record.MsdynCaseRocName;
        record.MsdynBusinessFunctionIdName = TrimToNull(get("msdyn_businessfunctionidname")) ?? record.MsdynBusinessFunctionIdName;
        record.MsdynLineOfBusinessIdName = TrimToNull(get("msdyn_lineofbusinessidname")) ?? record.MsdynLineOfBusinessIdName;
        record.MsdynProgramIdName = TrimToNull(get("msdyn_programidname")) ?? record.MsdynProgramIdName;
        record.MsdynCaseTypeIdName = TrimToNull(get("msdyn_casetypeidname")) ?? record.MsdynCaseTypeIdName;
        record.MsdynCaseSubTypeIdName = TrimToNull(get("msdyn_casesubtypeidname")) ?? record.MsdynCaseSubTypeIdName;
        record.MsdynCaseReasonIdName = TrimToNull(get("msdyn_casereasonidname")) ?? record.MsdynCaseReasonIdName;
        record.MsdynCaseSubReasonIdName = TrimToNull(get("msdyn_casesubreasonidname")) ?? record.MsdynCaseSubReasonIdName;
        record.PriorityCodeName = TrimToNull(get("prioritycodename")) ?? record.PriorityCodeName;
        record.MsdynComplexityName = TrimToNull(get("msdyn_complexityname")) ?? record.MsdynComplexityName;
        record.MsdynCountrySubmitterIdName = TrimToNull(get("msdyn_countrysubmitteridname")) ?? record.MsdynCountrySubmitterIdName;
        record.MsdynCountryProcessedIdName = TrimToNull(get("msdyn_countryprocessedidname")) ?? record.MsdynCountryProcessedIdName;
        record.StatusCodeName = TrimToNull(get("statuscodename")) ?? record.StatusCodeName;
        record.OnHoldTime = TrimToNull(get("onholdtime")) ?? record.OnHoldTime;

        return record;
    }

    private static CasePredictionRecord ResolveCreatedOn(CasePredictionRecord record, string userText, DateTimeOffset nowUtc)
    {
        record = Clone(record);

        // If createdon is already parseable, normalize to the expected format.
        if (!string.IsNullOrWhiteSpace(record.CreatedOn))
        {
            if (TryParseDateTime(record.CreatedOn!, out var dt))
            {
                record.CreatedOn = dt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                return record;
            }
        }

        // Try to infer ROC from text if missing (needed for relative times).
        if (string.IsNullOrWhiteSpace(record.MsdynCaseRocName))
        {
            var roc = InferRocFromText(userText);
            if (!string.IsNullOrWhiteSpace(roc))
                record.MsdynCaseRocName = roc;
        }

        // If user gave an explicit date-time in the message, use it.
        if (TryFindExplicitDateTimeInText(userText, out var explicitDt))
        {
            record.CreatedOn = explicitDt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
            return record;
        }

        // Relative time parsing (today/tomorrow/yesterday/now + time) in ROC timezone.
        if (!LooksLikeRelativeTime(userText))
            return record;

        var rocName = (record.MsdynCaseRocName ?? "").Trim().ToUpperInvariant();
        if (rocName.Length == 0)
            return record; // Agent should ask for roc if relative.

        if (!TryResolveRelativeTime(userText, rocName, nowUtc, out var createdLocal))
            return record;

        record.CreatedOn = createdLocal.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
        return record;
    }

    private static bool LooksLikeRelativeTime(string text)
    {
        text ??= "";
        return TodayRegex.IsMatch(text) || TomorrowRegex.IsMatch(text) || YesterdayRegex.IsMatch(text) || NowRegex.IsMatch(text) || TimeRegex.IsMatch(text);
    }

    private static bool TryResolveRelativeTime(string userText, string roc, DateTimeOffset nowUtc, out DateTime createdLocal)
    {
        createdLocal = default;
        userText ??= "";

        var tz = GetTimeZoneForRoc(roc);
        var nowLocal = TimeZoneInfo.ConvertTime(nowUtc, tz).DateTime;
        var date = nowLocal.Date;

        if (TomorrowRegex.IsMatch(userText)) date = date.AddDays(1);
        else if (YesterdayRegex.IsMatch(userText)) date = date.AddDays(-1);
        // today -> keep

        if (NowRegex.IsMatch(userText) && !TimeRegex.IsMatch(userText))
        {
            createdLocal = nowLocal;
            return true;
        }

        if (!TryExtractTime(userText, out var tod))
            return false;

        createdLocal = date.Add(tod);
        return true;
    }

    private static bool TryExtractTime(string text, out TimeSpan time)
    {
        time = default;
        text ??= "";

        if (Regex.IsMatch(text, @"\bnoon\b", RegexOptions.IgnoreCase))
        {
            time = new TimeSpan(12, 0, 0);
            return true;
        }
        if (Regex.IsMatch(text, @"\bmidnight\b", RegexOptions.IgnoreCase))
        {
            time = new TimeSpan(0, 0, 0);
            return true;
        }

        var m = TimeRegex.Match(text);
        if (!m.Success) return false;

        if (m.Groups["h24"].Success)
        {
            int h = int.Parse(m.Groups["h24"].Value, CultureInfo.InvariantCulture);
            int mm = int.Parse(m.Groups["m24"].Value, CultureInfo.InvariantCulture);
            int ss = m.Groups["s24"].Success ? int.Parse(m.Groups["s24"].Value, CultureInfo.InvariantCulture) : 0;
            if (h is < 0 or > 23 || mm is < 0 or > 59 || ss is < 0 or > 59) return false;
            time = new TimeSpan(h, mm, ss);
            return true;
        }

        int hour = int.Parse(m.Groups["h"].Value, CultureInfo.InvariantCulture);
        int minute = m.Groups["m"].Success ? int.Parse(m.Groups["m"].Value, CultureInfo.InvariantCulture) : 0;
        int sec2 = m.Groups["s"].Success ? int.Parse(m.Groups["s"].Value, CultureInfo.InvariantCulture) : 0;
        var ampm = (m.Groups["ampm"].Value ?? "").Trim().ToLowerInvariant();
        if (hour is < 1 or > 12 || minute is < 0 or > 59 || sec2 is < 0 or > 59) return false;
        if (ampm == "pm" && hour != 12) hour += 12;
        if (ampm == "am" && hour == 12) hour = 0;
        time = new TimeSpan(hour, minute, sec2);
        return true;
    }

    private static TimeZoneInfo GetTimeZoneForRoc(string roc)
    {
        roc = (roc ?? "").Trim().ToUpperInvariant();
        var id = roc switch
        {
            "AOC" => "Central Standard Time",
            "EOC" => "UTC",
            "APOC" => "India Standard Time",
            _ => "UTC"
        };

        try
        {
            return TimeZoneInfo.FindSystemTimeZoneById(id);
        }
        catch
        {
            return TimeZoneInfo.Utc;
        }
    }

    private static string? InferRocFromText(string text)
    {
        text ??= "";

        var m = RocRegex.Match(text);
        if (m.Success) return m.Value.Trim().ToUpperInvariant();

        var hint = RegionHintRegex.Match(text);
        if (!hint.Success) return null;

        var h = hint.Value.ToLowerInvariant();
        if (h.Contains("asia") || h.Contains("apac") || h.Contains("india"))
            return "APOC";
        if (h.Contains("europe") || h.Contains("emea"))
            return "EOC";
        if (h.Contains("america") || h.Contains("united states") || h.Contains("north america"))
            return "AOC";
        return null;
    }

    private static bool TryFindExplicitDateTimeInText(string text, out DateTime explicitDt)
    {
        explicitDt = default;
        text ??= "";

        // Very small set of patterns we can pick up reliably.
        var patterns = new[]
        {
            // 2025-04-21 20:04:00 or 2025-04-21 20:04
            new Regex(@"\b\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}(:\d{2})?\b", RegexOptions.Compiled),
            // 4/21/2025 20:04 or 4/21/2025 8:04 PM
            new Regex(@"\b\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}(\s*(AM|PM|am|pm))?\b", RegexOptions.Compiled)
        };

        foreach (var rx in patterns)
        {
            var m = rx.Match(text);
            if (!m.Success) continue;
            if (TryParseDateTime(m.Value, out var dt))
            {
                explicitDt = dt;
                return true;
            }
        }

        return false;
    }

    private static bool TryParseDateTime(string input, out DateTime dt)
    {
        dt = default;
        input = (input ?? "").Trim();
        if (input.Length == 0) return false;

        var formats = new[]
        {
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "M/d/yyyy H:mm",
            "M/d/yyyy HH:mm",
            "M/d/yyyy h:mm tt",
            "M/d/yyyy hh:mm tt",
            "MM/dd/yyyy HH:mm:ss",
            "MM/dd/yyyy HH:mm",
            "yyyy/MM/dd HH:mm:ss",
            "yyyy/MM/dd HH:mm"
        };

        if (DateTime.TryParseExact(input, formats, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out dt))
            return true;

        // Last resort (still invariant)
        return DateTime.TryParse(input, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out dt);
    }

    private static List<string> MissingRequired(CasePredictionRecord record)
    {
        var missing = new List<string>();

        bool blank(string? s) => string.IsNullOrWhiteSpace(s);

        if (blank(record.CreatedOn)) missing.Add("createdon");
        if (blank(record.MsdynCountryProcessedIdName)) missing.Add("msdyn_countryprocessedidname");
        if (blank(record.MsdynBusinessFunctionIdName)) missing.Add("msdyn_businessfunctionidname");
        if (blank(record.MsdynCaseSubTypeIdName)) missing.Add("msdyn_casesubtypeidname");
        if (blank(record.MsdynCaseSubReasonIdName)) missing.Add("msdyn_casesubreasonidname");

        return missing;
    }

    private static string BuildClarifyQuestion(List<string> missing)
    {
        missing = (missing ?? new List<string>()).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (missing.Count == 0)
            return "What case details should I use for prediction?";

        var labels = missing.Select(k => k switch
        {
            "createdon" => "`createdon` (when the case was created, e.g. `2026-04-15 16:00:00` or “today 4pm” + ROC)",
            "msdyn_countryprocessedidname" => "`msdyn_countryprocessedidname` (processing country/region, e.g. `United States`)",
            "msdyn_businessfunctionidname" => "`msdyn_businessfunctionidname` (e.g. `Signature to Invoice (S2I)`)",
            "msdyn_casesubtypeidname" => "`msdyn_casesubtypeidname` (e.g. `Agreement`)",
            "msdyn_casesubreasonidname" => "`msdyn_casesubreasonidname` (e.g. `Renewal Enrollment/Standalone Agreement`)",
            _ => $"`{k}`"
        }).ToList();

        return "To run case prediction, please provide: " + string.Join(", ", labels) + ".";
    }

    private static void EnsureSyntheticId(CasePredictionRecord record)
    {
        // The upstream function requires an id candidate column to exist for output `case_id`.
        // TicketNumber is not a model feature; we can generate a GUID if missing.
        if (string.IsNullOrWhiteSpace(record.TicketNumber))
            record.TicketNumber = Guid.NewGuid().ToString();
    }

    private static string? TrimToNull(string? s)
    {
        s = (s ?? "").Trim();
        return s.Length == 0 ? null : s;
    }

    private static CasePredictionRecord Clone(CasePredictionRecord r)
        => new()
        {
            TicketNumber = r.TicketNumber,
            CreatedOn = r.CreatedOn,
            MsdynCaseRocName = r.MsdynCaseRocName,
            MsdynBusinessFunctionIdName = r.MsdynBusinessFunctionIdName,
            MsdynLineOfBusinessIdName = r.MsdynLineOfBusinessIdName,
            MsdynProgramIdName = r.MsdynProgramIdName,
            MsdynCaseTypeIdName = r.MsdynCaseTypeIdName,
            MsdynCaseSubTypeIdName = r.MsdynCaseSubTypeIdName,
            MsdynCaseReasonIdName = r.MsdynCaseReasonIdName,
            MsdynCaseSubReasonIdName = r.MsdynCaseSubReasonIdName,
            PriorityCodeName = r.PriorityCodeName,
            MsdynComplexityName = r.MsdynComplexityName,
            MsdynCountrySubmitterIdName = r.MsdynCountrySubmitterIdName,
            MsdynCountryProcessedIdName = r.MsdynCountryProcessedIdName,
            StatusCodeName = r.StatusCodeName,
            OnHoldTime = r.OnHoldTime
        };
}

public sealed record CasePredictionAgentDecision(
    string Type,
    string? Question,
    IReadOnlyList<string> Missing,
    CasePredictionRecord? PartialRecord,
    CasePredictionRecord? Record)
{
    public static CasePredictionAgentDecision Clarify(string question, IReadOnlyList<string> missing, CasePredictionRecord partial)
        => new("clarify", question, missing, partial, null);

    public static CasePredictionAgentDecision CallApi(CasePredictionRecord record)
        => new("call_api", null, Array.Empty<string>(), null, record);
}

