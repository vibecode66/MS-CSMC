// ============================================================================
// CasePredictionClient.cs — HTTP client for the SLA regressor inference endpoint
//
// This client calls the external prediction endpoint (typically an Azure Function)
// that runs a trained model (e.g., LightGBM) and returns predicted resolution time.
//
// Design intent:
// - Keep HTTP + serialization details isolated from orchestration and UX logic.
// - Provide sensible defaults for endpoint + storage prefixes so demos work with
//   minimal configuration, while still allowing overrides via options.
//
// See also:
// - Orchestrator entrypoint: `Services/ConversationOrchestratorService.cs`
// - Input preparation/policy: `Services/CasePredictionAgent.cs`
// - Options and API models: `Models/CasePredictionOptions.cs`, `Models/CasePredictionApiModels.cs`
// - Web endpoint wrapper: `src/SqlCopilot.Web/Controllers/CasePredictionController.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Text;
using System.Text.Json;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Services;

namespace SqlCopilot.Core.Services;

public sealed class CasePredictionClient : ICasePredictionClient
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = null,
        // Always include keys (the function expects certain columns like 'createdon' to exist).
        DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.Never
    };

    private readonly HttpClient _http;
    private readonly CasePredictionOptions _options;
    private readonly ILogger<CasePredictionClient> _logger;

    public CasePredictionClient(
        HttpClient http,
        IOptions<CasePredictionOptions> options,
        ILogger<CasePredictionClient> logger)
    {
        _http = http ?? throw new ArgumentNullException(nameof(http));
        _options = (options ?? throw new ArgumentNullException(nameof(options))).Value;
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<CasePredictionApiResponse> PredictAsync(
        CasePredictionInvokeRequest request,
        CancellationToken cancellationToken = default)
    {
        if (request is null) throw new ArgumentNullException(nameof(request));
        if (request.Records is null || request.Records.Count == 0)
            throw new ArgumentException("At least one record is required.", nameof(request));

        // Fill defaults (from api.txt) if config is missing/blank.
        var endpointStr = FirstNonBlank(_options.Endpoint,
            "https://func-sla-lightgbm-infer-uat-eastus.azurewebsites.net/api/sla-regressor-lightgbm-infer");

        var storageAccount = FirstNonBlank(_options.StorageAccount, "stslalightgbmuateu");
        var container = FirstNonBlank(_options.Container, "train-data");
        var modelPrefix = FirstNonBlank(_options.ModelPrefix, "sla-regressor-lightgbm/models/");
        var outputPrefix = FirstNonBlank(_options.OutputPrefix, "sla-regressor-lightgbm/inference-outputs/");

        var payload = new
        {
            storageAccount,
            container,
            modelPrefix,
            outputPrefix,
            uploadOutput = request.UploadOutput ?? _options.UploadOutput,
            maxReturnRows = request.MaxReturnRows ?? _options.MaxReturnRows,
            records = request.Records.Select(NormalizeRecord).ToList()
        };

        var endpoint = new Uri(endpointStr, UriKind.Absolute);

        var ids = request.Records
            .Select(r => (r.TicketNumber ?? "").Trim())
            .Where(s => s.Length > 0)
            .Take(8)
            .ToList();

        _logger.LogInformation(
            "LGBM_HTTP_CALL_START endpoint={Endpoint} records={RecordCount} maxReturnRows={MaxReturnRows} ids=[{Ids}]",
            endpoint, request.Records.Count, payload.maxReturnRows, string.Join(", ", ids));

        var json = JsonSerializer.Serialize(payload, JsonOptions);
        _logger.LogDebug("Case prediction request payload (truncated): {Payload}", Truncate(json, 2000));

        var sw = Stopwatch.StartNew();
        using var content = new StringContent(json, Encoding.UTF8, "application/json");
        using var response = await _http.PostAsync(endpoint, content, cancellationToken);
        var raw = await response.Content.ReadAsStringAsync(cancellationToken);
        sw.Stop();
        _logger.LogInformation(
            "LGBM_HTTP_CALL_DONE statusCode={StatusCode} elapsedMs={ElapsedMs} responseChars={Chars}",
            (int)response.StatusCode,
            sw.ElapsedMilliseconds,
            raw.Length);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "LGBM_HTTP_CALL_FAILED statusCode={StatusCode} body=\"{Body}\"",
                (int)response.StatusCode, LogText.Trunc(raw, 2000));

            throw new HttpRequestException(
                $"Case prediction function call failed with HTTP {(int)response.StatusCode} ({response.ReasonPhrase}). Body: {Truncate(raw, 1000)}");
        }

        try
        {
            var parsed = JsonSerializer.Deserialize<CasePredictionApiResponse>(raw, JsonOptions);
            if (parsed is null)
                throw new JsonException("Response body deserialized to null.");

            _logger.LogInformation(
                "LGBM_HTTP_PARSE_OK status={Status} previewRows={Rows} modelBlob={ModelBlob}",
                parsed.Status ?? "",
                parsed.Preview?.Count ?? 0,
                parsed.Artifacts?.ModelBlob ?? "");
            return parsed;
        }
        catch (Exception ex) when (ex is JsonException or NotSupportedException)
        {
            _logger.LogError(ex,
                "Failed to parse case prediction response JSON. Body: {Body}",
                Truncate(raw, 2000));
            throw;
        }
    }

    private static string Truncate(string? s, int maxChars)
    {
        s ??= "";
        maxChars = Math.Max(16, maxChars);
        return s.Length <= maxChars ? s : s[..maxChars] + "...";
    }

    private static string FirstNonBlank(string? value, string fallback)
    {
        var v = (value ?? "").Trim();
        return v.Length == 0 ? fallback : v;
    }

    private static CasePredictionRecord NormalizeRecord(CasePredictionRecord r)
    {
        // Ensure all expected keys are present in JSON by avoiding nulls.
        // The upstream function can handle empty strings better than missing columns.
        return new CasePredictionRecord
        {
            TicketNumber = (r.TicketNumber ?? "").Trim(),
            CreatedOn = (r.CreatedOn ?? "").Trim(),
            MsdynCaseRocName = (r.MsdynCaseRocName ?? "").Trim(),
            MsdynBusinessFunctionIdName = (r.MsdynBusinessFunctionIdName ?? "").Trim(),
            MsdynLineOfBusinessIdName = (r.MsdynLineOfBusinessIdName ?? "").Trim(),
            MsdynProgramIdName = (r.MsdynProgramIdName ?? "").Trim(),
            MsdynCaseTypeIdName = (r.MsdynCaseTypeIdName ?? "").Trim(),
            MsdynCaseSubTypeIdName = (r.MsdynCaseSubTypeIdName ?? "").Trim(),
            MsdynCaseReasonIdName = (r.MsdynCaseReasonIdName ?? "").Trim(),
            MsdynCaseSubReasonIdName = (r.MsdynCaseSubReasonIdName ?? "").Trim(),
            PriorityCodeName = (r.PriorityCodeName ?? "").Trim(),
            MsdynComplexityName = (r.MsdynComplexityName ?? "").Trim(),
            MsdynCountrySubmitterIdName = (r.MsdynCountrySubmitterIdName ?? "").Trim(),
            MsdynCountryProcessedIdName = (r.MsdynCountryProcessedIdName ?? "").Trim(),
            StatusCodeName = (r.StatusCodeName ?? "").Trim(),
            OnHoldTime = (r.OnHoldTime ?? "").Trim()
        };
    }
}

