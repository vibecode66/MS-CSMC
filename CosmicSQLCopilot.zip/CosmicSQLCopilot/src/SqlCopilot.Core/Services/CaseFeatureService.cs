// ============================================================================
// CaseFeatureService.cs — Load case features from DB to enrich prediction input
//
// SLA prediction can be invoked with a fully specified `CasePredictionRecord`.
// In practice, users often only provide a ticket number. This service attempts
// to fetch a minimal set of feature columns from the database so the prediction
// request is complete enough for the model.
//
// Safety/robustness constraints:
// - Feature loading is best-effort: if schema/table/columns are missing, we return null
//   rather than failing the whole conversation.
// - Column selection is allowlisted and matched case-insensitively to tolerate
//   schema variations across environments.
//
// See also:
// - Case prediction orchestration: `Services/ConversationOrchestratorService.cs`
// - Prediction decisioning: `Services/CasePredictionAgent.cs`
// - Prediction invocation: `Services/CasePredictionClient.cs`
// - Data contracts: `Models/CasePredictionApiModels.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Globalization;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

public sealed class CaseFeatureService : ICaseFeatureService
{
    private static readonly string[] TicketIdStringCandidates =
    {
        "TicketNumber",
        "ticketnumber",
        "msdyn_casenumber",
        "case_id",
        "CaseId",
        "caseid",
        "IncidentId",
        "incidentid"
    };

    private static readonly string[] TicketIdGuidCandidates =
    {
        "IncidentId",
        "incidentid"
    };

    private static readonly string[] DesiredColumns =
    {
        "createdon",
        "msdyn_resolveddate",
        "msdyn_caserocname",
        "msdyn_businessfunctionidname",
        "msdyn_lineofbusinessidname",
        "msdyn_programidname",
        "msdyn_casetypeidname",
        "msdyn_casesubtypeidname",
        "msdyn_casereasonidname",
        "msdyn_casesubreasonidname",
        "prioritycodename",
        "msdyn_complexityname",
        "msdyn_countrysubmitteridname",
        "msdyn_countryprocessedidname",
        "statuscodename",
        "onholdtime"
    };

    private readonly ISchemaDiscoveryService _schema;
    private readonly ISqlConnectionFactory _connections;
    private readonly ILogger<CaseFeatureService> _logger;

    public CaseFeatureService(
        ISchemaDiscoveryService schema,
        ISqlConnectionFactory connections,
        ILogger<CaseFeatureService> logger)
    {
        _schema = schema ?? throw new ArgumentNullException(nameof(schema));
        _connections = connections ?? throw new ArgumentNullException(nameof(connections));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<CasePredictionRecord?> TryGetCasePredictionRecordAsync(
        string ticketNumber,
        CancellationToken cancellationToken = default)
    {
        ticketNumber = (ticketNumber ?? "").Trim();
        if (ticketNumber.Length == 0) return null;

        var dbSchema = await _schema.GetSchemaAsync(cancellationToken);

        // Prefer Incident/Cases-like tables when available; otherwise pick the best match
        // among allowlisted discovered tables (e.g., "eh_incident").
        var table = SelectBestCaseTable(dbSchema, requireCreatedOn: false);
        if (table is null)
        {
            _logger.LogWarning(
                "Cannot load case features: no suitable case table discovered in schema allowlist.");
            return null;
        }

        var cols = (table.Columns ?? new List<ColumnSchema>())
            .Select(c => c.ColumnName)
            .Where(n => !string.IsNullOrWhiteSpace(n))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var isGuid = Guid.TryParse(ticketNumber, out var guid);
        var ticketCol = PickTicketColumn(cols, isGuid);
        if (string.IsNullOrWhiteSpace(ticketCol))
        {
            _logger.LogWarning(
                "Cannot load case features: no ID column found on dbo.{Table}.",
                table.TableName);
            return null;
        }

        var selectParts = new List<string> { $"[{ticketCol}] AS [TicketNumber]" };
        foreach (var c in DesiredColumns)
        {
            if (cols.Contains(c))
                selectParts.Add($"[{c}] AS [{c}]");
        }

        var sql =
            "SELECT TOP (1) " + string.Join(", ", selectParts) + "\n" +
            $"FROM [dbo].[{table.TableName}] WITH (NOLOCK)\n" +
            $"WHERE [{ticketCol}] = @ticket";

        _logger.LogInformation(
            "CASE_FEATURE_LOOKUP_START table=dbo.{Table} idCol={IdCol} isGuid={IsGuid} ticket={Ticket}",
            table.TableName,
            ticketCol,
            isGuid,
            ticketNumber);
        _logger.LogDebug("CASE_FEATURE_LOOKUP_SQL (truncated) {Sql}", LogText.Trunc(sql, 2000));

        await using var connection = await _connections.CreateConnectionAsync(cancellationToken);

        await using var cmd = new SqlCommand(sql, connection)
        {
            CommandTimeout = 30
        };

        cmd.Parameters.Add(isGuid
            ? new SqlParameter("@ticket", System.Data.SqlDbType.UniqueIdentifier) { Value = guid }
            : new SqlParameter("@ticket", System.Data.SqlDbType.NVarChar, 200) { Value = ticketNumber });

        try
        {
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                _logger.LogInformation(
                    "CASE_FEATURE_LOOKUP_DONE found=false table=dbo.{Table} ticket={Ticket}",
                    table.TableName,
                    ticketNumber);
                return null;
            }

            var record = new CasePredictionRecord
            {
                TicketNumber = ticketNumber,
                CreatedOn = TryReadAsDateTimeString(reader, "createdon")
            };

            record.MsdynResolvedDate = TryReadAsDateTimeString(reader, "msdyn_resolveddate");
            record.MsdynCaseRocName = TryReadAsString(reader, "msdyn_caserocname");
            record.MsdynBusinessFunctionIdName = TryReadAsString(reader, "msdyn_businessfunctionidname");
            record.MsdynLineOfBusinessIdName = TryReadAsString(reader, "msdyn_lineofbusinessidname");
            record.MsdynProgramIdName = TryReadAsString(reader, "msdyn_programidname");
            record.MsdynCaseTypeIdName = TryReadAsString(reader, "msdyn_casetypeidname");
            record.MsdynCaseSubTypeIdName = TryReadAsString(reader, "msdyn_casesubtypeidname");
            record.MsdynCaseReasonIdName = TryReadAsString(reader, "msdyn_casereasonidname");
            record.MsdynCaseSubReasonIdName = TryReadAsString(reader, "msdyn_casesubreasonidname");
            record.PriorityCodeName = TryReadAsString(reader, "prioritycodename");
            record.MsdynComplexityName = TryReadAsString(reader, "msdyn_complexityname");
            record.MsdynCountrySubmitterIdName = TryReadAsString(reader, "msdyn_countrysubmitteridname");
            record.MsdynCountryProcessedIdName = TryReadAsString(reader, "msdyn_countryprocessedidname");
            record.StatusCodeName = TryReadAsString(reader, "statuscodename");
            record.OnHoldTime = TryReadAsString(reader, "onholdtime");

            // If we queried Incident by IncidentId, and ticketnumber exists, prefer using it as TicketNumber for readability.
            if (isGuid)
            {
                var tn = TryReadAsString(reader, "ticketnumber");
                if (!string.IsNullOrWhiteSpace(tn))
                    record.TicketNumber = tn.Trim();
            }

            _logger.LogInformation(
                "CASE_FEATURE_LOOKUP_DONE found=true table=dbo.{Table} ticket={Ticket} createdon={CreatedOn}",
                table.TableName,
                record.TicketNumber,
                record.CreatedOn ?? "");
            return record;
        }
        catch (Exception ex) when (ex is SqlException or InvalidOperationException)
        {
            _logger.LogWarning(ex,
                "Failed to load case features from dbo.{Table} for {TicketNumber}",
                table.TableName,
                ticketNumber);
            return null;
        }
    }

    public async Task<IReadOnlyList<CasePredictionRecord>> TryGetLatestCasePredictionRecordsAsync(
        int count,
        CancellationToken cancellationToken = default)
    {
        count = Math.Clamp(count, 1, 20);
        _logger.LogInformation("CASE_FEATURE_LATEST_START n={N}", count);

        var dbSchema = await _schema.GetSchemaAsync(cancellationToken);
        var table = SelectBestCaseTable(dbSchema, requireCreatedOn: true);
        if (table is null)
        {
            _logger.LogWarning(
                "Cannot load latest case features: no suitable case table discovered in schema allowlist.");
            return Array.Empty<CasePredictionRecord>();
        }

        var cols = (table.Columns ?? new List<ColumnSchema>())
            .Select(c => c.ColumnName)
            .Where(n => !string.IsNullOrWhiteSpace(n))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        if (!cols.Contains("createdon"))
        {
            _logger.LogWarning(
                "Cannot load latest case features: dbo.{Table} missing createdon column.",
                table.TableName);
            return Array.Empty<CasePredictionRecord>();
        }

        // For latest-N, prefer a readable string ticket number if available.
        var ticketCol =
            (cols.Contains("ticketnumber") ? "ticketnumber" : null) ??
            TicketIdStringCandidates.FirstOrDefault(c => cols.Contains(c)) ??
            TicketIdGuidCandidates.FirstOrDefault(c => cols.Contains(c));

        if (string.IsNullOrWhiteSpace(ticketCol))
        {
            _logger.LogWarning(
                "Cannot load latest case features: no ID column found on dbo.{Table}.",
                table.TableName);
            return Array.Empty<CasePredictionRecord>();
        }

        var selectParts = new List<string> { $"[{ticketCol}] AS [TicketNumber]" };
        foreach (var c in DesiredColumns)
        {
            if (cols.Contains(c))
                selectParts.Add($"[{c}] AS [{c}]");
        }

        var sql =
            $"SELECT TOP ({count}) " + string.Join(", ", selectParts) + "\n" +
            $"FROM [dbo].[{table.TableName}] WITH (NOLOCK)\n" +
            "ORDER BY [createdon] DESC";
        _logger.LogDebug("CASE_FEATURE_LATEST_SQL (truncated) {Sql}", LogText.Trunc(sql, 2000));

        await using var connection = await _connections.CreateConnectionAsync(cancellationToken);

        await using var cmd = new SqlCommand(sql, connection)
        {
            CommandTimeout = 30
        };

        var results = new List<CasePredictionRecord>();
        try
        {
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                var record = new CasePredictionRecord
                {
                    TicketNumber = (TryReadAsString(reader, "TicketNumber") ?? "").Trim(),
                    CreatedOn = TryReadAsDateTimeString(reader, "createdon")
                };

                record.MsdynResolvedDate = TryReadAsDateTimeString(reader, "msdyn_resolveddate");
                record.MsdynCaseRocName = TryReadAsString(reader, "msdyn_caserocname");
                record.MsdynBusinessFunctionIdName = TryReadAsString(reader, "msdyn_businessfunctionidname");
                record.MsdynLineOfBusinessIdName = TryReadAsString(reader, "msdyn_lineofbusinessidname");
                record.MsdynProgramIdName = TryReadAsString(reader, "msdyn_programidname");
                record.MsdynCaseTypeIdName = TryReadAsString(reader, "msdyn_casetypeidname");
                record.MsdynCaseSubTypeIdName = TryReadAsString(reader, "msdyn_casesubtypeidname");
                record.MsdynCaseReasonIdName = TryReadAsString(reader, "msdyn_casereasonidname");
                record.MsdynCaseSubReasonIdName = TryReadAsString(reader, "msdyn_casesubreasonidname");
                record.PriorityCodeName = TryReadAsString(reader, "prioritycodename");
                record.MsdynComplexityName = TryReadAsString(reader, "msdyn_complexityname");
                record.MsdynCountrySubmitterIdName = TryReadAsString(reader, "msdyn_countrysubmitteridname");
                record.MsdynCountryProcessedIdName = TryReadAsString(reader, "msdyn_countryprocessedidname");
                record.StatusCodeName = TryReadAsString(reader, "statuscodename");
                record.OnHoldTime = TryReadAsString(reader, "onholdtime");

                if (record.TicketNumber.Length == 0)
                    record.TicketNumber = Guid.NewGuid().ToString();

                results.Add(record);
            }
        }
        catch (Exception ex) when (ex is SqlException or InvalidOperationException)
        {
            _logger.LogWarning(ex,
                "Failed to load latest case features from dbo.{Table}",
                table.TableName);
            return Array.Empty<CasePredictionRecord>();
        }

        _logger.LogInformation("CASE_FEATURE_LATEST_DONE returned={Count} table=dbo.{Table}",
            results.Count,
            table.TableName);
        return results;
    }

    private static TableSchema? FindTable(DatabaseSchema schema, string tableName)
    {
        schema ??= new DatabaseSchema();
        return (schema.Tables ?? new List<TableSchema>()).FirstOrDefault(t =>
            string.Equals(t.SchemaName, "dbo", StringComparison.OrdinalIgnoreCase) &&
            string.Equals(t.TableName, tableName, StringComparison.OrdinalIgnoreCase));
    }

    private static TableSchema? FindTableBySuffix(DatabaseSchema schema, string tableNameSuffix)
    {
        schema ??= new DatabaseSchema();
        tableNameSuffix = (tableNameSuffix ?? "").Trim();
        if (tableNameSuffix.Length == 0) return null;

        return (schema.Tables ?? new List<TableSchema>())
            .FirstOrDefault(t =>
                string.Equals(t.SchemaName, "dbo", StringComparison.OrdinalIgnoreCase) &&
                !string.IsNullOrWhiteSpace(t.TableName) &&
                t.TableName.EndsWith(tableNameSuffix, StringComparison.OrdinalIgnoreCase));
    }

    private static TableSchema? SelectBestCaseTable(DatabaseSchema schema, bool requireCreatedOn)
    {
        schema ??= new DatabaseSchema();
        var tables = (schema.Tables ?? new List<TableSchema>())
            .Where(t => string.Equals(t.SchemaName, "dbo", StringComparison.OrdinalIgnoreCase))
            .ToList();

        // First, try the canonical names and common environment-specific suffix forms.
        var preferred =
            FindTable(schema, "Incident") ??
            FindTableBySuffix(schema, "incident") ??
            FindTable(schema, "Cases") ??
            FindTableBySuffix(schema, "cases");

        if (preferred is not null)
        {
            var preferredCols = (preferred.Columns ?? new List<ColumnSchema>())
                .Select(c => c.ColumnName)
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            var hasId =
                TicketIdStringCandidates.Any(c => preferredCols.Contains(c)) ||
                TicketIdGuidCandidates.Any(c => preferredCols.Contains(c)) ||
                preferredCols.Contains("ticketnumber");

            var hasCreatedOn = preferredCols.Contains("createdon");

            if (hasId && (!requireCreatedOn || hasCreatedOn))
                return preferred;
        }

        if (tables.Count == 0)
            return null;

        // Otherwise, score allowlisted tables based on feature coverage.
        (TableSchema Table, int Score)? best = null;
        foreach (var t in tables)
        {
            var cols = (t.Columns ?? new List<ColumnSchema>())
                .Select(c => c.ColumnName)
                .Where(n => !string.IsNullOrWhiteSpace(n))
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            var hasCreatedOn = cols.Contains("createdon");
            if (requireCreatedOn && !hasCreatedOn)
                continue;

            var hasTicket =
                cols.Contains("ticketnumber") ||
                TicketIdStringCandidates.Any(c => cols.Contains(c)) ||
                TicketIdGuidCandidates.Any(c => cols.Contains(c));
            if (!hasTicket)
                continue;

            var score = 0;
            if (hasCreatedOn) score += 30;
            if (cols.Contains("ticketnumber")) score += 40;

            // Prioritize the required prediction keys and then any additional desired columns.
            if (cols.Contains("msdyn_countryprocessedidname")) score += 20;
            if (cols.Contains("msdyn_businessfunctionidname")) score += 20;
            if (cols.Contains("msdyn_casesubtypeidname")) score += 20;
            if (cols.Contains("msdyn_casesubreasonidname")) score += 20;

            foreach (var c in DesiredColumns)
            {
                if (cols.Contains(c)) score += 5;
            }

            var name = (t.TableName ?? "").ToLowerInvariant();
            if (name.Contains("incident")) score += 15;
            if (name.Contains("case")) score += 5;

            if (best is null || score > best.Value.Score)
                best = (t, score);
        }

        return best?.Table;
    }

    private static string? PickTicketColumn(IReadOnlySet<string> cols, bool isGuid)
    {
        if (cols is null || cols.Count == 0) return null;

        if (isGuid)
        {
            var guidCol = TicketIdGuidCandidates.FirstOrDefault(c => cols.Contains(c));
            if (!string.IsNullOrWhiteSpace(guidCol)) return guidCol;
        }

        var strCol = TicketIdStringCandidates.FirstOrDefault(c => cols.Contains(c));
        if (!string.IsNullOrWhiteSpace(strCol)) return strCol;

        // Fallback: if only guid-like columns exist but the input isn't a guid, return null.
        if (isGuid) return TicketIdGuidCandidates.FirstOrDefault(c => cols.Contains(c));
        return null;
    }

    private static string? TryReadAsString(SqlDataReader reader, string name)
    {
        try
        {
            var ord = reader.GetOrdinal(name);
            if (reader.IsDBNull(ord)) return null;
            return reader.GetValue(ord)?.ToString();
        }
        catch (IndexOutOfRangeException)
        {
            return null;
        }
    }

    private static string? TryReadAsDateTimeString(SqlDataReader reader, string name)
    {
        try
        {
            var ord = reader.GetOrdinal(name);
            if (reader.IsDBNull(ord)) return null;

            var v = reader.GetValue(ord);
            if (v is DateTime dt)
                return dt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
            if (v is DateTimeOffset dto)
                return dto.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
            return v?.ToString();
        }
        catch (IndexOutOfRangeException)
        {
            return null;
        }
    }
}

