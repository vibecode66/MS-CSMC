// ============================================================================
// ConversationOrchestratorService.cs — Turn orchestration + tool routing
//
// This service is the "traffic controller" for a single user turn. It decides
// which internal capability to invoke (schema snapshot, single-shot NL→SQL,
// multi-step agent, or case prediction) and then formats the response into
// one or more bot replies.
//
// Why this exists (design intent):
// - Keep entrypoints (Teams bot + HTTP controllers) thin and deterministic.
// - Centralize routing and policy (when to clarify, when to include steps,
//   when to generate artifacts) so behavior is consistent across channels.
//
// Key dependencies (follow the flow):
// - NL→SQL: `SqlGeneratorService` (`src/SqlCopilot.Core/Services/SqlGeneratorService.cs`)
// - Execution: `QueryExecutionService` (`src/SqlCopilot.Core/Services/QueryExecutionService.cs`)
// - Cards: `AdaptiveCardService` (`src/SqlCopilot.Core/Services/AdaptiveCardService.cs`)
// - Agent: `AgentOrchestratorService` (`src/SqlCopilot.Core/Agent/AgentOrchestratorService.cs`)
// - Prediction: `CasePredictionAgent` + `CasePredictionClient` + `CaseFeatureService`
//
// See also:
// - Developer map: `docs/CODE_TOUR.md`
// - Result envelope: `src/SqlCopilot.Core/Models/ConversationTurnResult.cs`
// ============================================================================

using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using System.Reflection;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Agent;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Services.SqlPromptPolicies;
using SqlCopilot.Core.Tracing;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Orchestrates a single conversation turn: route intent, call tools (DB/prediction/agent),
/// ask clarifying questions only when required inputs are missing, and produce bot replies.
/// </summary>
public sealed class ConversationOrchestratorService : IConversationOrchestratorService
{
    private const string CasePredictionCacheKeyPrefix = "case-prediction:";
    private const string DebugModeCacheKeyPrefix = "debug-mode:";
    private static readonly TimeSpan CasePredictionStateTtl = TimeSpan.FromMinutes(60);
    private static readonly TimeSpan DebugModeTtl = TimeSpan.FromHours(12);
    private static readonly Regex LatestCasesRegex = new(@"\b(latest|most\s+recent)\s+(?<n>\d{1,2})\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex PredictionKeywordRegex = new(@"\b(predict|prediction|estimate|eta|sla)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex CaseKeywordRegex = new(@"\b(case|ticket|incident)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex DetailsKeywordRegex = new(@"\bdetail(s)?\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex MetricKeywordRegex = new(@"\b(percent|percentage|ratio|rate)\b|%", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex ActionKeywordRegex = new(@"\b(action|actions|action\s*type|action\s*group)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex HumanTouchKeywordRegex =
        new(@"\b(human\s*touch|manual\s*touch|automation|automated|without\s+human|no\s+human)\b",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex TrendKeywordRegex =
        new(@"\b(trend|over\s+time|time\s+series|timeseries|weekly|monthly|per\s+week|per\s+month|by\s+week|by\s+month|by\s+day)\b",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private readonly ISchemaDiscoveryService _schemaService;
    private readonly ISqlGeneratorService _sqlGenerator;
    private readonly IQueryExecutionService _queryExecutor;
    private readonly ITicketActionQueryService _ticketActionQuery;
    private readonly IJsonLlmClient _jsonLlm;
    private readonly IAdaptiveCardService _cardService;
    private readonly IResultSupervisorService _resultSupervisor;
    private readonly IAgentOrchestratorService _agent;
    private readonly ICasePredictionClient _casePredictionClient;
    private readonly ICaseFeatureService _caseFeatureService;
    private readonly CasePredictionAgent _casePredictionAgent;
    private readonly IMemoryCache _cache;
    private readonly ILogger<ConversationOrchestratorService> _logger;
    private readonly IConversationTraceSink _trace;
    private readonly bool _slaPredictionEnabled;

    public ConversationOrchestratorService(
        ISchemaDiscoveryService schemaService,
        ISqlGeneratorService sqlGenerator,
        IQueryExecutionService queryExecutor,
        ITicketActionQueryService ticketActionQuery,
        IJsonLlmClient jsonLlm,
        IAdaptiveCardService cardService,
        IResultSupervisorService resultSupervisor,
        IAgentOrchestratorService agent,
        ICasePredictionClient casePredictionClient,
        ICaseFeatureService caseFeatureService,
        CasePredictionAgent casePredictionAgent,
        IOptions<SlaPredictionAccessOptions> slaPredictionAccess,
        IConversationTraceSink trace,
        IMemoryCache cache,
        ILogger<ConversationOrchestratorService> logger)
    {
        _schemaService = schemaService ?? throw new ArgumentNullException(nameof(schemaService));
        _sqlGenerator = sqlGenerator ?? throw new ArgumentNullException(nameof(sqlGenerator));
        _queryExecutor = queryExecutor ?? throw new ArgumentNullException(nameof(queryExecutor));
        _ticketActionQuery = ticketActionQuery ?? throw new ArgumentNullException(nameof(ticketActionQuery));
        _jsonLlm = jsonLlm ?? throw new ArgumentNullException(nameof(jsonLlm));
        _cardService = cardService ?? throw new ArgumentNullException(nameof(cardService));
        _resultSupervisor = resultSupervisor ?? throw new ArgumentNullException(nameof(resultSupervisor));
        _agent = agent ?? throw new ArgumentNullException(nameof(agent));
        _casePredictionClient = casePredictionClient ?? throw new ArgumentNullException(nameof(casePredictionClient));
        _caseFeatureService = caseFeatureService ?? throw new ArgumentNullException(nameof(caseFeatureService));
        _casePredictionAgent = casePredictionAgent ?? throw new ArgumentNullException(nameof(casePredictionAgent));
        _trace = trace ?? throw new ArgumentNullException(nameof(trace));
        var access = (slaPredictionAccess?.Value) ?? new SlaPredictionAccessOptions();
        _slaPredictionEnabled = access.Enabled;
        _cache = cache ?? throw new ArgumentNullException(nameof(cache));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<ConversationTurnResult> HandleAsync(
        string userText,
        string? conversationId,
        CancellationToken cancellationToken = default,
        Func<string, Task>? progress = null,
        string? userAadObjectId = null)
    {
        userText = (userText ?? "").Trim();
        if (userText.Length == 0)
            return ConversationTurnResult.Text("Please enter a question about your data.");

        conversationId = (conversationId ?? "").Trim();
        var turnId = DateTimeOffset.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "-" + Guid.NewGuid().ToString("N")[..6];
        using var scope = _logger.BeginScope(new Dictionary<string, object?>
        {
            ["ConversationId"] = conversationId.Length == 0 ? "<none>" : conversationId,
            ["TurnId"] = turnId
        });

        _logger.LogInformation(
            "TURN_START textChars={Chars} textPreview=\"{Preview}\"",
            userText.Length,
            LogText.OneLine(userText, 220));

        _trace.Step("TURN_START", "orchestrator", outgoing: new { userTextPreview = LogText.OneLine(userText, 220) });

        // Debug toggle (deterministic control command).
        if (TryHandleDebugCommand(userText, conversationId, out var debugToggleResult))
            return debugToggleResult;

        // Keep /refresh deterministic because it's a side-effect tool not exposed to the router.
        if (userText.Equals("/refresh", StringComparison.OrdinalIgnoreCase))
        {
            _logger.LogInformation("TOOL_CALL schema_refresh");
            await _schemaService.RefreshSchemaAsync(cancellationToken);
            return ConversationTurnResult.Text("✅ Database schema cache has been refreshed.");
        }

        var debugEnabled = IsDebugModeEnabled(conversationId);
        DebugContext.Set(new DebugContext(
            Enabled: debugEnabled,
            Emit: progress,
            ConversationId: conversationId,
            TurnId: turnId));

        try
        {
            if (debugEnabled)
            {
                await DebugContext.WriteAsync("Debug mode is ON for this conversation.");
                await DebugContext.WriteAsync($"Question received: {LogText.OneLine(userText, 600)}");
            }

            // Router (LLM) is invoked for every Teams message (except /refresh).
        var observations = new List<string>();
        if (TryGetPendingCasePrediction(conversationId, out _))
            observations.Add("pending_case_prediction_state=true");

        const int maxIterations = 3;

        for (var iter = 0; iter < maxIterations; iter++)
        {
            var prompt = BuildToolRouterPrompt(userText, observations);
            if (debugEnabled)
            {
                await DebugContext.WriteAsync($"Invoking orchestrator router (iteration {iter + 1}/{maxIterations}).");
                await DebugContext.WriteBlockAsync("Router prompt (truncated)", prompt);
            }
            JsonElement decision;
            try
            {
                decision = await _jsonLlm.CallJsonAsync(prompt, cancellationToken);
            }
            catch (JsonException ex)
            {
                _logger.LogWarning(ex, "Router returned non-JSON output; falling back to sql_agent. FirstObs: {Obs}",
                    observations.Count > 0 ? observations[0] : "");
                break;
            }

            var type = decision.TryGetProperty("type", out var t) ? (t.GetString() ?? "") : "";
            type = type.Trim().ToLowerInvariant();
            if (debugEnabled)
                await DebugContext.WriteBlockAsync("Router decision JSON (truncated)", LogText.Json(decision, 3500));
            _logger.LogInformation(
                "ROUTER_DECISION iter={Iter} type={Type} json={Json}",
                iter + 1,
                type,
                LogText.Json(decision, 900));

            _trace.Step("ROUTE_DECISION", "router", outgoing: new { iteration = iter + 1 }, incoming: new { decision = LogText.Json(decision, 1500) });

            if (type != "tool")
            {
                observations.Add($"Router output type '{type}' is not supported. Return type='tool' only.");
                continue;
            }

            var tool = decision.TryGetProperty("name", out var n) ? (n.GetString() ?? "") : "";
            tool = tool.Trim().ToLowerInvariant();
            var args = decision.TryGetProperty("arguments", out var a) ? a : default;
            _logger.LogInformation(
                "TOOL_SELECTED name={Tool} args={Args}",
                tool,
                args.ValueKind == JsonValueKind.Undefined ? "<none>" : LogText.Json(args, 900));

            if (debugEnabled)
            {
                var dbg = decision.TryGetProperty("debug", out var d) ? LogText.Json(d, 1200) : "<none>";
                await DebugContext.WriteAsync($"Next step selected: {tool}");
                await DebugContext.WriteBlockAsync("Router debug (truncated)", dbg);
            }

            switch (tool)
            {
                case "help":
                    return ConversationTurnResult.Attachment(_cardService.CreateWelcomeCard());

                case "schema_snapshot":
                    return await HandleSchemaSnapshotAsync(cancellationToken);

                case "sql_query":
                    return await HandleSqlQueryAsync(userText, args, cancellationToken, progress);

                case "sql_agent":
                    return await HandleSqlAgentAsync(userText, cancellationToken, progress);

                case "case_prediction":
                    return await HandleCasePredictionAsync(userText, args, conversationId, cancellationToken, userAadObjectId);

                default:
                    observations.Add($"Unknown tool '{tool}'.");
                    continue;
            }
        }

        // Router did not produce a usable plan; fallback to the multi-step agent.
        return await HandleSqlAgentAsync(userText, cancellationToken, progress);
        }
        finally
        {
            DebugContext.Clear();
        }
    }

    private bool IsDebugModeEnabled(string? conversationId)
    {
        conversationId = (conversationId ?? "").Trim();
        if (conversationId.Length == 0) return false;
        return _cache.TryGetValue(DebugModeCacheKeyPrefix + conversationId, out bool enabled) && enabled;
    }

    private void SetDebugMode(string? conversationId, bool enabled)
    {
        conversationId = (conversationId ?? "").Trim();
        if (conversationId.Length == 0) return;
        _cache.Set(DebugModeCacheKeyPrefix + conversationId, enabled, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = DebugModeTtl
        });
    }

    private bool TryHandleDebugCommand(string userText, string? conversationId, out ConversationTurnResult result)
    {
        result = default!;
        var text = (userText ?? "").Trim();
        if (text.Length == 0) return false;

        // Supported:
        // /debug on | /debug off | /debug status | /debug
        // debug on  | debug off  | debug status  | debug
        var lower = text.ToLowerInvariant();
        if (!lower.StartsWith("/debug") && !lower.StartsWith("debug"))
            return false;

        var parts = lower.Replace("/", "").Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (parts.Length == 0 || parts[0] != "debug")
            return false;

        var hasConversation = !string.IsNullOrWhiteSpace((conversationId ?? "").Trim());
        if (!hasConversation)
        {
            result = ConversationTurnResult.Text("Debug mode is only available in Teams conversations (missing conversation id).");
            return true;
        }

        var current = IsDebugModeEnabled(conversationId);
        var arg = parts.Length >= 2 ? parts[1] : "";

        if (arg is "on" or "enable" or "enabled" or "true" or "1")
        {
            SetDebugMode(conversationId, true);
            result = ConversationTurnResult.Text("Debug mode enabled for this conversation.");
            return true;
        }
        if (arg is "off" or "disable" or "disabled" or "false" or "0")
        {
            SetDebugMode(conversationId, false);
            result = ConversationTurnResult.Text("Debug mode disabled for this conversation.");
            return true;
        }
        if (arg is "status" or "state")
        {
            result = ConversationTurnResult.Text($"Debug mode is currently {(current ? "ON" : "OFF")} for this conversation.");
            return true;
        }

        // Toggle by default.
        SetDebugMode(conversationId, !current);
        result = ConversationTurnResult.Text($"Debug mode {(current ? "disabled" : "enabled")} for this conversation.");
        return true;
    }

    private static bool TryParseLatestCasesForPrediction(string userText, out int count)
    {
        count = 0;
        var q = (userText ?? "").Trim();
        if (q.Length == 0) return false;

        var lower = q.ToLowerInvariant();
        var looksLikePredict = PredictionKeywordRegex.IsMatch(q);
        var looksLikeCase = CaseKeywordRegex.IsMatch(q);
        if (!looksLikePredict || !looksLikeCase) return false;

        if (!lower.Contains("latest") && !lower.Contains("most recent"))
            return false;

        var m = LatestCasesRegex.Match(q);
        if (!m.Success) return false;

        if (!int.TryParse(m.Groups["n"].Value, out var n)) return false;
        count = Math.Clamp(n, 1, 20);
        return true;
    }

    private static bool TryParseLatestCasesForDetails(string userText, out int count)
    {
        count = 0;
        var q = (userText ?? "").Trim();
        if (q.Length == 0) return false;

        // Explicitly avoid prediction paths.
        if (PredictionKeywordRegex.IsMatch(q)) return false;

        if (!DetailsKeywordRegex.IsMatch(q)) return false;
        if (!CaseKeywordRegex.IsMatch(q)) return false;

        var lower = q.ToLowerInvariant();
        if (!lower.Contains("latest") && !lower.Contains("most recent"))
            return false;

        var m = LatestCasesRegex.Match(q);
        if (!m.Success) return false;

        if (!int.TryParse(m.Groups["n"].Value, out var n)) return false;
        count = Math.Clamp(n, 1, 20);
        return true;
    }

    private static bool LooksLikeTicketNumberPrediction(string userText)
    {
        userText ??= "";
        return PredictionKeywordRegex.IsMatch(userText) && TicketNumberRegex.IsMatch(userText);
    }

    private static bool ShouldForceSqlQueryForMetric(string userText)
    {
        var q = (userText ?? "").Trim();
        if (q.Length == 0) return false;

        // Keep scope narrow: only case/ticket questions about human touch/automation.
        if (!CaseKeywordRegex.IsMatch(q))
        {
            var lowerNoCase = q.ToLowerInvariant();
            // Users sometimes omit the word "case" but still ask "last N resolved/closed ... without human touch".
            if (!lowerNoCase.Contains("resolved") && !lowerNoCase.Contains("closed"))
                return false;
        }
        if (!HumanTouchKeywordRegex.IsMatch(q)) return false;

        // Trend/time-series questions benefit from the multi-step agent.
        if (TrendKeywordRegex.IsMatch(q)) return false;

        // If it explicitly asks for a metric, or a simple count/number, use sql_query.
        if (MetricKeywordRegex.IsMatch(q)) return true;

        var lower = q.ToLowerInvariant();
        return lower.Contains("how many") || lower.Contains("count") || lower.Contains("number of");
    }

    private async Task<ConversationTurnResult> HandleLatestCaseDetailsAsync(int count, CancellationToken ct)
    {
        count = Math.Clamp(count, 1, 20);
        _logger.LogInformation("CASE_DETAILS_LATEST_START n={N}", count);

        var records = await _caseFeatureService.TryGetLatestCasePredictionRecordsAsync(count, ct);
        if (records.Count == 0)
        {
            _logger.LogWarning("CASE_DETAILS_LATEST_EMPTY n={N}", count);
            return ConversationTurnResult.Text(
                $"I couldn't load the latest {count} tickets from the database. " +
                "Try providing a specific case number/ID instead.");
        }

        static string? Str(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

        var cols = new List<QueryColumn>
        {
            new() { Name = "TicketNumber", DataType = "nvarchar" },
            new() { Name = "createdon", DataType = "nvarchar" },
            new() { Name = "msdyn_countryprocessedidname", DataType = "nvarchar" },
            new() { Name = "msdyn_businessfunctionidname", DataType = "nvarchar" },
            new() { Name = "msdyn_casesubtypeidname", DataType = "nvarchar" },
            new() { Name = "msdyn_casesubreasonidname", DataType = "nvarchar" },
            new() { Name = "prioritycodename", DataType = "nvarchar" },
            new() { Name = "statuscodename", DataType = "nvarchar" }
        };

        var rows = records.Select(r => new Dictionary<string, object?>
        {
            ["TicketNumber"] = Str(r.TicketNumber),
            ["createdon"] = Str(r.CreatedOn),
            ["msdyn_countryprocessedidname"] = Str(r.MsdynCountryProcessedIdName),
            ["msdyn_businessfunctionidname"] = Str(r.MsdynBusinessFunctionIdName),
            ["msdyn_casesubtypeidname"] = Str(r.MsdynCaseSubTypeIdName),
            ["msdyn_casesubreasonidname"] = Str(r.MsdynCaseSubReasonIdName),
            ["prioritycodename"] = Str(r.PriorityCodeName),
            ["statuscodename"] = Str(r.StatusCodeName)
        }).ToList();

        var result = new QueryResult
        {
            IsSuccess = true,
            SqlQuery = "-- loaded from database (latest ticket details)",
            Columns = cols,
            Rows = rows,
            TotalRowCount = rows.Count,
            IsTruncated = false,
            ExecutionTime = TimeSpan.Zero
        };

        var sqlResponse = new NL2SqlResponse
        {
            IsSuccess = true,
            GeneratedSql = "-- loaded from database (latest ticket details)",
            Explanation = $"Loaded latest {rows.Count} ticket records from the database.",
            SuggestedChart = ChartType.Table
        };

        _logger.LogInformation("CASE_DETAILS_LATEST_DONE n={N} returned={Count}", count, rows.Count);
        return ConversationTurnResult.Attachment(_cardService.CreateResultCard(result, sqlResponse));
    }

    private async Task<ConversationTurnResult> HandleSchemaSnapshotAsync(CancellationToken ct)
    {
        try
        {
            var schema = await _schemaService.GetSchemaAsync(ct);
            var full = schema.ToSchemaSnapshot(includeSampleData: false);
            var chunks = SplitSchemaIntoChunks(full, 3500);
            var isTruncated = full.Contains("(truncated)", StringComparison.OrdinalIgnoreCase);

            var replies = new List<BotReply>();
            for (var i = 0; i < chunks.Count; i++)
            {
                var schemaCard = _cardService.CreateAgentSchemaCard(
                    source: "azure_sql",
                    schemaText: chunks[i],
                    partNumber: i + 1,
                    totalParts: chunks.Count,
                    isTruncated: isTruncated);
                replies.Add(new BotReply(Attachment: schemaCard));
            }

            return new ConversationTurnResult(replies);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "SCHEMA_SNAPSHOT_FAILED error={Error}", ex.Message);
            return ConversationTurnResult.Attachment(
                _cardService.CreateErrorCard($"Schema snapshot failed: {ex.Message}"));
        }
    }

    private async Task<ConversationTurnResult> HandleSqlQueryAsync(
        string userText,
        JsonElement args,
        CancellationToken ct,
        Func<string, Task>? progress = null)
    {
        var nlq =
            args.ValueKind == JsonValueKind.Object &&
            args.TryGetProperty("question", out var q) &&
            q.ValueKind == JsonValueKind.String
                ? (q.GetString() ?? "").Trim()
                : userText;

        if (nlq.Length == 0)
            return ConversationTurnResult.Text("What would you like to know about the case data?");

        _logger.LogInformation("SQL_QUERY_START questionPreview=\"{Question}\"",
            LogText.OneLine(nlq, 220));

        try
        {
            if (TryParseTicketActionIntent(nlq, out var ticketNumber))
            {
                if (progress is not null)
                    await progress("Working on it — loading actions for the ticket directly from the database…");

                var deterministic = await _ticketActionQuery.ExecuteTicketActionsAsync(ticketNumber, ct);
                if (!deterministic.IsSuccess)
                {
                    var err = (deterministic.ErrorMessage ?? "Could not load ticket actions.").Trim();
                    return ConversationTurnResult.Text(err.Length == 0 ? "Could not load ticket actions." : err);
                }

                var deterministicSqlResponse = new NL2SqlResponse
                {
                    IsSuccess = true,
                    GeneratedSql = TicketActionQueryService.DisplaySql,
                    Explanation = $"Loaded classified case actions for ticket {ticketNumber} using the deterministic ticket-action query.",
                    SuggestedChart = ChartType.Table,
                    IsReadOnly = true
                };

                _logger.LogInformation(
                    "SQL_QUERY_TICKET_ACTION_DONE ticket={Ticket} rows={Rows}",
                    ticketNumber,
                    deterministic.TotalRowCount);

                if (ShouldShowTicketActionDetails(nlq))
                    return ConversationTurnResult.Attachment(_cardService.CreateResultCard(deterministic, deterministicSqlResponse));

                var pieResult = BuildTicketActionPieResult(deterministic);
                var breakdownResult = BuildTicketActionTypeBreakdownResult(deterministic);

                var pieSqlResponse = new NL2SqlResponse
                {
                    IsSuccess = true,
                    GeneratedSql = TicketActionQueryService.DisplaySql,
                    Explanation = $"AI vs Human action split for ticket {ticketNumber}.",
                    SuggestedChart = ChartType.Pie,
                    IsReadOnly = true
                };

                var breakdownSqlResponse = new NL2SqlResponse
                {
                    IsSuccess = true,
                    GeneratedSql = TicketActionQueryService.DisplaySql,
                    Explanation = $"Action type breakdown for ticket {ticketNumber}, split by AI and Human actions.",
                    SuggestedChart = ChartType.HorizontalBar,
                    IsReadOnly = true
                };

                return new ConversationTurnResult(new[]
                {
                    new BotReply(Attachment: _cardService.CreateResultCard(pieResult, pieSqlResponse)),
                    new BotReply(Attachment: _cardService.CreateResultCard(breakdownResult, breakdownSqlResponse))
                });
            }

            var schema = await _schemaService.GetSchemaAsync(ct);
            var currentQuestion = nlq;

            // Debug-only: ask an LLM for a simple execution plan (no SQL).
            if (DebugContext.IsEnabled())
            {
                try
                {
                    var planPrompt = BuildDebugSqlQueryPlanPrompt(schema, currentQuestion);
                    await DebugContext.WriteAsync("sql_query: planning (LLM).");
                    await DebugContext.WriteBlockAsync("sql_query plan prompt (truncated)", LogText.Trunc(planPrompt, 3500));
                    var planEl = await _jsonLlm.CallJsonAsync(planPrompt, ct);
                    await DebugContext.WriteBlockAsync("sql_query plan JSON (truncated)", LogText.Json(planEl, 3500));
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    await DebugContext.WriteAsync($"sql_query planning skipped due to error: {LogText.OneLine(ex.Message, 240)}");
                }
            }

            var (sqlResponse, queryResult) = await _sqlGenerator.GenerateAndValidateAsync(
                currentQuestion,
                schema,
                _queryExecutor,
                ct);

            queryResult ??= new QueryResult
            {
                IsSuccess = false,
                ErrorMessage = (sqlResponse.ErrorMessage ?? sqlResponse.Explanation ?? "Could not generate a query for that request.").Trim(),
                SqlQuery = (sqlResponse.GeneratedSql ?? "").Trim(),
                Columns = new List<QueryColumn>(),
                Rows = new List<Dictionary<string, object?>>(),
                TotalRowCount = 0,
                IsTruncated = false,
                ExecutionTime = TimeSpan.Zero
            };

            static bool LooksLikeChartRequest(string text)
            {
                var t = (text ?? "").ToLowerInvariant();
                return t.Contains("chart") || t.Contains("plot") || t.Contains("graph") || t.Contains("trend") || t.Contains("over time")
                       || t.Contains("per week") || t.Contains("per month") || t.Contains("weekly") || t.Contains("monthly");
            }

            static bool LooksLikeMetricRequest(string text)
            {
                var t = (text ?? "").ToLowerInvariant();
                return t.Contains("percent") || t.Contains("percentage") || t.Contains("%")
                       || t.Contains("ratio") || t.Contains("rate");
            }

            var shouldInvokeSupervisor =
                !queryResult.IsSuccess ||
                queryResult.Rows.Count == 0 ||
                sqlResponse.SuggestedChart != ChartType.Table ||
                LooksLikeChartRequest(currentQuestion) ||
                LooksLikeMetricRequest(currentQuestion) ||
                queryResult.ResultType == QueryResultType.Kpi;

            // Supervisor loop: validate result + choose best visualization (or request a rerun/escalation).
            const int maxSupervisorIterations = 2;
            var maxReruns = 1;
            var reruns = 0;
            var progressSent = false;

            string? lastUserNote = null;
            string? lastReason = null;
            var chartOverridden = false;

            async Task SendProgressAsync(string message)
            {
                if (progress is null || progressSent) return;
                progressSent = true;
                try
                {
                    message = (message ?? "").Trim();
                    if (message.Length == 0) return;
                    await progress(message);
                }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    _logger.LogWarning(ex, "PROGRESS_SEND_FAILED {Error}", ex.Message);
                }
            }

            // Some KPI questions (human-touch/automation %) are prone to subtle logic bugs; allow one extra correction pass.
            if (LooksLikeMetricRequest(currentQuestion))
            {
                var t = currentQuestion.ToLowerInvariant();
                if (t.Contains("human") || t.Contains("touch") || t.Contains("automation") || t.Contains("automated"))
                    maxReruns = 2;
            }

            if (shouldInvokeSupervisor)
            {
                for (var iter = 1; iter <= maxSupervisorIterations; iter++)
                {
                    ResultSupervisorDecision decision;
                    try
                    {
                        _logger.LogInformation(
                            "RESULT_SUPERVISOR_START iter={Iter} reruns={Reruns} success={Success} rows={Rows} cols={Cols} suggestedChart={Chart}",
                            iter,
                            reruns,
                            queryResult.IsSuccess,
                            queryResult.Rows.Count,
                            queryResult.Columns.Count,
                            sqlResponse.SuggestedChart);

                        decision = await _resultSupervisor.DecideAsync(
                            userQuery: currentQuestion,
                            schema: schema,
                            sqlResponse: sqlResponse,
                            queryResult: queryResult,
                            cancellationToken: ct);
                    }
                    catch (Exception ex) when (ex is not OperationCanceledException)
                    {
                        _logger.LogWarning(ex, "RESULT_SUPERVISOR_ERROR {Error}", ex.Message);
                        break; // fall back to default behavior
                    }

                    if (!string.IsNullOrWhiteSpace(decision.UserNote))
                        lastUserNote = decision.UserNote.Trim();
                    if (!string.IsNullOrWhiteSpace(decision.Reason))
                        lastReason = decision.Reason.Trim();

                    if (decision.Action == ResultSupervisorAction.Clarify)
                    {
                        var clarify = (decision.ClarifyQuestion ?? "").Trim();
                        if (clarify.Length == 0)
                            clarify = "Can you clarify what you want to see in the results?";
                        _trace.Step("SUPERVISOR_DECISION", "result_supervisor",
                            outgoing: new { action = "clarify" },
                            incoming: new { clarifyQuestion = clarify });
                        return ConversationTurnResult.Text(clarify);
                    }

                    if (decision.Action == ResultSupervisorAction.UseSqlAgent)
                    {
                        await SendProgressAsync("Working on it — running a deeper analysis…");
                        _logger.LogInformation(
                            "RESULT_SUPERVISOR_ESCALATE reason=\"{Reason}\"",
                            LogText.OneLine(decision.Reason, 240));
                        _trace.Step("SUPERVISOR_DECISION", "result_supervisor",
                            outgoing: new { action = "use_sql_agent" },
                            incoming: new { reason = LogText.OneLine(decision.Reason, 500) });
                        return await HandleSqlAgentAsync(currentQuestion, ct);
                    }

                    if (decision.Action == ResultSupervisorAction.RerunSqlQuery)
                    {
                        var updated = (decision.UpdatedQuestion ?? "").Trim();
                        if (reruns >= maxReruns ||
                            updated.Length == 0 ||
                            updated.Equals(currentQuestion, StringComparison.OrdinalIgnoreCase))
                        {
                            _logger.LogWarning(
                                "RESULT_SUPERVISOR_RERUN_SKIPPED reruns={Reruns} updatedLen={Len}",
                                reruns,
                                updated.Length);
                            break;
                        }

                        await SendProgressAsync("Working on it — validating results and choosing the best visualization…");

                        reruns++;
                        currentQuestion = updated;
                        _trace.Step("SUPERVISOR_DECISION", "result_supervisor",
                            outgoing: new { action = "rerun_sql_query", reruns },
                            incoming: new { updatedQuestion = LogText.OneLine(updated, 800) });
                        _logger.LogInformation(
                            "RESULT_SUPERVISOR_RERUN_APPLY reruns={Reruns} updatedPreview=\"{Updated}\"",
                            reruns,
                            LogText.OneLine(updated, 220));

                        (sqlResponse, queryResult) = await _sqlGenerator.GenerateAndValidateAsync(
                            currentQuestion,
                            schema,
                            _queryExecutor,
                            ct);

                        queryResult ??= new QueryResult
                        {
                            IsSuccess = false,
                            ErrorMessage = (sqlResponse.ErrorMessage ?? sqlResponse.Explanation ?? "Could not generate a query for that request.").Trim(),
                            SqlQuery = (sqlResponse.GeneratedSql ?? "").Trim(),
                            Columns = new List<QueryColumn>(),
                            Rows = new List<Dictionary<string, object?>>(),
                            TotalRowCount = 0,
                            IsTruncated = false,
                            ExecutionTime = TimeSpan.Zero
                        };

                        // Continue the loop so the supervisor can decide on the rerun output.
                        continue;
                    }

                    // Render: override chart type if provided, then stop.
                    if (decision.Action == ResultSupervisorAction.Render && decision.ChartType is not null)
                    {
                        var before = sqlResponse.SuggestedChart;
                        sqlResponse.SuggestedChart = decision.ChartType.Value;
                        chartOverridden = decision.ChartType.Value != before;
                    }

                    break;
                }
            }

            // Only surface supervisor notes when it actually changed the flow (rerun, override, or error).
            if (!string.IsNullOrWhiteSpace(lastUserNote))
            {
                var shouldShowNote = reruns > 0 || chartOverridden || !queryResult.IsSuccess;
                if (shouldShowNote)
                {
                    var baseExpl = (sqlResponse.Explanation ?? "").Trim();
                    sqlResponse.Explanation = baseExpl.Length == 0
                        ? lastUserNote
                        : baseExpl + "\n\n" + lastUserNote;
                }
            }

            if (!queryResult.IsSuccess)
            {
                var msg = (lastUserNote ?? "").Trim();
                if (msg.Length == 0) msg = (lastReason ?? "").Trim();
                if (msg.Length == 0) msg = (queryResult.ErrorMessage ?? "").Trim();
                if (msg.Length == 0) msg = (sqlResponse.ErrorMessage ?? sqlResponse.Explanation ?? "Query failed.").Trim();
                if (msg.Length == 0) msg = "Query failed. Please try rephrasing your question.";

                _logger.LogInformation("SQL_QUERY_DONE success=false errorPreview=\"{Error}\"",
                    LogText.OneLine(msg, 220));
                return ConversationTurnResult.Text(msg);
            }

            var card = _cardService.CreateResultCard(queryResult, sqlResponse);

            _logger.LogInformation(
                "SQL_QUERY_DONE success=true rows={Rows} cols={Cols}",
                queryResult.TotalRowCount,
                queryResult.Columns.Count);

            return ConversationTurnResult.Attachment(card);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex,
                "SQL_QUERY_FAILED error={Error}",
                ex.Message);
            return ConversationTurnResult.Text($"SQL query failed: {ex.Message}");
        }
    }

    private async Task<ConversationTurnResult> HandleSqlAgentAsync(
        string userText,
        CancellationToken ct,
        Func<string, Task>? progress = null)
    {
        _logger.LogInformation("SQL_AGENT_START textPreview=\"{Preview}\"", LogText.OneLine(userText, 220));
        SqlCopilot.Core.Agent.AgentRunResult agentResult;
        try
        {
            if (progress is not null)
                await progress("Working on it - running a deeper analysis...");

            agentResult = await _agent.RunAsync(userText, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogError(ex, "SQL_AGENT_FAILED error={Error}", ex.Message);
            return ConversationTurnResult.Attachment(
                _cardService.CreateErrorCard($"SQL agent failed: {ex.Message}"));
        }
        _logger.LogInformation("SQL_AGENT_DONE mode={Mode} steps={Steps} hasReport={HasReport}",
            agentResult.Mode,
            agentResult.Steps?.Count ?? 0,
            agentResult.Report is not null);

        if (agentResult.Payload is SqlCopilot.Core.Agent.AgentSchemaInfo schemaInfo)
        {
            var full = (schemaInfo.Preview ?? "").Trim();
            var chunks = SplitSchemaIntoChunks(full, 3500);
            var isTruncated = full.Contains("(truncated)", StringComparison.OrdinalIgnoreCase);

            var replies = new List<BotReply>();
            for (var i = 0; i < chunks.Count; i++)
            {
                var schemaCard = _cardService.CreateAgentSchemaCard(
                    source: schemaInfo.Source,
                    schemaText: chunks[i],
                    partNumber: i + 1,
                    totalParts: chunks.Count,
                    isTruncated: isTruncated);
                replies.Add(new BotReply(Attachment: schemaCard));
            }
            return new ConversationTurnResult(replies);
        }

        var outs = new List<BotReply>();
        var includeAllSteps = ShouldIncludeAgentSteps(userText);
        var allSteps = agentResult.Steps ?? Array.Empty<SqlCopilot.Core.Agent.AgentStepResult>();
        var stepsToSend = includeAllSteps
            ? allSteps
            : SelectRelevantAgentSteps(allSteps);

        foreach (var step in stepsToSend)
        {
            Attachment stepCard = step.QueryResult.IsSuccess
                ? _cardService.CreateResultCard(step.QueryResult, step.SqlResponse)
                : _cardService.CreateErrorCard(step.QueryResult.ErrorMessage ?? "Step failed.");
            outs.Add(new BotReply(Attachment: stepCard));
        }

        var stepSql = allSteps
            .Select(s => (s.Name, s.SqlResponse.GeneratedSql))
            .Where(s => !string.IsNullOrWhiteSpace(s.GeneratedSql))
            .Select(s => (s.Name, s.GeneratedSql!.Trim()))
            .ToList();

        outs.Add(new BotReply(Attachment: _cardService.CreateAgentSummaryCard(
            userQuery: agentResult.UserQuery,
            summary: agentResult.Summary,
            steps: stepSql)));

        if (includeAllSteps &&
            ShouldIncludeAgentReportArtifacts(userText) &&
            agentResult.Report is not null &&
            (!string.IsNullOrWhiteSpace(agentResult.Report.PdfUrl) ||
             !string.IsNullOrWhiteSpace(agentResult.Report.HtmlUrl) ||
             (agentResult.Report.ChartImageUrls?.Count ?? 0) > 0))
        {
            outs.Add(new BotReply(Attachment: _cardService.CreateAgentReportCard(agentResult.Report)));
        }

        return new ConversationTurnResult(outs);
    }

    private static IReadOnlyList<SqlCopilot.Core.Agent.AgentStepResult> SelectRelevantAgentSteps(
        IReadOnlyList<SqlCopilot.Core.Agent.AgentStepResult> steps)
    {
        steps ??= Array.Empty<SqlCopilot.Core.Agent.AgentStepResult>();
        if (steps.Count == 0) return steps;

        // Prefer chartable steps (agent already computed ChartUrl when chart is relevant).
        var chartSteps = steps
            .Where(s => s.QueryResult.IsSuccess && !string.IsNullOrWhiteSpace(s.ChartUrl))
            .Take(2)
            .ToList();

        if (chartSteps.Count > 0)
            return chartSteps;

        // Fallback: send the first successful step (usually enough context) to avoid spamming.
        var firstOk = steps.FirstOrDefault(s => s.QueryResult.IsSuccess);
        return firstOk is null ? Array.Empty<SqlCopilot.Core.Agent.AgentStepResult>() : new[] { firstOk };
    }

    private static bool ShouldIncludeAgentSteps(string userText)
    {
        var t = (userText ?? "").Trim().ToLowerInvariant();
        if (t.Length == 0) return false;

        // Only include step-by-step cards when user explicitly asks.
        return t.Contains("show steps") ||
               t.Contains("show step") ||
               t.Contains("show the steps") ||
               t.Contains("include steps") ||
               t.Contains("show sql") ||
               t.Contains("show queries") ||
               t.Contains("show charts") ||
               t.Contains("include charts") ||
               t.Contains("detailed") ||
               t.Contains("full details");
    }

    private static bool ShouldIncludeAgentReportArtifacts(string userText)
    {
        var t = (userText ?? "").Trim().ToLowerInvariant();
        if (t.Length == 0) return false;

        return t.Contains("report") ||
               t.Contains("pdf") ||
               t.Contains("download") ||
               t.Contains("artifacts");
    }

    private async Task<ConversationTurnResult> HandleCasePredictionAsync(
        string userText,
        JsonElement args,
        string? conversationId,
        CancellationToken ct,
        string? userAadObjectId)
    {
        try
        {
            if (!_slaPredictionEnabled)
                return ConversationTurnResult.Text("SLA prediction is currently disabled.");

            _logger.LogInformation(
                "CASE_PREDICTION_START textPreview=\"{Preview}\" args={Args}",
                LogText.OneLine(userText, 220),
                args.ValueKind == JsonValueKind.Undefined ? "<none>" : LogText.Json(args, 900));

            // Special-case: "latest N cases" prediction (batch) — fetch N latest and call LightGBM once.
            if (TryParseLatestCasesForPrediction(userText, out var latestCount) &&
                !TryGetTicketNumberFromArgs(args, out _) &&
                !TryGetRecordFromArgs(args, out _))
            {
                _logger.LogInformation("CASE_PREDICTION_BATCH_LATEST_START n={N}", latestCount);
                var records = await _caseFeatureService.TryGetLatestCasePredictionRecordsAsync(
                    latestCount,
                    ct);

                if (records.Count == 0)
                {
                    _logger.LogWarning("CASE_PREDICTION_BATCH_LATEST_EMPTY n={N}", latestCount);
                    return ConversationTurnResult.Text(
                        $"I couldn't load the latest {latestCount} cases from the database. " +
                        "Try providing a specific case number/ID, or paste the record JSON like `api.txt`.");
                }

                var resolved = records.Where(r => r is not null && !string.IsNullOrWhiteSpace(r.MsdynResolvedDate)).ToList();
                var unresolved = records.Where(r => r is not null && string.IsNullOrWhiteSpace(r.MsdynResolvedDate)).ToList();

                if (unresolved.Count == 0)
                {
                    _logger.LogInformation(
                        "CASE_PREDICTION_BATCH_LATEST_SKIP allResolved=true count={Count}",
                        records.Count);
                    var resolvedCards = records
                        .Where(r => r is not null && !string.IsNullOrWhiteSpace(r.MsdynResolvedDate))
                        .Select(r =>
                        {
                            var ticket = (r!.TicketNumber ?? "").Trim();
                            var resolvedAt = (r.MsdynResolvedDate ?? "").Trim();
                            var features = BuildCasePredictionFeatureSummary(r, source: $"Loaded from database (latest {records.Count})");
                            return new BotReply(Attachment: _cardService.CreateCaseResolvedCard(ticket, resolvedAt, features));
                        })
                        .ToList();

                    if (resolvedCards.Count == 0)
                        return ConversationTurnResult.Text("All of the latest cases are already resolved.");

                    return new ConversationTurnResult(resolvedCards);
                }

                if (resolved.Count > 0)
                {
                    _logger.LogInformation(
                        "CASE_PREDICTION_BATCH_LATEST_SKIP resolvedCount={Resolved} unresolvedCount={Unresolved}",
                        resolved.Count,
                        unresolved.Count);
                }

                var missingCols = FindMissingRequiredForBatch(unresolved);
                if (missingCols.Count > 0)
                {
                    _logger.LogWarning(
                        "CASE_PREDICTION_BATCH_LATEST_MISSING requiredMissing={Missing} count={Count}",
                        string.Join(",", missingCols),
                        unresolved.Count);
                    return ConversationTurnResult.Text(
                        "I loaded the latest cases, but required prediction fields are missing for at least one record: " +
                        string.Join(", ", missingCols) + ". " +
                        "Please provide those fields (or paste a full record like `api.txt`).");
                }

                _logger.LogInformation("LGBM_CALL batch=true records={Count}", unresolved.Count);
                var apiResponseBatch = await _casePredictionClient.PredictAsync(
                    new CasePredictionInvokeRequest
                    {
                        MaxReturnRows = unresolved.Count,
                        UploadOutput = false,
                        Records = unresolved.ToList()
                    },
                    ct);

                var modelBlobBatch = apiResponseBatch.Artifacts?.ModelBlob;
                _logger.LogInformation(
                    "LGBM_DONE batch=true status={Status} previewRows={Rows} modelBlob={ModelBlob}",
                    apiResponseBatch.Status ?? "",
                    apiResponseBatch.Preview?.Count ?? 0,
                    modelBlobBatch ?? "");
                var predictedByCaseId = (apiResponseBatch.Preview ?? new List<CasePredictionPreviewRow>())
                    .Where(r => !string.IsNullOrWhiteSpace(r.CaseId))
                    .ToDictionary(
                        r => (r.CaseId ?? "").Trim(),
                        r => (r.PredictedResolutionDt ?? "").Trim(),
                        StringComparer.OrdinalIgnoreCase);

                var replies = new List<BotReply>();
                foreach (var r in records)
                {
                    if (r is null) continue;
                    var key = (r.TicketNumber ?? "").Trim();

                    if (!string.IsNullOrWhiteSpace(r.MsdynResolvedDate))
                    {
                        var resolvedAt = (r.MsdynResolvedDate ?? "").Trim();
                        var features = BuildCasePredictionFeatureSummary(r, source: $"Loaded from database (latest {records.Count})");
                        replies.Add(new BotReply(Attachment: _cardService.CreateCaseResolvedCard(
                            ticketNumber: key,
                            resolvedDateTime: resolvedAt,
                            featuresSummary: features)));
                        continue;
                    }

                    predictedByCaseId.TryGetValue(key, out var pred);
                    pred = string.IsNullOrWhiteSpace(pred) ? null : pred;

                    _logger.LogInformation(
                        "CASE_PREDICTION_RESULT ticket={Ticket} predicted={Predicted}",
                        key,
                        pred ?? "");
                    replies.Add(new BotReply(Attachment: _cardService.CreateCasePredictionCard(
                        ticketNumber: (r.TicketNumber ?? "").Trim(),
                        predictedResolutionDateTime: pred,
                        modelBlob: modelBlobBatch,
                        featuresSummary: $"Loaded from database (latest {records.Count}).")));
                }

                _logger.LogInformation("CASE_PREDICTION_BATCH_LATEST_DONE n={N}", latestCount);
                return new ConversationTurnResult(replies);
            }

            CasePredictionRecord? pendingRecord = null;
            if (TryGetPendingCasePrediction(conversationId, out var pending))
                pendingRecord = pending.PartialRecord;

            CasePredictionRecord? providedRecord = null;
            if (TryGetRecordFromArgs(args, out var r1) || TryExtractRecordFromText(userText, out r1))
                providedRecord = r1;
            else if (TryGetTicketNumberFromArgs(args, out var tn))
                providedRecord = new CasePredictionRecord { TicketNumber = tn };
            else
            {
                // If the router didn't pass arguments, still try to seed TicketNumber from the user's text
                // so DB enrichment can run for ticket-only prediction prompts.
                var m = TicketNumberRegex.Match(userText ?? "");
                if (m.Success && PredictionKeywordRegex.IsMatch(userText ?? ""))
                    providedRecord = new CasePredictionRecord { TicketNumber = m.Value.Trim() };
            }

            // Merge: pending <- provided
            if (pendingRecord is not null && providedRecord is not null)
                MergePredictionRecord(target: pendingRecord, source: providedRecord);

            var baseRecord = providedRecord ?? pendingRecord;

            static bool Blank(string? s) => string.IsNullOrWhiteSpace(s);
            var relyingOnDbForRequired =
                providedRecord is not null &&
                !Blank(providedRecord.TicketNumber) &&
                Blank(providedRecord.CreatedOn) &&
                Blank(providedRecord.MsdynCountryProcessedIdName) &&
                Blank(providedRecord.MsdynBusinessFunctionIdName) &&
                Blank(providedRecord.MsdynCaseSubTypeIdName) &&
                Blank(providedRecord.MsdynCaseSubReasonIdName);

            var attemptedDbEnrichment = false;
            var enrichedFromDb = false;

            // Best-effort: if a ticket number is present, load required prediction fields from the DB.
            if (baseRecord is not null &&
                !string.IsNullOrWhiteSpace(baseRecord.TicketNumber) &&
                PredictionNeedsDbEnrichment(baseRecord))
            {
                attemptedDbEnrichment = true;
                var ticket = (baseRecord.TicketNumber ?? "").Trim();
                _logger.LogInformation(
                    "CASE_ENRICH_START ticket={Ticket}",
                    ticket);
                var fromDb = await _caseFeatureService.TryGetCasePredictionRecordAsync(
                    ticket,
                    ct);
                if (fromDb is not null)
                {
                    enrichedFromDb = true;
                    _logger.LogInformation(
                        "CASE_ENRICH_DONE found=true createdon={CreatedOn} roc={Roc} subtype={Subtype} subreason={SubReason} countryProcessed={CountryProcessed} businessFunction={BusinessFunction}",
                        fromDb.CreatedOn ?? "",
                        fromDb.MsdynCaseRocName ?? "",
                        fromDb.MsdynCaseSubTypeIdName ?? "",
                        fromDb.MsdynCaseSubReasonIdName ?? "",
                        fromDb.MsdynCountryProcessedIdName ?? "",
                        fromDb.MsdynBusinessFunctionIdName ?? "");
                    MergePredictionRecord(target: baseRecord, source: fromDb);
                }
                else
                {
                    _logger.LogWarning("CASE_ENRICH_DONE found=false ticket={Ticket}",
                        (baseRecord.TicketNumber ?? "").Trim());
                }
            }

            if (baseRecord is not null &&
                !string.IsNullOrWhiteSpace(baseRecord.TicketNumber) &&
                !string.IsNullOrWhiteSpace(baseRecord.MsdynResolvedDate))
            {
                var ticket = (baseRecord.TicketNumber ?? "").Trim();
                var resolvedAt = (baseRecord.MsdynResolvedDate ?? "").Trim();
                _logger.LogInformation(
                    "CASE_PREDICTION_SKIP_RESOLVED ticket={Ticket} resolveddate={ResolvedDate}",
                    ticket,
                    resolvedAt);
                var features = BuildCasePredictionFeatureSummary(baseRecord, source: "Loaded from database (ticket lookup)");
                return ConversationTurnResult.Attachment(_cardService.CreateCaseResolvedCard(
                    ticketNumber: ticket,
                    resolvedDateTime: resolvedAt,
                    featuresSummary: features));
            }

            var decision = await _casePredictionAgent.DecideAsync(
                userText: userText ?? "",
                pendingRecord: baseRecord,
                nowUtc: DateTimeOffset.UtcNow,
                cancellationToken: ct);
            _logger.LogInformation(
                "CASE_PREDICTION_DECISION type={Type} missing={Missing}",
                decision.Type,
                decision.Missing is null ? "" : string.Join(",", decision.Missing));

            if (decision.Type == "clarify")
            {
                var partial = decision.PartialRecord ?? baseRecord ?? new CasePredictionRecord();
                SetPendingCasePrediction(conversationId, partial, decision.Missing ?? Array.Empty<string>());

                var q = (decision.Question ?? "").Trim();
                if (q.Length == 0)
                    q = "Please provide the missing case details so I can run prediction.";

                if (attemptedDbEnrichment && !enrichedFromDb && relyingOnDbForRequired)
                {
                    var ticket = (baseRecord?.TicketNumber ?? "").Trim();
                    var missing = (decision.Missing ?? Array.Empty<string>()).ToList();
                    if (missing.Count == 0)
                        missing = new List<string>
                        {
                            "createdon",
                            "msdyn_countryprocessedidname",
                            "msdyn_businessfunctionidname",
                            "msdyn_casesubtypeidname",
                            "msdyn_casesubreasonidname"
                        };

                    static string Friendly(string? key)
                    {
                        var k = (key ?? "").Trim();
                        var lower = k.ToLowerInvariant();
                        return lower switch
                        {
                            "createdon" => "case creation date/time (createdon)",
                            "msdyn_countryprocessedidname" => "processing country/region",
                            "msdyn_businessfunctionidname" => "business function",
                            "msdyn_casesubtypeidname" => "case subtype",
                            "msdyn_casesubreasonidname" => "case subreason",
                            _ => k.Length == 0 ? "missing field" : k
                        };
                    }

                    var missingText = string.Join(", ", missing.Select(Friendly));
                    q = ticket.Length > 0
                        ? $"I couldn't find ticket {ticket} in the database. Please provide: {missingText}."
                        : $"I couldn't find that ticket in the database. Please provide: {missingText}.";
                }

                return ConversationTurnResult.Text(q);
            }

            var record = decision.Record ?? baseRecord ?? new CasePredictionRecord();
            ClearPendingCasePrediction(conversationId);

            _logger.LogInformation(
                "LGBM_CALL batch=false ticket={Ticket} createdon={CreatedOn} roc={Roc} subtype={Subtype} subreason={SubReason} countryProcessed={CountryProcessed} businessFunction={BusinessFunction}",
                (record.TicketNumber ?? "").Trim(),
                record.CreatedOn ?? "",
                record.MsdynCaseRocName ?? "",
                record.MsdynCaseSubTypeIdName ?? "",
                record.MsdynCaseSubReasonIdName ?? "",
                record.MsdynCountryProcessedIdName ?? "",
                record.MsdynBusinessFunctionIdName ?? "");
            var apiResponse = await _casePredictionClient.PredictAsync(
                new CasePredictionInvokeRequest
                {
                    MaxReturnRows = 1,
                    UploadOutput = false,
                    Records = new List<CasePredictionRecord> { record }
                },
                ct);

            var predicted = apiResponse.Preview?.FirstOrDefault()?.PredictedResolutionDt;
            var modelBlob = apiResponse.Artifacts?.ModelBlob;
            _logger.LogInformation(
                "LGBM_DONE batch=false status={Status} predicted={Predicted} modelBlob={ModelBlob}",
                apiResponse.Status ?? "",
                predicted ?? "",
                modelBlob ?? "");

            var featuresSummary =
                enrichedFromDb
                    ? BuildCasePredictionFeatureSummary(record, source: "Loaded from database (ticket lookup)")
                    : BuildCasePredictionFeatureSummary(record, source: "Extracted from message");

            return ConversationTurnResult.Attachment(_cardService.CreateCasePredictionCard(
                ticketNumber: (record.TicketNumber ?? "").Trim(),
                predictedResolutionDateTime: predicted,
                modelBlob: modelBlob,
                featuresSummary: featuresSummary));
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "Case prediction failed: {Error}", ex.Message);
            return ConversationTurnResult.Attachment(_cardService.CreateErrorCard($"Case prediction failed: {ex.Message}"));
        }
    }

    private static IReadOnlyList<string> FindMissingRequiredForBatch(IReadOnlyList<CasePredictionRecord> records)
    {
        records ??= Array.Empty<CasePredictionRecord>();

        static bool Blank(string? s) => string.IsNullOrWhiteSpace(s);

        var missing = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var r in records)
        {
            if (r is null) continue;
            if (Blank(r.CreatedOn)) missing.Add("createdon");
            if (Blank(r.MsdynCountryProcessedIdName)) missing.Add("msdyn_countryprocessedidname");
            if (Blank(r.MsdynBusinessFunctionIdName)) missing.Add("msdyn_businessfunctionidname");
            if (Blank(r.MsdynCaseSubTypeIdName)) missing.Add("msdyn_casesubtypeidname");
            if (Blank(r.MsdynCaseSubReasonIdName)) missing.Add("msdyn_casesubreasonidname");
        }

        return missing.OrderBy(s => s).ToList();
    }

    private static string BuildCasePredictionFeatureSummary(CasePredictionRecord record, string source)
    {
        record ??= new CasePredictionRecord();
        source = (source ?? "").Trim();

        static string? Val(string? s)
        {
            s = (s ?? "").Trim();
            return s.Length == 0 ? null : s;
        }

        void Add(List<string> parts, string label, string? value)
        {
            value = Val(value);
            if (value is null) return;
            parts.Add($"{label}={value}");
        }

        var parts = new List<string>();
        Add(parts, "createdon", record.CreatedOn);
        Add(parts, "processed", record.MsdynCountryProcessedIdName);
        Add(parts, "businessFunction", record.MsdynBusinessFunctionIdName);
        Add(parts, "subtype", record.MsdynCaseSubTypeIdName);
        Add(parts, "subreason", record.MsdynCaseSubReasonIdName);

        // Helpful extras (best-effort, keep compact)
        Add(parts, "roc", record.MsdynCaseRocName);
        Add(parts, "priority", record.PriorityCodeName);
        Add(parts, "complexity", record.MsdynComplexityName);
        Add(parts, "status", record.StatusCodeName);
        Add(parts, "resolveddate", record.MsdynResolvedDate);

        var joined = parts.Count == 0 ? "—" : string.Join("; ", parts);
        var prefix = source.Length == 0 ? "" : source + ": ";
        return LogText.Trunc(prefix + joined, 900);
    }

    private static void MergePredictionRecord(CasePredictionRecord target, CasePredictionRecord source)
    {
        if (target is null) throw new ArgumentNullException(nameof(target));
        if (source is null) throw new ArgumentNullException(nameof(source));

        static bool Blank(string? s) => string.IsNullOrWhiteSpace(s);

        if (Blank(target.TicketNumber) && !Blank(source.TicketNumber))
            target.TicketNumber = source.TicketNumber.Trim();

        if (Blank(target.CreatedOn) && !Blank(source.CreatedOn))
            target.CreatedOn = source.CreatedOn!.Trim();

        if (Blank(target.MsdynCaseRocName) && !Blank(source.MsdynCaseRocName))
            target.MsdynCaseRocName = source.MsdynCaseRocName;
        if (Blank(target.MsdynBusinessFunctionIdName) && !Blank(source.MsdynBusinessFunctionIdName))
            target.MsdynBusinessFunctionIdName = source.MsdynBusinessFunctionIdName;
        if (Blank(target.MsdynLineOfBusinessIdName) && !Blank(source.MsdynLineOfBusinessIdName))
            target.MsdynLineOfBusinessIdName = source.MsdynLineOfBusinessIdName;
        if (Blank(target.MsdynProgramIdName) && !Blank(source.MsdynProgramIdName))
            target.MsdynProgramIdName = source.MsdynProgramIdName;
        if (Blank(target.MsdynCaseTypeIdName) && !Blank(source.MsdynCaseTypeIdName))
            target.MsdynCaseTypeIdName = source.MsdynCaseTypeIdName;
        if (Blank(target.MsdynCaseSubTypeIdName) && !Blank(source.MsdynCaseSubTypeIdName))
            target.MsdynCaseSubTypeIdName = source.MsdynCaseSubTypeIdName;
        if (Blank(target.MsdynCaseReasonIdName) && !Blank(source.MsdynCaseReasonIdName))
            target.MsdynCaseReasonIdName = source.MsdynCaseReasonIdName;
        if (Blank(target.MsdynCaseSubReasonIdName) && !Blank(source.MsdynCaseSubReasonIdName))
            target.MsdynCaseSubReasonIdName = source.MsdynCaseSubReasonIdName;
        if (Blank(target.PriorityCodeName) && !Blank(source.PriorityCodeName))
            target.PriorityCodeName = source.PriorityCodeName;
        if (Blank(target.MsdynComplexityName) && !Blank(source.MsdynComplexityName))
            target.MsdynComplexityName = source.MsdynComplexityName;
        if (Blank(target.MsdynCountrySubmitterIdName) && !Blank(source.MsdynCountrySubmitterIdName))
            target.MsdynCountrySubmitterIdName = source.MsdynCountrySubmitterIdName;
        if (Blank(target.MsdynCountryProcessedIdName) && !Blank(source.MsdynCountryProcessedIdName))
            target.MsdynCountryProcessedIdName = source.MsdynCountryProcessedIdName;
        if (Blank(target.StatusCodeName) && !Blank(source.StatusCodeName))
            target.StatusCodeName = source.StatusCodeName;
        if (Blank(target.OnHoldTime) && !Blank(source.OnHoldTime))
            target.OnHoldTime = source.OnHoldTime;

        if (Blank(target.MsdynResolvedDate) && !Blank(source.MsdynResolvedDate))
            target.MsdynResolvedDate = source.MsdynResolvedDate;
    }

    private sealed record PendingCasePredictionState(
        CasePredictionRecord PartialRecord,
        IReadOnlyList<string> Missing,
        DateTimeOffset UpdatedUtc);

    private bool TryGetPendingCasePrediction(string? conversationId, out PendingCasePredictionState state)
    {
        state = new PendingCasePredictionState(new CasePredictionRecord(), Array.Empty<string>(), DateTimeOffset.MinValue);
        conversationId = (conversationId ?? "").Trim();
        if (conversationId.Length == 0) return false;

        var key = CasePredictionCacheKeyPrefix + conversationId;
        if (!_cache.TryGetValue(key, out PendingCasePredictionState? cached) || cached is null)
            return false;

        state = cached;
        return true;
    }

    private void SetPendingCasePrediction(string? conversationId, CasePredictionRecord partial, IReadOnlyList<string> missing)
    {
        conversationId = (conversationId ?? "").Trim();
        if (conversationId.Length == 0) return;

        partial ??= new CasePredictionRecord();
        missing ??= Array.Empty<string>();

        // Store a defensive copy so later merges don't mutate the cached instance unexpectedly.
        var copy = new CasePredictionRecord
        {
            TicketNumber = partial.TicketNumber,
            CreatedOn = partial.CreatedOn,
            MsdynCaseRocName = partial.MsdynCaseRocName,
            MsdynBusinessFunctionIdName = partial.MsdynBusinessFunctionIdName,
            MsdynLineOfBusinessIdName = partial.MsdynLineOfBusinessIdName,
            MsdynProgramIdName = partial.MsdynProgramIdName,
            MsdynCaseTypeIdName = partial.MsdynCaseTypeIdName,
            MsdynCaseSubTypeIdName = partial.MsdynCaseSubTypeIdName,
            MsdynCaseReasonIdName = partial.MsdynCaseReasonIdName,
            MsdynCaseSubReasonIdName = partial.MsdynCaseSubReasonIdName,
            PriorityCodeName = partial.PriorityCodeName,
            MsdynComplexityName = partial.MsdynComplexityName,
            MsdynCountrySubmitterIdName = partial.MsdynCountrySubmitterIdName,
            MsdynCountryProcessedIdName = partial.MsdynCountryProcessedIdName,
            StatusCodeName = partial.StatusCodeName,
            OnHoldTime = partial.OnHoldTime,
            MsdynResolvedDate = partial.MsdynResolvedDate
        };

        var normMissing = missing
            .Where(s => !string.IsNullOrWhiteSpace(s))
            .Select(s => s.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var st = new PendingCasePredictionState(copy, normMissing, DateTimeOffset.UtcNow);
        var key = CasePredictionCacheKeyPrefix + conversationId;
        _cache.Set(key, st, new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = CasePredictionStateTtl
        });
    }

    private void ClearPendingCasePrediction(string? conversationId)
    {
        conversationId = (conversationId ?? "").Trim();
        if (conversationId.Length == 0) return;
        _cache.Remove(CasePredictionCacheKeyPrefix + conversationId);
    }

    // ------------------------ Router prompt ------------------------
    private const string RouterPromptResourceName = "SqlCopilot.Core.Prompts.OrchestratorRouterPrompt.txt";

    private static readonly Lazy<string> RouterPromptTemplate = new(LoadRouterPromptTemplate);

    private static string LoadRouterPromptTemplate()
    {
        try
        {
            var asm = typeof(ConversationOrchestratorService).Assembly;
            using var stream = asm.GetManifestResourceStream(RouterPromptResourceName);
            if (stream is null)
                return "";
            using var reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }
        catch
        {
            return "";
        }
    }

    private static string BuildToolRouterPrompt(string userQuery, List<string> observations)
    {
        var template = RouterPromptTemplate.Value ?? "";
        if (template.Trim().Length == 0)
            template = "Output JSON only: {\"type\":\"tool\",\"name\":\"sql_agent\",\"arguments\":{},\"debug\":{\"decision\":\"route 4\",\"why\":\"router prompt missing\",\"next\":\"run sql_agent\"}}";

        var obs = observations.Count == 0 ? "(none)" : string.Join("\n", observations.TakeLast(6));
        return template
            .Replace("{{OBSERVATIONS_OR_(none)}}", obs)
            .Replace("{{USER_MESSAGE}}", userQuery ?? "");
    }

    private static string BuildDebugSqlQueryPlanPrompt(DatabaseSchema schema, string userQuery)
    {
        // Keep this prompt small-ish; it's debug-only and should not generate SQL.
        // Include the same case-domain policy used by SQL generation so the plan matches project logic.
        var policy = CaseDomainSqlPolicy.For(schema);
        var schemaText = LogText.Trunc(schema.ToSchemaSnapshot(includeSampleData: false), 6000);
        userQuery = (userQuery ?? "").Trim();

        return
            "You are a DEBUG PLANNER for a Text-to-SQL assistant.\n" +
            "Your task is to explain a simple, step-by-step plan for how to answer the user question using the database.\n" +
            "Do NOT write SQL. Do NOT answer the question.\n\n" +
            "IMPORTANT:\n" +
            "- Use ONLY tables/columns that appear in the DATABASE SCHEMA below.\n" +
            "- Do NOT invent columns (e.g., do not guess fields like incidentstagecode/origincode unless they appear in the schema).\n" +
            "- Follow the CASE-DOMAIN SQL POLICY below (it defines joins and the 'without human touch' logic).\n\n" +
            "Return ONLY valid JSON with this shape:\n" +
            "{\n" +
            "  \"steps\": [\n" +
            "    {\"step\":1,\"what\":\"...\",\"tables\":[\"dbo.table\"],\"joins\":[\"a=b\"],\"notes\":\"...\"}\n" +
            "  ]\n" +
            "}\n\n" +
            "Guidance:\n" +
            "- Use 3-7 steps.\n" +
            "- Mention the key tables, join keys, filters, and aggregation strategy.\n" +
            "- If the question is a KPI/percent, explicitly state the numerator and denominator and any excluded cohorts.\n" +
            "- If the policy indicates that some cases may have missing evidence, include an evidence-coverage step and define the denominator accordingly.\n\n" +
            "CASE-DOMAIN SQL POLICY:\n" +
            policy +
            "\n\n" +
            "DATABASE SCHEMA (truncated):\n" +
            schemaText +
            "\n\nUSER QUESTION:\n" +
            userQuery;
    }

    // ------------------------ Prediction helpers (moved from bot) ------------------------
    private static readonly Regex TicketNumberRegex = new(@"\b\d-\d{5,}\b", RegexOptions.Compiled);

    private static bool TryParseCasePredictionIntent(string userQuery, out string ticketNumber)
    {
        ticketNumber = "";
        var q = (userQuery ?? "").Trim();
        if (q.Length == 0) return false;

        var lower = q.ToLowerInvariant();
        var looksLikePredict =
            lower.Contains("predict") ||
            lower.Contains("prediction") ||
            lower.Contains("estimate") ||
            lower.Contains("eta");

        var looksLikeCase =
            lower.Contains("case") ||
            lower.Contains("ticket");

        if (!looksLikePredict || !looksLikeCase)
            return false;

        var m = TicketNumberRegex.Match(q);
        if (!m.Success) return false;

        ticketNumber = m.Value.Trim();
        return ticketNumber.Length > 0;
    }

    private static bool TryParseTicketActionIntent(string userQuery, out string ticketNumber)
    {
        ticketNumber = "";
        var q = (userQuery ?? "").Trim();
        if (q.Length == 0) return false;

        // Prediction/ETA/SLA questions with a ticket number must stay on the
        // case_prediction route and never fall into the deterministic action path.
        if (PredictionKeywordRegex.IsMatch(q)) return false;

        var m = TicketNumberRegex.Match(q);
        if (!m.Success) return false;

        var lower = q.ToLowerInvariant();
        var looksLikeActionQuery =
            ActionKeywordRegex.IsMatch(q) ||
            HumanTouchKeywordRegex.IsMatch(q) ||
            lower.Contains(" ai ") ||
            lower.Contains("human");

        if (!looksLikeActionQuery) return false;

        ticketNumber = m.Value.Trim();
        return ticketNumber.Length > 0;
    }

    private static bool ShouldShowTicketActionDetails(string userQuery)
    {
        var q = (userQuery ?? "").ToLowerInvariant();
        return q.Contains("detail") ||
               q.Contains("list") ||
               q.Contains("table") ||
               q.Contains("raw") ||
               q.Contains("each action") ||
               q.Contains("all actions") ||
               q.Contains("show rows");
    }

    private static QueryResult BuildTicketActionPieResult(QueryResult detailed)
    {
        detailed ??= new QueryResult();
        var rows = detailed.Rows ?? new List<Dictionary<string, object?>>();

        long ai = 0;
        long human = 0;

        foreach (var row in rows)
        {
            var kind = GetStringValue(row, "AIHuman");
            if (string.Equals(kind, "AI", StringComparison.OrdinalIgnoreCase)) ai++;
            else if (string.Equals(kind, "Human", StringComparison.OrdinalIgnoreCase)) human++;
        }

        var pieRows = new List<Dictionary<string, object?>>();
        if (ai > 0) pieRows.Add(new Dictionary<string, object?> { ["AIHuman"] = "AI", ["ActionCount"] = ai });
        if (human > 0) pieRows.Add(new Dictionary<string, object?> { ["AIHuman"] = "Human", ["ActionCount"] = human });

        return new QueryResult
        {
            IsSuccess = true,
            SqlQuery = detailed.SqlQuery,
            Columns = new List<QueryColumn>
            {
                new() { Name = "AIHuman", DataType = "nvarchar" },
                new() { Name = "ActionCount", DataType = "int" }
            },
            Rows = pieRows,
            TotalRowCount = pieRows.Count,
            IsTruncated = false,
            ExecutionTime = detailed.ExecutionTime
        };
    }

    private static QueryResult BuildTicketActionTypeBreakdownResult(QueryResult detailed)
    {
        detailed ??= new QueryResult();
        var rows = detailed.Rows ?? new List<Dictionary<string, object?>>();

        var counts = new Dictionary<string, (long AI, long Human)>(StringComparer.OrdinalIgnoreCase);

        foreach (var row in rows)
        {
            var actionType = GetStringValue(row, "msdyn_actiontype");
            if (string.IsNullOrWhiteSpace(actionType))
                actionType = "(blank)";

            counts.TryGetValue(actionType, out var current);
            var kind = GetStringValue(row, "AIHuman");
            if (string.Equals(kind, "AI", StringComparison.OrdinalIgnoreCase))
                current.AI++;
            else if (string.Equals(kind, "Human", StringComparison.OrdinalIgnoreCase))
                current.Human++;
            counts[actionType] = current;
        }

        var breakdownRows = counts
            .OrderByDescending(kvp => kvp.Value.AI + kvp.Value.Human)
            .ThenBy(kvp => kvp.Key, StringComparer.OrdinalIgnoreCase)
            .Select(kvp => new Dictionary<string, object?>
            {
                ["ActionType"] = kvp.Key,
                ["AI"] = kvp.Value.AI,
                ["Human"] = kvp.Value.Human
            })
            .ToList();

        return new QueryResult
        {
            IsSuccess = true,
            SqlQuery = detailed.SqlQuery,
            Columns = new List<QueryColumn>
            {
                new() { Name = "ActionType", DataType = "nvarchar" },
                new() { Name = "AI", DataType = "int" },
                new() { Name = "Human", DataType = "int" }
            },
            Rows = breakdownRows,
            TotalRowCount = breakdownRows.Count,
            IsTruncated = false,
            ExecutionTime = detailed.ExecutionTime
        };
    }

    private static string GetStringValue(Dictionary<string, object?> row, string key)
    {
        row ??= new Dictionary<string, object?>();
        foreach (var kvp in row)
        {
            if (string.Equals(kvp.Key, key, StringComparison.OrdinalIgnoreCase))
                return (kvp.Value?.ToString() ?? "").Trim();
        }

        return "";
    }

    private static bool TryGetRecordFromArgs(JsonElement args, out CasePredictionRecord record)
    {
        record = new CasePredictionRecord();
        if (args.ValueKind != JsonValueKind.Object) return false;

        if (args.TryGetProperty("record", out var recEl) && TryParseRecordElement(recEl, out record))
            return true;

        if (args.TryGetProperty("records", out var recordsEl) && recordsEl.ValueKind == JsonValueKind.Array)
        {
            var first = recordsEl.EnumerateArray().FirstOrDefault();
            if (first.ValueKind != JsonValueKind.Undefined && TryParseRecordElement(first, out record))
                return true;
        }

        return false;
    }

    private static bool TryGetTicketNumberFromArgs(JsonElement args, out string ticketNumber)
    {
        ticketNumber = "";
        if (args.ValueKind != JsonValueKind.Object) return false;

        if (args.TryGetProperty("ticketNumber", out var tn) && tn.ValueKind == JsonValueKind.String)
        {
            ticketNumber = (tn.GetString() ?? "").Trim();
            return ticketNumber.Length > 0;
        }

        if (args.TryGetProperty("TicketNumber", out var tn2) && tn2.ValueKind == JsonValueKind.String)
        {
            ticketNumber = (tn2.GetString() ?? "").Trim();
            return ticketNumber.Length > 0;
        }

        return false;
    }

    private static bool PredictionNeedsDbEnrichment(CasePredictionRecord record)
    {
        static bool Blank(string? s) => string.IsNullOrWhiteSpace(s);
        return Blank(record.CreatedOn) ||
               Blank(record.MsdynCountryProcessedIdName) ||
               Blank(record.MsdynBusinessFunctionIdName) ||
               Blank(record.MsdynCaseSubTypeIdName) ||
               Blank(record.MsdynCaseSubReasonIdName);
    }

    private static bool TryExtractRecordFromText(string text, out CasePredictionRecord record)
    {
        record = new CasePredictionRecord();
        text ??= "";

        if (TryExtractRecordFromExcel(text, out record))
            return true;

        var start = text.IndexOf('{');
        var end = text.LastIndexOf('}');
        if (start < 0 || end <= start) return false;

        var slice = text.Substring(start, end - start + 1);
        try
        {
            using var doc = JsonDocument.Parse(slice);
            var root = doc.RootElement;

            if (root.ValueKind == JsonValueKind.Object &&
                root.TryGetProperty("records", out var recs) &&
                recs.ValueKind == JsonValueKind.Array)
            {
                var first = recs.EnumerateArray().FirstOrDefault();
                return TryParseRecordElement(first, out record);
            }

            return TryParseRecordElement(root, out record);
        }
        catch
        {
            return false;
        }
    }

    private static bool TryExtractRecordFromExcel(string text, out CasePredictionRecord record)
    {
        record = new CasePredictionRecord();
        text ??= "";

        if (!text.Contains('\t') && !text.Contains('\n') && !text.Contains('\r'))
            return false;

        var lines = text
            .Replace("\r\n", "\n")
            .Replace('\r', '\n')
            .Split('\n')
            .Select(l => (l ?? "").TrimEnd())
            .Where(l => !string.IsNullOrWhiteSpace(l))
            .ToList();

        if (lines.Count < 2)
            return false;

        var known = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "TicketNumber",
            "createdon",
            "msdyn_caserocname",
            "msdyn_businessfunctionidname",
            "msdyn_lineofbusinessidname",
            "msdyn_programidname",
            "msdyn_casetypeidname",
            "msdyn_casesubtypeidname",
            "msdyn_casereasonidname",
            "msdyn_casesubreasonidname",
            "prioritycodename",
            "msdyn_complexityname",
            "msdyn_countrysubmitteridname",
            "msdyn_countryprocessedidname",
            "statuscodename",
            "onholdtime"
        };

        // Teams often wraps pasted tables across multiple lines and replaces tabs with spaces.
        // We'll collect header cells from the first contiguous block of lines that contain
        // recognized header names, then collect value cells from subsequent lines until
        // we have enough values.
        var headerCells = new List<string>();
        var valueCells = new List<string>();

        var idx = 0;
        for (; idx < lines.Count; idx++)
        {
            var cells = SplitExcelCells(lines[idx]);
            var hasKnownHeader = cells
                .Select(NormalizeHeader)
                .Any(k => !string.IsNullOrWhiteSpace(k) && known.Contains(k));

            if (!hasKnownHeader)
                break;

            headerCells.AddRange(cells);
        }

        if (headerCells.Count < 2)
            return false;

        var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        // Collect values from the remaining lines until we have enough.
        for (; idx < lines.Count && valueCells.Count < headerCells.Count; idx++)
        {
            valueCells.AddRange(SplitExcelCells(lines[idx]));
        }

        if (valueCells.Count < 2)
            return false;

        for (var i = 0; i < Math.Min(headerCells.Count, valueCells.Count); i++)
        {
            var k = NormalizeHeader(headerCells[i]);
            if (string.IsNullOrWhiteSpace(k) || !known.Contains(k)) continue;
            map[k] = (valueCells[i] ?? "").Trim();
        }

        string? get(string k) => map.TryGetValue(k, out var v) ? v : null;

        record.TicketNumber = (get("TicketNumber") ?? "").Trim();
        record.CreatedOn = NullIfBlank(get("createdon"));
        record.MsdynCaseRocName = NullIfBlank(get("msdyn_caserocname"));
        record.MsdynBusinessFunctionIdName = NullIfBlank(get("msdyn_businessfunctionidname"));
        record.MsdynLineOfBusinessIdName = NullIfBlank(get("msdyn_lineofbusinessidname"));
        record.MsdynProgramIdName = NullIfBlank(get("msdyn_programidname"));
        record.MsdynCaseTypeIdName = NullIfBlank(get("msdyn_casetypeidname"));
        record.MsdynCaseSubTypeIdName = NullIfBlank(get("msdyn_casesubtypeidname"));
        record.MsdynCaseReasonIdName = NullIfBlank(get("msdyn_casereasonidname"));
        record.MsdynCaseSubReasonIdName = NullIfBlank(get("msdyn_casesubreasonidname"));
        record.PriorityCodeName = NullIfBlank(get("prioritycodename"));
        record.MsdynComplexityName = NullIfBlank(get("msdyn_complexityname"));
        record.MsdynCountrySubmitterIdName = NullIfBlank(get("msdyn_countrysubmitteridname"));
        record.MsdynCountryProcessedIdName = NullIfBlank(get("msdyn_countryprocessedidname"));
        record.StatusCodeName = NullIfBlank(get("statuscodename"));
        record.OnHoldTime = NullIfBlank(get("onholdtime"));

        return true;
    }

    private static List<string> SplitExcelCells(string line)
    {
        line ??= "";
        line = line.Trim();
        if (line.Length == 0) return new List<string>();

        if (line.Contains('\t'))
            return line.Split('\t').Select(s => (s ?? "").Trim()).Where(s => s.Length > 0).ToList();

        // CSV-like
        if (line.Contains(','))
            return line.Split(',').Select(s => (s ?? "").Trim()).Where(s => s.Length > 0).ToList();

        // Space-aligned tables (Teams wraps tabs into multiple spaces)
        var parts = Regex.Split(line, @"\s{2,}")
            .Select(s => (s ?? "").Trim())
            .Where(s => s.Length > 0)
            .ToList();

        return parts.Count > 0 ? parts : new List<string> { line };
    }

    private static string NormalizeHeader(string header)
    {
        header = (header ?? "").Trim();
        if (header.Length == 0) return "";
        var compact = new string(header.Where(ch => ch is not ' ' and not '_' and not '-').ToArray());
        if (compact.Equals("ticketnumber", StringComparison.OrdinalIgnoreCase)) return "TicketNumber";
        return header.Trim();
    }

    private static string? NullIfBlank(string? s)
    {
        s = (s ?? "").Trim();
        return s.Length == 0 ? null : s;
    }

    private static bool TryParseRecordElement(JsonElement el, out CasePredictionRecord record)
    {
        record = new CasePredictionRecord();
        if (el.ValueKind != JsonValueKind.Object) return false;

        string? get(string name)
            => el.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

        record.TicketNumber = (get("TicketNumber") ?? get("ticketNumber") ?? "").Trim();
        record.CreatedOn = get("createdon");
        record.MsdynCaseRocName = get("msdyn_caserocname");
        record.MsdynBusinessFunctionIdName = get("msdyn_businessfunctionidname");
        record.MsdynLineOfBusinessIdName = get("msdyn_lineofbusinessidname");
        record.MsdynProgramIdName = get("msdyn_programidname");
        record.MsdynCaseTypeIdName = get("msdyn_casetypeidname");
        record.MsdynCaseSubTypeIdName = get("msdyn_casesubtypeidname");
        record.MsdynCaseReasonIdName = get("msdyn_casereasonidname");
        record.MsdynCaseSubReasonIdName = get("msdyn_casesubreasonidname");
        record.PriorityCodeName = get("prioritycodename");
        record.MsdynComplexityName = get("msdyn_complexityname");
        record.MsdynCountrySubmitterIdName = get("msdyn_countrysubmitteridname");
        record.MsdynCountryProcessedIdName = get("msdyn_countryprocessedidname");
        record.StatusCodeName = get("statuscodename");
        record.OnHoldTime = get("onholdtime");
        return true;
    }

    private sealed record PlannedCaseSql(string Type, string Sql, string Message);

    private async Task<PlannedCaseSql> PlanCasePredictionSqlAsync(string userQuery, CancellationToken ct)
    {
        var schema = await _schemaService.GetSchemaAsync(ct);
        var schemaText = schema.ToSchemaPrompt();

        var prompt =
            "You are preparing a SQL Server (T-SQL) query to fetch ONE case record for SLA prediction.\n\n" +
            "Return ONLY valid JSON of one of these forms:\n" +
            "1) {\"type\":\"sql\",\"sql\":\"...\"}\n" +
            "2) {\"type\":\"clarify\",\"question\":\"...\"}\n\n" +
            "Rules for the SQL:\n" +
            "- Must be a single read-only SELECT (or WITH ... SELECT).\n" +
            "- Must return TOP (1) row.\n" +
            "- Must alias output columns EXACTLY as these names (even if computed):\n" +
            "  TicketNumber, createdon, msdyn_caserocname, msdyn_businessfunctionidname, msdyn_lineofbusinessidname, msdyn_programidname,\n" +
            "  msdyn_casetypeidname, msdyn_casesubtypeidname, msdyn_casereasonidname, msdyn_casesubreasonidname,\n" +
            "  prioritycodename, msdyn_complexityname, msdyn_countrysubmitteridname, msdyn_countryprocessedidname, statuscodename, onholdtime\n" +
            "- Use ONLY tables/columns in the provided DATABASE SCHEMA.\n" +
            "- If a value is not available in the schema, return an empty string '' for that alias.\n" +
            "- If the user message does not uniquely identify a case (no ticket id, no clear filter like \"latest\"), ask a clarify question.\n" +
            "- If user asks \"latest\"/\"most recent\", order by createdon desc.\n\n" +
            "DATABASE SCHEMA:\n" + schemaText + "\n\n" +
            "USER MESSAGE:\n" + userQuery + "\n";

        var el = await _jsonLlm.CallJsonAsync(prompt, ct);
        var type = el.TryGetProperty("type", out var t) ? (t.GetString() ?? "") : "";
        type = type.Trim().ToLowerInvariant();

        if (type == "clarify")
        {
            var q = el.TryGetProperty("question", out var qq) ? (qq.GetString() ?? "") : "";
            q = q.Trim();
            if (q.Length == 0)
                q = "Which case should I predict? Paste the record JSON (like `api.txt`) or specify a clear filter.";
            return new PlannedCaseSql("clarify", "", q);
        }

        var sql = el.TryGetProperty("sql", out var s) ? (s.GetString() ?? "") : "";
        sql = sql.Trim();
        if (sql.Length == 0)
            return new PlannedCaseSql("clarify", "", "Which case should I predict? Paste the record JSON (like `api.txt`) or specify a clear filter.");

        return new PlannedCaseSql("sql", sql, "");
    }

    private static CasePredictionRecord MapRowToPredictionRecord(Dictionary<string, object?> row)
    {
        string? get(string k)
        {
            foreach (var key in row.Keys)
            {
                if (string.Equals(key, k, StringComparison.OrdinalIgnoreCase))
                    return row.TryGetValue(key, out var v) ? (v?.ToString() ?? "") : "";
            }
            return null;
        }

        return new CasePredictionRecord
        {
            TicketNumber = (get("TicketNumber") ?? "").Trim(),
            CreatedOn = get("createdon"),
            MsdynCaseRocName = get("msdyn_caserocname"),
            MsdynBusinessFunctionIdName = get("msdyn_businessfunctionidname"),
            MsdynLineOfBusinessIdName = get("msdyn_lineofbusinessidname"),
            MsdynProgramIdName = get("msdyn_programidname"),
            MsdynCaseTypeIdName = get("msdyn_casetypeidname"),
            MsdynCaseSubTypeIdName = get("msdyn_casesubtypeidname"),
            MsdynCaseReasonIdName = get("msdyn_casereasonidname"),
            MsdynCaseSubReasonIdName = get("msdyn_casesubreasonidname"),
            PriorityCodeName = get("prioritycodename"),
            MsdynComplexityName = get("msdyn_complexityname"),
            MsdynCountrySubmitterIdName = get("msdyn_countrysubmitteridname"),
            MsdynCountryProcessedIdName = get("msdyn_countryprocessedidname"),
            StatusCodeName = get("statuscodename"),
            OnHoldTime = get("onholdtime")
        };
    }

    private static bool IsGreeting(string text)
    {
        var t = (text ?? "").Trim().ToLowerInvariant();
        if (t.Length == 0) return false;

        return t is "hi" or "hello" or "hey" or "yo" or "sup" or "good morning" or "good afternoon" or "good evening"
            or "thanks" or "thank you" or "thx"
            or "ok" or "okay";
    }

    private static List<string> SplitSchemaIntoChunks(string schemaText, int maxChars)
    {
        schemaText ??= "";
        maxChars = Math.Max(500, maxChars);

        var normalized = schemaText.Replace("\r\n", "\n");

        var marker = "\nTable:";
        var first = normalized.IndexOf(marker, StringComparison.Ordinal);
        if (first < 0)
            return SplitTextIntoChunks(normalized, maxChars);

        var blocks = new List<string>();

        var header = normalized[..first].TrimEnd();
        if (header.Length > 0)
            blocks.Add(header);

        var rest = normalized[(first + 1)..];
        var parts = rest.Split(marker, StringSplitOptions.None);
        for (var i = 0; i < parts.Length; i++)
        {
            var p = (i == 0 ? parts[i] : "Table:" + parts[i]).Trim();
            if (p.Length > 0) blocks.Add(p);
        }

        var outChunks = new List<string>();
        foreach (var b in blocks)
        {
            if (b.Length <= maxChars)
            {
                outChunks.Add(b);
                continue;
            }
            outChunks.AddRange(SplitTextIntoChunks(b, maxChars));
        }

        return outChunks.Count == 0 ? new List<string> { "" } : outChunks;
    }

    private static List<string> SplitTextIntoChunks(string text, int maxChars)
    {
        text ??= "";
        maxChars = Math.Max(500, maxChars);

        var lines = text.Replace("\r\n", "\n").Split('\n');
        var chunks = new List<string>();
        var sb = new System.Text.StringBuilder();

        foreach (var line in lines)
        {
            if (line.Length > maxChars)
            {
                Flush();
                for (var i = 0; i < line.Length; i += maxChars)
                    chunks.Add(line.Substring(i, Math.Min(maxChars, line.Length - i)));
                continue;
            }

            if (sb.Length + line.Length + 1 > maxChars)
                Flush();

            if (sb.Length > 0) sb.Append('\n');
            sb.Append(line);
        }

        Flush();
        return chunks.Count == 0 ? new List<string> { "" } : chunks;

        void Flush()
        {
            if (sb.Length == 0) return;
            chunks.Add(sb.ToString());
            sb.Clear();
        }
    }
}

