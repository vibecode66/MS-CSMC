using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using SqlCopilot.Core.Agent;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Post-query supervisor that validates the result shape and makes a final
/// visualization decision (or requests a rerun/escalation) before rendering
/// an Adaptive Card for Teams.
/// </summary>
public sealed class ResultSupervisorService : IResultSupervisorService
{
    // Keep prompt payload bounded and deterministic.
    private const int MaxSchemaChars = 6000;
    private const int MaxSqlChars = 4000;
    private const int MaxResultJsonChars = 9000;
    private const int SampleMaxRows = 15;
    private const int SampleMaxCols = 8;

    private static readonly Regex ExplicitIdIntentRegex =
        new(@"\b(id|ids|guid|guids)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex MetricIntentRegex =
        new(@"\b(percent|percentage|ratio|rate)\b|%", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex CountIntentRegex =
        new(@"\b(how\s+many|count|number\s+of)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex ActionDimensionIntentRegex =
        new(@"\b(action\s*type|action\s*types|action\s*group|action\s*groups)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex OnCasesIntentRegex =
        new(@"\b(on|for)\s+cases?\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex HumanTouchIntentRegex =
        new(@"\b(human\s*touch|manual\s*touch|automation|automated|without\s+human|no\s+human)\b",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private readonly IJsonLlmClient _jsonLlm;
    private readonly ILogger<ResultSupervisorService> _logger;

    public ResultSupervisorService(IJsonLlmClient jsonLlm, ILogger<ResultSupervisorService> logger)
    {
        _jsonLlm = jsonLlm ?? throw new ArgumentNullException(nameof(jsonLlm));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<ResultSupervisorDecision> DecideAsync(
        string userQuery,
        DatabaseSchema schema,
        NL2SqlResponse sqlResponse,
        QueryResult queryResult,
        CancellationToken cancellationToken = default)
    {
        userQuery = (userQuery ?? "").Trim();
        schema ??= new DatabaseSchema();
        sqlResponse ??= new NL2SqlResponse();
        queryResult ??= new QueryResult { IsSuccess = false };

        if (DebugContext.IsEnabled())
        {
            await DebugContext.WriteAsync("Invoking result supervisor.");
            await DebugContext.WriteAsync($"Supervisor input: success={queryResult.IsSuccess} rows={queryResult.Rows.Count} cols={queryResult.Columns.Count} suggestedChart={sqlResponse.SuggestedChart}");
        }

        var trimmed = Trim(queryResult);
        var schemaText = LogText.Trunc(schema.ToSchemaSnapshot(includeSampleData: false), MaxSchemaChars);
        var sqlText = LogText.Trunc(sqlResponse.GeneratedSql ?? "", MaxSqlChars);

        // Fast-path fixes (deterministic) for common empty-result causes and chart-shape issues.
        // This avoids spending tokens when the fix is obvious.
        if (ShouldRerunForIsDeletedNullTrap(trimmed, sqlText))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (IsDeleted NULL trap).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Query returned zero rows; likely filtered out NULL IsDeleted values.",
                ChartType: sqlResponse.SuggestedChart,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Treat IsDeleted NULL as not deleted (use ISNULL(IsDeleted,0)=0)."),
                UserNote: "No rows were returned. I’ll retry with a safer soft-delete filter (treat NULL IsDeleted as not deleted).");
        }

        if (ShouldRerunForGuidIdColumns(trimmed, schema, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (GUID/id columns not user-friendly).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Result includes GUID/id columns where name columns would be more readable.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Return user-friendly name columns (like ...idname) instead of GUID id columns (like ...id), unless the user explicitly asks for IDs."),
                UserNote: "The result included GUID-style IDs. I’ll rerun the query selecting the corresponding name columns so it’s easier to read.");
        }

        if (ShouldRerunForLineChartTimeAxis(trimmed, sqlResponse.SuggestedChart))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (line chart needs time axis).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Line chart needs a single time axis column (WeekStartDate/WeekLabel).",
                ChartType: ChartType.Line,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "For weekly trend charts, return a WeekStartDate (date) or WeekLabel (YYYY-WW) column as the first column."),
                UserNote: "I’ll retry with a proper weekly time axis so the line chart can render correctly.");
        }

        if (ShouldRerunForActionDimensionMissingIncidentJoin(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (action dimension query missing incident join).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Action type/group question says 'on cases' but SQL is not anchored on the incident table.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Because this asks for action types on cases, anchor the query on dbo.eh_incident, filter the cases first, then join dbo.eh_msdyn_caseaction on dbo.eh_incident.incidentid = dbo.eh_msdyn_caseaction.msdyn_case. Group by the action dimension after the join. Do not answer from dbo.eh_msdyn_caseaction alone."),
                UserNote: "I’ll rerun using the case table as the anchor so the action types are counted on cases, not just on raw action rows.");
        }

        if (ShouldRerunForRequestedDayWindowMismatch(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (requested day window mismatch).");

            TryParseRequestedDayWindow(userQuery, out var requestedDays);
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "SQL used a different last-N-days window than the user requested.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    $"Use the exact requested time window of last {requestedDays} days. Do not broaden or change it. If the question is about action types on cases, apply the {requestedDays}-day filter to the case date unless I explicitly asked for action created date."),
                UserNote: "I’ll rerun using the exact day range you asked for.");
        }

        if (ShouldRerunForCaseactionLeftJoinElseTrap(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (caseaction LEFT JOIN else trap).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "LEFT JOIN classification treats missing child rows as human/no-human touch.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Use a cohort-first approach: build TOP (N) resolved cases ordered by msdyn_resolveddate. Then aggregate eh_msdyn_caseaction per case (GROUP BY msdyn_case) using MAX(CASE...) to compute HasEvidence, HasHumanTouch, HasNoHumanTouch. A case is WITHOUT human touch ONLY if HasEvidence=1 AND HasNoHumanTouch=1 AND HasHumanTouch=0. Exclude HasEvidence=0 cases from percentages and report ExcludedNoEvidence."),
                UserNote: "I’ll rerun with a safer case-level classification so missing caseaction rows don’t get mislabeled.");
        }

        if (ShouldRerunForContradictoryHumanTouchPredicate(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (contradictory human-touch predicate).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "SQL contains contradictory human-touch predicates (e.g., HasHumanTouch=1 AND HasHumanTouch=0).",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Fix any contradictory predicates. For WITHOUT human touch, the predicate must be: HasEvidence=1 AND HasNoHumanTouch=1 AND HasHumanTouch=0 (never HasHumanTouch=1 and 0 at the same time). Return a single KPI row."),
                UserNote: "I’ll rerun fixing a logic bug in the predicates so the KPI counts/percentage are computed correctly.");
        }

        if (ShouldRerunForNullUnsafeNotApplicable(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (NULL-unsafe Not Applicable filter).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "statuscodename filter is not NULL-safe; can drop valid rows.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "When excluding Not Applicable, use ISNULL(statuscodename,'') <> 'Not Applicable' (statuscodename is nullable)."),
                UserNote: "I’ll rerun with a NULL-safe Not Applicable filter so we don’t lose rows unintentionally.");
        }

        if (ShouldRerunForJoinInflatedTotal(trimmed, userQuery, sqlText))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (join-inflated totals).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Total count appears inflated by join duplication.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "If joining to child tables, avoid COUNT(*) over the joined result. Use a cohort CTE of the top N cases first and count cases (COUNT(*) from the cohort or COUNT(DISTINCT incidentid))."),
                UserNote: "The total looks inflated by child-table joins. I’ll rerun counting cases correctly (cohort-first / DISTINCT).");
        }

        if (ShouldRerunForInconsistentHumanTouchCoverage(trimmed, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (inconsistent human-touch coverage counts).");

            var targetColumn = IsWithoutHumanTouchQuestion(userQuery)
                ? "ResolvedWithoutHumanTouch"
                : "ResolvedWithHumanTouch";
            var targetRule = IsWithoutHumanTouchQuestion(userQuery)
                ? "Compute ResolvedWithoutHumanTouch only where HasEvidence=1 AND HasNoHumanTouch=1 AND HasHumanTouch=0."
                : "Compute ResolvedWithHumanTouch only where HasEvidence=1 AND HasHumanTouch=1.";

            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Human-touch summary counts are internally inconsistent.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    $"Return a single KPI row with internally consistent counts. CasesWithEvidence must count only cohort cases where the per-case aggregate exists or HasEvidence=1, not all cohort rows after a LEFT JOIN. ExcludedNoEvidence must equal TotalResolvedCases - CasesWithEvidence. {targetColumn} must be less than or equal to CasesWithEvidence. Build the TOP (N) resolved-case cohort first, aggregate eh_msdyn_caseaction per case, then LEFT JOIN that aggregate back to the cohort. Use COUNT(DISTINCT CASE WHEN agg.EvidenceCount IS NOT NULL THEN cohort.incidentid END) for CasesWithEvidence instead of COUNT(DISTINCT cohort.incidentid). {targetRule}"),
                UserNote: "I’ll rerun because the summary counts contradict each other.");
        }

        if (ShouldRerunForMissingHumanTouchCountCoverage(trimmed, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (missing human-touch count coverage columns).");

            var targetColumn = IsWithoutHumanTouchQuestion(userQuery)
                ? "ResolvedWithoutHumanTouch"
                : "ResolvedWithHumanTouch";
            var targetRule = IsWithoutHumanTouchQuestion(userQuery)
                ? "Compute ResolvedWithoutHumanTouch only where HasEvidence=1 AND HasNoHumanTouch=1 AND HasHumanTouch=0."
                : "Compute ResolvedWithHumanTouch only where HasEvidence=1 AND HasHumanTouch=1.";

            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Human-touch count question dropped part of the cohort or hid no-evidence cases.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    $"Preserve the full resolved-case cohort before touching eh_msdyn_caseaction. Build the TOP (N) resolved-case cohort first, aggregate eh_msdyn_caseaction per case (GROUP BY msdyn_case) to compute HasEvidence, HasHumanTouch, HasNoHumanTouch, then LEFT JOIN that per-case aggregate back to the cohort so cases with no applicable caseaction rows remain visible as ExcludedNoEvidence instead of disappearing. Return a single KPI row with exactly these columns: TotalResolvedCases, CasesWithEvidence, ExcludedNoEvidence, {targetColumn}. Do not collapse the cohort with an INNER JOIN to caseaction. {targetRule}"),
                UserNote: "I’ll rerun keeping the full case cohort and showing how many cases had no human-touch evidence, instead of silently dropping them.");
        }

        if (ShouldRerunForMissingHumanTouchCoverageColumns(trimmed, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (missing human-touch KPI coverage columns).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Human-touch KPI should include evidence coverage and counts to make the denominator explicit.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Return a single KPI row with these columns: TotalResolvedCases, CasesWithEvidence, ExcludedNoEvidence, ResolvedWithHumanTouch, ResolvedWithoutHumanTouch, PercentWithoutHumanTouch (=100.0*ResolvedWithoutHumanTouch/NULLIF(CasesWithEvidence,0)). Do not return a detail rowset."),
                UserNote: "I’ll rerun including evidence coverage and the supporting counts so the percentage denominator is explicit.");
        }

        if (ShouldRerunForMissingTelemetryDenominator(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (wrong denominator / missing evidence coverage).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Percentage is computed over all cases even when many have no caseaction evidence.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Report evidence coverage and compute percentages among cases with evidence only. Return: TotalResolvedCases, CasesWithEvidence, ExcludedNoEvidence, ResolvedWithHumanTouch, ResolvedWithoutHumanTouch, PercentWithoutHumanTouch (=100*Without/NULLIF(CasesWithEvidence,0))."),
                UserNote: "I’ll rerun computing the percentage only over cases that have caseaction evidence, and report how many cases were excluded due to missing evidence.");
        }

        if (ShouldRerunForAutomationNotExclusive(sqlText, userQuery))
        {
            if (DebugContext.IsEnabled())
                await DebugContext.WriteAsync("Supervisor decided: rerun (without-human-touch not exclusive).");
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: "Without-human-touch is counted without excluding cases that also have human-touch actions.",
                ChartType: ChartType.Table,
                UpdatedQuestion: AppendConstraint(userQuery,
                    "Make 'without human touch' exclusive at the CASE level: compute HasEvidence/HasHumanTouch/HasNoHumanTouch per case via MAX(CASE...). Count WithoutHumanTouch only where HasEvidence=1 AND HasNoHumanTouch=1 AND HasHumanTouch=0. Human-touch row = execution=Manual OR automatic with executedbyname not NULL/#uami OR modifiedbyname not NULL/#uami."),
                UserNote: "I’ll rerun using a strict definition: a case is 'without human touch' only if it has no human-touch actions at all.");
        }

        var resultSummaryJson = BuildResultSummaryJson(trimmed);
        resultSummaryJson = LogText.Trunc(resultSummaryJson, MaxResultJsonChars);

        var prompt = BuildPrompt(
            userQuery: userQuery,
            schemaText: schemaText,
            sql: sqlText,
            explanation: (sqlResponse.Explanation ?? "").Trim(),
            suggestedChart: ToChartTypeString(sqlResponse.SuggestedChart),
            resultSummaryJson: resultSummaryJson);
        if (DebugContext.IsEnabled())
            await DebugContext.WriteBlockAsync("Supervisor LLM prompt (truncated)", prompt);

        JsonElement el;
        try
        {
            el = await _jsonLlm.CallJsonAsync(prompt, cancellationToken);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "RESULT_SUPERVISOR_FAILED error={Error}", ex.Message);
            return new ResultSupervisorDecision(
                Action: ResultSupervisorAction.Render,
                Reason: "Supervisor failed; rendering with default settings.",
                ChartType: sqlResponse.SuggestedChart);
        }

        var decision = ParseDecision(el, fallbackChart: sqlResponse.SuggestedChart);
        if (DebugContext.IsEnabled())
            await DebugContext.WriteBlockAsync("Supervisor decision JSON (truncated)", LogText.Json(el, 2000));
        _logger.LogInformation(
            "RESULT_SUPERVISOR_DECISION action={Action} chart={Chart} hasRerun={HasRerun} hasClarify={HasClarify}",
            decision.Action,
            decision.ChartType?.ToString() ?? "",
            !string.IsNullOrWhiteSpace(decision.UpdatedQuestion),
            !string.IsNullOrWhiteSpace(decision.ClarifyQuestion));

        return decision;
    }

    private static bool ShouldRerunForNullUnsafeNotApplicable(string sqlText, string userQuery)
    {
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "") && !MetricIntentRegex.IsMatch(userQuery ?? ""))
            return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("statuscodename")) return false;
        if (!sqlText.Contains("not applicable")) return false;

        // If query already uses ISNULL/COALESCE around statuscodename, it's fine.
        if (sqlText.Contains("isnull(ca.[statuscodename]") ||
            sqlText.Contains("isnull([statuscodename]") ||
            sqlText.Contains("isnull(ca.statuscodename") ||
            sqlText.Contains("coalesce(ca.[statuscodename]") ||
            sqlText.Contains("coalesce([statuscodename]") ||
            sqlText.Contains("coalesce(ca.statuscodename"))
            return false;

        // Common unsafe pattern.
        return sqlText.Contains("statuscodename <> 'not applicable'") ||
               sqlText.Contains("statuscodename<>'not applicable'");
    }

    private static bool ShouldRerunForActionDimensionMissingIncidentJoin(string sqlText, string userQuery)
    {
        if (!LooksLikeActionDimensionOnCasesQuestion(userQuery)) return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("eh_msdyn_caseaction")) return false;

        return !sqlText.Contains("eh_incident");
    }

    private static bool ShouldRerunForRequestedDayWindowMismatch(string sqlText, string userQuery)
    {
        if (!TryParseRequestedDayWindow(userQuery, out var requestedDays)) return false;
        if (!TryParseSqlDayWindow(sqlText, out var sqlDays)) return false;

        return requestedDays != sqlDays;
    }

    private static bool ShouldRerunForCaseactionLeftJoinElseTrap(string sqlText, string userQuery)
    {
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "")) return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("left join")) return false;
        if (!sqlText.Contains("eh_msdyn_caseaction")) return false;

        // The bad pattern we observed: CASE ... ELSE 'Human Touch' (or similar) with a LEFT JOIN,
        // causing NULL-join rows to be labeled as human/no-human instead of excluded.
        if (sqlText.Contains("else 'human touch'") || sqlText.Contains("else 'no human touch'"))
        {
            // If the query explicitly has a no-caseaction branch, don't flag.
            if (sqlText.Contains("no caseaction") || sqlText.Contains("ca.[id] is null") || sqlText.Contains("ca.id is null"))
                return false;
            return true;
        }

        return false;
    }

    private static bool ShouldRerunForContradictoryHumanTouchPredicate(string sqlText, string userQuery)
    {
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "")) return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("eh_msdyn_caseaction")) return false;

        // Catch the exact failure mode observed: "... HasHumanTouch = 1 AND ... HasHumanTouch = 0 ..."
        // within the same predicate, which makes the condition impossible.
        return Regex.IsMatch(
            sqlText,
            @"hashumantouch\s*=\s*1\s*and[\s\S]{0,120}hashumantouch\s*=\s*0",
            RegexOptions.IgnoreCase);
    }

    private static bool ShouldRerunForMissingTelemetryDenominator(string sqlText, string userQuery)
    {
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "")) return false;
        if (!MetricIntentRegex.IsMatch(userQuery ?? "")) return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("eh_msdyn_caseaction")) return false;

        // If the SQL already talks about evidence coverage, don't force a rerun.
        if (sqlText.Contains("caseswithevidence") ||
            sqlText.Contains("excludednoevidence") ||
            sqlText.Contains("caseactionevidence") ||
            sqlText.Contains("caseswithcaseaction") ||
            sqlText.Contains("noevidence"))
            return false;

        // Detect percent-style calculations that divide by the cohort size rather than evidence count.
        // Common pattern: ... / COUNT(DISTINCT c.incidentid) ... or ... / COUNT(*)
        var dividesByCohort =
            Regex.IsMatch(sqlText, @"/\s*count\s*\(\s*distinct\s*(c|lrc)\.", RegexOptions.IgnoreCase) ||
            Regex.IsMatch(sqlText, @"/\s*count\s*\(\s*distinct\s*\[?incidentid\]?", RegexOptions.IgnoreCase) ||
            Regex.IsMatch(sqlText, @"/\s*count\s*\(\s*\*\s*\)", RegexOptions.IgnoreCase);

        // Only fire if it looks like a percent computation.
        var looksLikePercent = sqlText.Contains("percent") || sqlText.Contains("%") || sqlText.Contains("100.0") || sqlText.Contains("100.00");
        return looksLikePercent && dividesByCohort;
    }

    private static bool ShouldRerunForInconsistentHumanTouchCoverage(QueryResult trimmed, string userQuery)
    {
        if (!LooksLikeHumanTouchCountQuestion(userQuery)) return false;
        if (!trimmed.IsSuccess) return false;
        var rows = trimmed.Rows ?? new List<Dictionary<string, object?>>();
        if (rows.Count == 0) return false;
        if (trimmed.TotalRowCount > 1) return false;

        var row = rows[0];

        if (!TryGetNumber(row, "TotalResolvedCases", out var total) &&
            !TryGetNumber(row, "TotalCases", out total))
            return false;

        if (!TryGetNumber(row, "CasesWithEvidence", out var evidence))
            return false;

        if (!TryGetNumber(row, "ExcludedNoEvidence", out var excluded))
            return false;

        long requestedBucket = 0;
        var hasRequestedBucket = IsWithoutHumanTouchQuestion(userQuery)
            ? TryGetNumber(row, "ResolvedWithoutHumanTouch", out requestedBucket) ||
              TryGetNumber(row, "CasesWithoutHumanTouch", out requestedBucket) ||
              TryGetNumber(row, "WithoutHumanTouch", out requestedBucket)
            : TryGetNumber(row, "ResolvedWithHumanTouch", out requestedBucket) ||
              TryGetNumber(row, "CasesWithHumanTouch", out requestedBucket) ||
              TryGetNumber(row, "WithHumanTouch", out requestedBucket);

        if (evidence < 0 || excluded < 0 || total < 0) return true;
        if (evidence > total || excluded > total) return true;
        if (evidence + excluded != total) return true;
        if (hasRequestedBucket && (requestedBucket < 0 || requestedBucket > evidence)) return true;

        return false;
    }

    private static bool ShouldRerunForMissingHumanTouchCountCoverage(QueryResult trimmed, string userQuery)
    {
        if (!LooksLikeHumanTouchCountQuestion(userQuery)) return false;
        if (!trimmed.IsSuccess) return false;

        // If it returned multiple rows, it may be a deliberate breakdown.
        if (trimmed.TotalRowCount > 1) return false;

        var cols = trimmed.Columns
            .Select(c => (c.Name ?? "").Trim())
            .Where(s => s.Length > 0)
            .ToList();

        bool has(string name) => cols.Any(c => string.Equals(c, name, StringComparison.OrdinalIgnoreCase));
        bool hasAny(params string[] names) => names.Any(has);

        var hasTotal = hasAny("TotalResolvedCases", "TotalCases");
        var hasEvidence = has("CasesWithEvidence");
        var hasExcluded = has("ExcludedNoEvidence");
        var hasRequestedBucket = IsWithoutHumanTouchQuestion(userQuery)
            ? hasAny("ResolvedWithoutHumanTouch", "CasesWithoutHumanTouch", "WithoutHumanTouch")
            : hasAny("ResolvedWithHumanTouch", "CasesWithHumanTouch", "WithHumanTouch");

        if (hasTotal && hasEvidence && hasExcluded && hasRequestedBucket)
            return false;

        var looksLikeCollapsedCount =
            hasRequestedBucket ||
            cols.Any(c => c.Contains("Evidence", StringComparison.OrdinalIgnoreCase)) ||
            (cols.Count <= 2 && cols.Any(c => c.Contains("HumanTouch", StringComparison.OrdinalIgnoreCase)));

        return looksLikeCollapsedCount && (!hasTotal || !hasEvidence || !hasExcluded);
    }

    private static bool ShouldRerunForMissingHumanTouchCoverageColumns(QueryResult trimmed, string userQuery)
    {
        // Only for metric-ish questions about human touch / automation.
        if (!MetricIntentRegex.IsMatch(userQuery ?? "")) return false;
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "")) return false;

        // If the query didn't succeed, let other rules handle reruns.
        if (!trimmed.IsSuccess) return false;

        // If it returned multiple rows, it might be a breakdown; don't force KPI shape.
        if (trimmed.TotalRowCount > 1) return false;

        var cols = trimmed.Columns
            .Select(c => (c.Name ?? "").Trim())
            .Where(s => s.Length > 0)
            .ToList();

        bool has(string name) => cols.Any(c => string.Equals(c, name, StringComparison.OrdinalIgnoreCase));

        // If it already has the key fields, don't rerun.
        if (has("CasesWithEvidence") &&
            has("ExcludedNoEvidence") &&
            (has("PercentWithoutHumanTouch") || has("PercentWithoutTouch")))
            return false;

        // If it looks like it returned just a percent column, rerun to add supporting counts.
        var looksLikePercentColumn =
            has("PercentWithoutHumanTouch") ||
            has("PercentWithoutTouch") ||
            cols.Any(c => c.Contains("percent", StringComparison.OrdinalIgnoreCase));

        return looksLikePercentColumn && !has("CasesWithEvidence") && !has("ExcludedNoEvidence");
    }

    private static bool ShouldRerunForAutomationNotExclusive(string sqlText, string userQuery)
    {
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "")) return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("eh_msdyn_caseaction")) return false;

        // If the SQL already contains explicit exclusion logic, don't force a rerun.
        if (sqlText.Contains("not exists") ||
            sqlText.Contains("hashumantouch") ||
            sqlText.Contains("hasnohumantouch") ||
            sqlText.Contains("humantouch") && sqlText.Contains("case") && sqlText.Contains("max("))
            return false;

        // If it never mentions the human-touch side (Manual / not-#uami), it's likely counting automation
        // without excluding cases that also had a human-touch action.
        var mentionsAutomation =
            (sqlText.Contains("msdyn_execution") && sqlText.Contains("automatic")) ||
            sqlText.Contains("automation") ||
            sqlText.Contains("automated");

        var includesOnlyUamiLogic =
            (sqlText.Contains("executedbyname") && (sqlText.Contains("like '%# uami%'") || sqlText.Contains("is null"))) &&
            !sqlText.Contains("not like '%# uami%'");

        var mentionsManualOrPerson =
            sqlText.Contains("msdyn_execution = 'manual'") ||
            sqlText.Contains("msdyn_execution='manual'") ||
            sqlText.Contains("not like '%# uami%'") ||
            sqlText.Contains("modifiedbyname") && sqlText.Contains("not like '%# uami%'");

        return mentionsAutomation && includesOnlyUamiLogic && !mentionsManualOrPerson;
    }

    private static bool LooksLikeHumanTouchCountQuestion(string userQuery)
    {
        if (!HumanTouchIntentRegex.IsMatch(userQuery ?? "")) return false;
        if (MetricIntentRegex.IsMatch(userQuery ?? "")) return false;
        return CountIntentRegex.IsMatch(userQuery ?? "") || TryParseRequestedN(userQuery ?? "", out _);
    }

    private static bool LooksLikeActionDimensionOnCasesQuestion(string userQuery)
    {
        userQuery ??= "";
        return ActionDimensionIntentRegex.IsMatch(userQuery) && OnCasesIntentRegex.IsMatch(userQuery);
    }

    private static bool IsWithoutHumanTouchQuestion(string userQuery)
    {
        userQuery = (userQuery ?? "").ToLowerInvariant();
        return userQuery.Contains("without human") ||
               userQuery.Contains("no human") ||
               userQuery.Contains("automation") ||
               userQuery.Contains("automated");
    }

    private static bool ShouldRerunForJoinInflatedTotal(QueryResult trimmed, string userQuery, string sqlText)
    {
        if (!MetricIntentRegex.IsMatch(userQuery ?? "")) return false;
        if (!trimmed.IsSuccess) return false;
        var rows = trimmed.Rows ?? new List<Dictionary<string, object?>>();
        if (rows.Count == 0) return false;

        // Detect the common failure: total should match the cohort size (TOP N), but join duplication makes it larger.
        // Try to infer N from SQL or the user's query; if we can't, skip.
        var expectedN =
            TryParseTopN(sqlText, out var nSql) ? nSql :
            (TryParseRequestedN(userQuery ?? "", out var nUser) ? nUser : (int?)null);
        if (expectedN is null) return false;

        var row = rows[0];
        if (TryGetNumber(row, "TotalResolvedCases", out var total) ||
            TryGetNumber(row, "TotalCases", out total))
        {
            return total > expectedN.Value;
        }

        return false;
    }

    private static bool TryParseTopN(string sqlText, out int n)
    {
        n = 0;
        sqlText = (sqlText ?? "").ToLowerInvariant();
        // Handles: "select top 1000", "select top (1000)"
        var m = Regex.Match(sqlText, @"\btop\s*\(?\s*(?<n>\d{1,6})\s*\)?", RegexOptions.IgnoreCase);
        if (!m.Success) return false;
        return int.TryParse(m.Groups["n"].Value, out n) && n > 0;
    }

    private static bool TryParseRequestedN(string userQuery, out int n)
    {
        n = 0;
        userQuery = (userQuery ?? "").ToLowerInvariant();
        // Common phrasing: "last 1000", "latest 1000", "recent 1000", "top 1000"
        var m = Regex.Match(userQuery, @"\b(last|latest|recent|top)\s+(?<n>\d{1,6})\b", RegexOptions.IgnoreCase);
        if (!m.Success) return false;
        return int.TryParse(m.Groups["n"].Value, out n) && n > 0;
    }

    private static bool TryParseRequestedDayWindow(string userQuery, out int n)
    {
        n = 0;
        userQuery = (userQuery ?? "").ToLowerInvariant();
        var m = Regex.Match(userQuery, @"\blast\s+(?<n>\d{1,4})\s+days?\b", RegexOptions.IgnoreCase);
        if (!m.Success) return false;
        return int.TryParse(m.Groups["n"].Value, out n) && n > 0;
    }

    private static bool TryParseSqlDayWindow(string sqlText, out int n)
    {
        n = 0;
        sqlText = (sqlText ?? "").ToLowerInvariant();
        var m = Regex.Match(sqlText, @"dateadd\s*\(\s*day\s*,\s*-\s*(?<n>\d{1,4})\s*,", RegexOptions.IgnoreCase);
        if (!m.Success) return false;
        return int.TryParse(m.Groups["n"].Value, out n) && n > 0;
    }

    private static bool TryGetNumber(Dictionary<string, object?> row, string key, out long value)
    {
        value = 0;
        row ??= new Dictionary<string, object?>();

        object? raw = null;
        foreach (var k in row.Keys)
        {
            if (string.Equals(k, key, StringComparison.OrdinalIgnoreCase))
            {
                raw = row[k];
                break;
            }
        }
        if (raw is null) return false;

        if (raw is int i) { value = i; return true; }
        if (raw is long l) { value = l; return true; }
        if (raw is decimal d) { value = (long)d; return true; }
        if (raw is double dbl) { value = (long)dbl; return true; }
        if (long.TryParse(raw.ToString(), out var parsed)) { value = parsed; return true; }
        return false;
    }

    private static bool ShouldRerunForIsDeletedNullTrap(QueryResult trimmed, string sqlText)
    {
        // Only applies when we got no data.
        if (!trimmed.IsSuccess) return false;
        if ((trimmed.Rows ?? new List<Dictionary<string, object?>>()).Count != 0) return false;

        sqlText = (sqlText ?? "").ToLowerInvariant();
        if (!sqlText.Contains("isdeleted")) return false;

        // If the query already handles NULLs, no need.
        if (sqlText.Contains("isnull([isdeleted]") || sqlText.Contains("coalesce([isdeleted]") ||
            sqlText.Contains("isdeleted] is null") || sqlText.Contains("isdeleted is null"))
            return false;

        // Common problematic form.
        return sqlText.Contains("isdeleted = 0") || sqlText.Contains("[isdeleted]=0");
    }

    private static bool ShouldRerunForLineChartTimeAxis(QueryResult trimmed, ChartType suggestedChart)
    {
        if (!trimmed.IsSuccess) return false;
        if (suggestedChart != ChartType.Line) return false;
        if ((trimmed.Rows ?? new List<Dictionary<string, object?>>()).Count == 0) return false;

        var cols = trimmed.Columns ?? new List<QueryColumn>();
        if (cols.Count < 2) return false;

        // If there is already a date/datetime-like or label-like first column, accept.
        var first = cols[0];
        var dt = (first.DataType ?? "").ToLowerInvariant();
        var name = (first.Name ?? "").ToLowerInvariant();
        if (dt.Contains("date") || dt.Contains("time")) return false;
        if (name.Contains("weeklabel") || name.Contains("week_start") || name.Contains("weekstart") || name.Contains("date")) return false;

        // Detect the known-bad pattern: separate numeric Year/Week columns.
        bool hasYear = cols.Any(c => string.Equals(c.Name, "Year", StringComparison.OrdinalIgnoreCase) ||
                                     string.Equals(c.Name, "year", StringComparison.OrdinalIgnoreCase));
        bool hasWeek = cols.Any(c => string.Equals(c.Name, "Week", StringComparison.OrdinalIgnoreCase) ||
                                     string.Equals(c.Name, "week", StringComparison.OrdinalIgnoreCase));
        return hasYear && hasWeek;
    }

    private static bool ShouldRerunForGuidIdColumns(QueryResult trimmed, DatabaseSchema schema, string userQuery)
    {
        if (!trimmed.IsSuccess) return false;

        // If the user explicitly wants IDs, do not override.
        if (ExplicitIdIntentRegex.IsMatch(userQuery ?? "")) return false;

        var cols = trimmed.Columns ?? new List<QueryColumn>();
        if (cols.Count == 0) return false;

        var rows = trimmed.Rows ?? new List<Dictionary<string, object?>>();
        if (rows.Count == 0) return false;

        var schemaCols = (schema?.Tables ?? new List<TableSchema>())
            .SelectMany(t => t.Columns ?? new List<ColumnSchema>())
            .Select(c => (c.ColumnName ?? "").Trim())
            .Where(n => n.Length > 0)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        // Common identifiers we should not treat as "unreadable GUID ids".
        var exempt = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "ticketnumber",
            "msdyn_casenumber",
            "case_id",
            "caseid",
            "incidentid"
        };

        foreach (var c in cols)
        {
            var name = (c.Name ?? "").Trim();
            if (name.Length == 0) continue;
            if (exempt.Contains(name)) continue;

            // Heuristic: columns ending in "id" are likely GUIDs; prefer the corresponding "...idname".
            // Example: msdyn_lineofbusinessid -> msdyn_lineofbusinessidname
            if (!name.EndsWith("id", StringComparison.OrdinalIgnoreCase)) continue;
            if (name.EndsWith("idname", StringComparison.OrdinalIgnoreCase)) continue;

            var candidate = name + "name";
            if (schemaCols.Contains(candidate))
                return true;
        }

        return false;
    }

    private static string AppendConstraint(string userQuery, string constraint)
    {
        userQuery = (userQuery ?? "").Trim();
        constraint = (constraint ?? "").Trim();
        if (constraint.Length == 0) return userQuery;
        if (userQuery.Length == 0) return constraint;
        return userQuery + " " + constraint;
    }

    private static QueryResult Trim(QueryResult result)
    {
        result ??= new QueryResult();
        var cols = result.Columns ?? new List<QueryColumn>();
        var rows = result.Rows ?? new List<Dictionary<string, object?>>();

        var trimmedColumns = cols.Count > SampleMaxCols ? cols.Take(SampleMaxCols).ToList() : cols;
        var keepNames = trimmedColumns.Select(c => c.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);

        var trimmedRows = rows
            .Take(SampleMaxRows)
            .Select(r => r
                .Where(kvp => keepNames.Contains(kvp.Key))
                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value))
            .ToList();

        return new QueryResult
        {
            IsSuccess = result.IsSuccess,
            ErrorMessage = result.ErrorMessage,
            SqlQuery = result.SqlQuery,
            Columns = trimmedColumns,
            Rows = trimmedRows,
            TotalRowCount = result.TotalRowCount,
            IsTruncated = result.IsTruncated || rows.Count > SampleMaxRows || cols.Count > SampleMaxCols,
            ExecutionTime = result.ExecutionTime
        };
    }

    private static string BuildResultSummaryJson(QueryResult trimmed)
    {
        trimmed ??= new QueryResult();
        var summaryObj = new
        {
            isSuccess = trimmed.IsSuccess,
            errorMessage = (trimmed.ErrorMessage ?? "").Trim(),
            totalRowCount = trimmed.TotalRowCount,
            returnedRowCount = (trimmed.Rows ?? new List<Dictionary<string, object?>>()).Count,
            isTruncated = trimmed.IsTruncated,
            executionTimeMs = Math.Round(trimmed.ExecutionTime.TotalMilliseconds, 1),
            resultType = trimmed.ResultType.ToString(),
            columns = (trimmed.Columns ?? new List<QueryColumn>()).Select(c => new { name = c.Name, dataType = c.DataType }).ToList(),
            sampleRows = trimmed.Rows ?? new List<Dictionary<string, object?>>()
        };

        try
        {
            return JsonSerializer.Serialize(summaryObj);
        }
        catch
        {
            return "{\"error\":\"failed_to_serialize_result_summary\"}";
        }
    }

    private static string BuildPrompt(
        string userQuery,
        string schemaText,
        string sql,
        string explanation,
        string suggestedChart,
        string resultSummaryJson)
    {
        var sb = new StringBuilder();
        sb.AppendLine("You are a ResultSupervisorAgent for a Teams analytics bot.");
        sb.AppendLine("You must validate that the query result answers the user question, and choose the best way to present it in Teams.");
        sb.AppendLine("You are allowed to request a rerun (with an improved natural-language question) or escalate to a multi-step SQL agent.");
        sb.AppendLine("Do NOT invent any data values.");
        sb.AppendLine();
        sb.AppendLine("Allowed actions (return ONLY one JSON object):");
        sb.AppendLine("1) {\"action\":\"render\",\"chartType\":\"table|bar|horizontalBar|pie|doughnut|line\",\"reason\":\"...\",\"userNote\":\"...\"}");
        sb.AppendLine("2) {\"action\":\"rerun_sql_query\",\"updatedQuestion\":\"...\",\"chartType\":\"table|bar|horizontalBar|pie|doughnut|line\",\"reason\":\"...\",\"userNote\":\"...\"}");
        sb.AppendLine("3) {\"action\":\"use_sql_agent\",\"reason\":\"...\",\"userNote\":\"...\"}");
        sb.AppendLine("4) {\"action\":\"clarify\",\"question\":\"...\",\"reason\":\"...\",\"userNote\":\"...\"}");
        sb.AppendLine();
        sb.AppendLine("Visualization rules (strict):");
        sb.AppendLine("- bar/horizontalBar: use when comparing categories; should have >= 3 rows to be meaningful. If 1-2 rows, prefer table.");
        sb.AppendLine("- pie/doughnut: use only for 2-8 categories.");
        sb.AppendLine("- line: use only for trends over time; must have >= 2 points and a date/time-like label column.");
        sb.AppendLine("- If the question asks for a single \"biggest/top\" item and the result has 1 row, prefer table (chartType=table) rather than bar.");
        sb.AppendLine("- If the chart choice is not supported by the returned data shape, choose chartType=table or request a rerun.");
        sb.AppendLine("- If the user asked for a chart but returnedRowCount=0, request rerun_sql_query with a broader time window or relaxed filters.");
        sb.AppendLine("- Common cause of empty results: filtering [IsDeleted] = 0 when [IsDeleted] is nullable. Prefer ISNULL([IsDeleted],0)=0 or ([IsDeleted]=0 OR [IsDeleted] IS NULL).");
        sb.AppendLine("- For line charts, require a single time axis column (date/datetime or a week label string). If the result only has separate numeric [Year] and [Week] columns, request a rerun to return WeekStartDate or WeekLabel.");
        sb.AppendLine();
        sb.AppendLine("Rerun rules:");
        sb.AppendLine("- updatedQuestion must be plain English (NOT SQL).");
        sb.AppendLine("- Keep the meaning the same; only adjust to fix result shape or make visualization meaningful (e.g., top 10 instead of top 1).");
        sb.AppendLine();
        sb.AppendLine("INPUT:");
        sb.AppendLine("ORIGINAL_QUESTION:");
        sb.AppendLine(userQuery);
        sb.AppendLine();
        sb.AppendLine("CURRENT_SQL (truncated):");
        sb.AppendLine(sql);
        sb.AppendLine();
        sb.AppendLine("CURRENT_EXPLANATION:");
        sb.AppendLine(explanation.Length == 0 ? "(none)" : explanation);
        sb.AppendLine();
        sb.AppendLine("CURRENT_SUGGESTED_CHART:");
        sb.AppendLine(suggestedChart);
        sb.AppendLine();
        sb.AppendLine("DATABASE_SCHEMA_SNAPSHOT (truncated):");
        sb.AppendLine(schemaText);
        sb.AppendLine();
        sb.AppendLine("QUERY_RESULT_SUMMARY_JSON:");
        sb.AppendLine(resultSummaryJson);
        return sb.ToString();
    }

    private static ResultSupervisorDecision ParseDecision(JsonElement el, ChartType fallbackChart)
    {
        static string? Str(JsonElement obj, string name)
            => obj.ValueKind == JsonValueKind.Object &&
               obj.TryGetProperty(name, out var v) &&
               v.ValueKind == JsonValueKind.String
                ? (v.GetString() ?? "").Trim()
                : null;

        var action = (Str(el, "action") ?? "").Trim().ToLowerInvariant();
        var reason = Str(el, "reason");
        var userNote = Str(el, "userNote");

        ChartType? chart = null;
        var chartStr = Str(el, "chartType");
        if (!string.IsNullOrWhiteSpace(chartStr))
            chart = ParseChartType(chartStr);

        return action switch
        {
            "rerun_sql_query" => new ResultSupervisorDecision(
                Action: ResultSupervisorAction.RerunSqlQuery,
                Reason: reason,
                ChartType: chart,
                UpdatedQuestion: Str(el, "updatedQuestion"),
                UserNote: userNote),

            "use_sql_agent" => new ResultSupervisorDecision(
                Action: ResultSupervisorAction.UseSqlAgent,
                Reason: reason,
                UserNote: userNote),

            "clarify" => new ResultSupervisorDecision(
                Action: ResultSupervisorAction.Clarify,
                Reason: reason,
                ClarifyQuestion: Str(el, "question"),
                UserNote: userNote),

            _ => new ResultSupervisorDecision(
                Action: ResultSupervisorAction.Render,
                Reason: reason,
                ChartType: chart ?? fallbackChart,
                UserNote: userNote)
        };
    }

    private static ChartType? ParseChartType(string chartType)
    {
        chartType = (chartType ?? "").Trim();
        if (chartType.Length == 0) return null;
        return chartType.ToLowerInvariant() switch
        {
            "table" => ChartType.Table,
            "bar" => ChartType.Bar,
            "horizontalbar" => ChartType.HorizontalBar,
            "pie" => ChartType.Pie,
            "doughnut" => ChartType.Doughnut,
            "line" => ChartType.Line,
            _ => null
        };
    }

    private static string ToChartTypeString(ChartType chartType)
    {
        return chartType switch
        {
            ChartType.Bar => "bar",
            ChartType.HorizontalBar => "horizontalBar",
            ChartType.Pie => "pie",
            ChartType.Doughnut => "doughnut",
            ChartType.Line => "line",
            _ => "table"
        };
    }
}

