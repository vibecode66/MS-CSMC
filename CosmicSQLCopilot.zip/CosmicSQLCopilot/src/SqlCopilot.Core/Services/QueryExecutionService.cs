// ============================================================================
// QueryExecutionService.cs — Safe SQL query execution against Azure SQL
//
// Purpose:
//   Executes LLM-generated SQL queries against Azure SQL Database with
//   multiple safety guardrails:
//     - Only SELECT / WITH (CTE) statements are allowed
//     - Queries run inside READ UNCOMMITTED transactions for isolation
//     - Configurable timeout prevents long-running queries
//     - Configurable row limit prevents memory issues from large result sets
//     - All values are converted to serializable types for Adaptive Card rendering
//
// Dependencies:
//   - ISqlConnectionFactory for Managed Identity connections
//   - AzureSqlOptions for timeout/row-limit configuration
//
// See also:
//   - Prompted SQL generation: `Services/SqlGeneratorService.cs`
//   - Read-only SQL guardrails: `AgentPort/Sql/SqlGuard.cs`
//   - Result rendering (Teams): `Services/AdaptiveCardService.cs`
//   - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.AgentPort.Sql;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Tracing;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Executes SQL queries against Azure SQL Database with safety guardrails.
/// Enforces read-only access, query timeouts, and row limits to protect
/// both the database and the application from runaway queries.
/// </summary>
public class QueryExecutionService : IQueryExecutionService
{
    private readonly AzureSqlOptions _options;
    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<QueryExecutionService> _logger;
    private readonly IConversationTraceSink _trace;
    private readonly ConversationTraceOptions _traceOptions;

    /// <summary>
    /// Initializes the query execution service.
    /// </summary>
    /// <param name="options">Azure SQL configuration (timeout, row limit).</param>
    /// <param name="connectionFactory">Factory for creating database connections.</param>
    /// <param name="logger">Logger for diagnostics.</param>
    public QueryExecutionService(
        IOptions<AzureSqlOptions> options,
        IOptions<ConversationTraceOptions> traceOptions,
        ISqlConnectionFactory connectionFactory,
        IConversationTraceSink trace,
        ILogger<QueryExecutionService> logger)
    {
        _options = (options ?? throw new ArgumentNullException(nameof(options))).Value;
        _traceOptions = (traceOptions ?? throw new ArgumentNullException(nameof(traceOptions))).Value;
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _trace = trace ?? throw new ArgumentNullException(nameof(trace));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Executes a SQL query and returns the results as a <see cref="QueryResult"/>.
    /// The query must be a SELECT statement (or CTE with SELECT). Any data-modifying
    /// statements are rejected before execution.
    /// </summary>
    /// <param name="sqlQuery">The SQL query to execute.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>
    /// A <see cref="QueryResult"/> with column metadata, row data, timing, and status.
    /// If execution fails, <see cref="QueryResult.IsSuccess"/> is <c>false</c>
    /// and <see cref="QueryResult.ErrorMessage"/> describes the problem.
    /// </returns>
    public async Task<QueryResult> ExecuteQueryAsync(
        string sqlQuery, CancellationToken cancellationToken = default)
    {
        var result = new QueryResult { SqlQuery = sqlQuery };

        var queryId = Guid.NewGuid().ToString("N")[..8];

        // ---- Safety check: reject batches and non-read-only queries ----
        // Reject semicolons to prevent batch injection (e.g., "SELECT 1; DELETE FROM ...")
        var trimmed = sqlQuery.Trim();
        var withoutTrailingSemicolon = trimmed.TrimEnd(';');
        if (withoutTrailingSemicolon.Contains(';'))
        {
            _logger.LogWarning("Rejected multi-statement batch (queryId={QueryId})", queryId);
            result.IsSuccess = false;
            result.ErrorMessage = "Only single SQL statements are allowed. Batches (multiple statements separated by semicolons) are rejected.";
            return result;
        }

        try
        {
            SqlGuard.EnsureReadOnly(trimmed);
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning("Rejected unsafe query (queryId={QueryId}): {Reason}", queryId, ex.Message);
            result.IsSuccess = false;
            result.ErrorMessage = ex.Message;
            return result;
        }

        _logger.LogInformation(
            "SQL_EXECUTE_START queryId={QueryId} timeoutSec={Timeout}s maxRows={MaxRows}",
            queryId,
            _options.QueryTimeoutSeconds,
            _options.MaxRowsReturned);
        _logger.LogDebug("SQL_QUERY queryId={QueryId} sql=\"{Sql}\"", queryId, LogText.OneLine(sqlQuery, 800));
        if (DebugContext.IsEnabled())
            await DebugContext.WriteBlockAsync("Executing SQL (truncated)", LogText.Trunc(sqlQuery, 3500));

        var stopwatch = Stopwatch.StartNew();

        try
        {
            await using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

            _logger.LogInformation(
                "SQL_EXECUTE_CONNECTED dataSource={DataSource} database={Database}",
                connection.DataSource,
                connection.Database);

            // Wrap in READ UNCOMMITTED transaction for extra safety.
            // This prevents any accidental writes and uses dirty reads
            // for better performance on read-only queries.
            await using var transaction = connection.BeginTransaction(
                System.Data.IsolationLevel.ReadUncommitted);

            await using var cmd = new SqlCommand(sqlQuery, connection, transaction)
            {
                CommandTimeout = _options.QueryTimeoutSeconds
            };

            _logger.LogDebug("Executing SQL command against {Database}...", connection.Database);

            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);

            // ---- Read column metadata ----
            for (int i = 0; i < reader.FieldCount; i++)
            {
                result.Columns.Add(new QueryColumn
                {
                    Name = reader.GetName(i),
                    DataType = reader.GetDataTypeName(i)
                });
            }

            _logger.LogDebug("Query returned {ColumnCount} columns: [{Columns}]",
                result.Columns.Count,
                string.Join(", ", result.Columns.Select(c => $"{c.Name}({c.DataType})")));

            // ---- Read rows up to the configured limit ----
            int rowCount = 0;
            while (await reader.ReadAsync(cancellationToken))
            {
                rowCount++;

                // Once we exceed the limit, keep counting total rows but stop storing data
                if (rowCount > _options.MaxRowsReturned)
                {
                    result.IsTruncated = true;
                    continue;
                }

                var row = new Dictionary<string, object?>();
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    var value = reader.IsDBNull(i) ? null : reader.GetValue(i);

                    // Convert values to types that serialize cleanly to JSON/Adaptive Cards
                    row[reader.GetName(i)] = value switch
                    {
                        DateTime dt => dt.ToString("yyyy-MM-dd HH:mm:ss"),
                        DateTimeOffset dto => dto.ToString("yyyy-MM-dd HH:mm:ss zzz"),
                        decimal d => d,       // Keep decimal precision for formatting
                        byte[] bytes => $"[Binary: {bytes.Length} bytes]",
                        _ => value
                    };
                }
                result.Rows.Add(row);
            }

            result.TotalRowCount = rowCount;
            result.IsSuccess = true;

            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;

            _logger.LogInformation(
                "SQL_EXECUTE_DONE success=true rows={RowCount} showing={DisplayedRows} cols={ColCount} truncated={Truncated} elapsedMs={ElapsedMs}",
                rowCount, result.Rows.Count, result.Columns.Count,
                result.IsTruncated, stopwatch.ElapsedMilliseconds);

            object? preview = null;
            if (_traceOptions.IncludeDbPreview && result.Rows.Count > 0)
            {
                var first = result.Rows[0];
                preview = first.Count > 0
                    ? first.Take(6).ToDictionary(k => k.Key, v => v.Value)
                    : null;
            }
            _trace.Step("DB_EXECUTION", "db_exec",
                outgoing: new { queryId, sqlPreview = LogText.OneLine(sqlQuery, 300) },
                incoming: new { rows = result.TotalRowCount, cols = result.Columns.Count, truncated = result.IsTruncated, preview },
                success: true,
                sqlText: sqlQuery,
                dbRows: result.TotalRowCount,
                dbCols: result.Columns.Count,
                dbTruncated: result.IsTruncated);
        }
        catch (OperationCanceledException)
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = "Query execution was cancelled.";

            _logger.LogWarning("Query execution cancelled after {ElapsedMs}ms",
                stopwatch.ElapsedMilliseconds);
        }
        catch (SqlException ex) when (ex.Number == -2) // Timeout
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"Query timed out after {_options.QueryTimeoutSeconds} seconds. Try narrowing your query with WHERE clauses or TOP.";

            _logger.LogWarning(
                "SQL_EXECUTE_DONE success=false timeout=true queryId={QueryId} elapsedMs={ElapsedMs} timeoutSec={TimeoutSeconds}",
                queryId,
                stopwatch.ElapsedMilliseconds,
                _options.QueryTimeoutSeconds);

            _trace.Step("DB_EXECUTION", "db_exec",
                outgoing: new { queryId, sqlPreview = LogText.OneLine(sqlQuery, 300) },
                incoming: new { timeout = true },
                success: false,
                error: result.ErrorMessage,
                sqlText: sqlQuery);
        }
        catch (SqlException ex)
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"SQL Error #{ex.Number}: {ex.Message}";

            _logger.LogError(ex,
                "SQL_EXECUTE_DONE success=false queryId={QueryId} sqlErrorNumber={ErrorNumber} state={State} class={Class} elapsedMs={ElapsedMs}",
                queryId,
                ex.Number,
                ex.State,
                ex.Class,
                stopwatch.ElapsedMilliseconds);

            _trace.Step("DB_EXECUTION", "db_exec",
                outgoing: new { queryId, sqlPreview = LogText.OneLine(sqlQuery, 300) },
                incoming: new { sqlErrorNumber = ex.Number },
                success: false,
                error: result.ErrorMessage,
                sqlText: sqlQuery);
        }
        catch (ConnectionFactoryException ex)
        {
            // Connection creation failed — already logged in the factory
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"Database connection failed: {ex.Message}";

            _logger.LogError(ex,
                "Connection factory error during query execution: {Error}", ex.Message);

            _trace.Step("DB_EXECUTION", "db_exec",
                outgoing: new { queryId, sqlPreview = LogText.OneLine(sqlQuery, 300) },
                incoming: new { connectionError = true },
                success: false,
                error: result.ErrorMessage,
                sqlText: sqlQuery);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            result.ExecutionTime = stopwatch.Elapsed;
            result.IsSuccess = false;
            result.ErrorMessage = $"Unexpected error: {ex.Message}";

            _logger.LogError(ex,
                "Unexpected error during query execution queryId={QueryId} after {ElapsedMs}ms: {Error}",
                queryId, stopwatch.ElapsedMilliseconds, ex.Message);
        }

        return result;
    }
}
