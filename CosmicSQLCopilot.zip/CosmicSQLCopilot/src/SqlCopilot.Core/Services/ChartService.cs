// ============================================================================
// ChartService.cs — Chart image generation via QuickChart.io
//
// Purpose:
//   Generates chart visualization URLs for query results using QuickChart.io,
//   a free Chart.js rendering service. The chart configuration is encoded as
//   a JSON query parameter in the URL — the URL itself IS the image.
//
// Supported chart types:
//   Bar, HorizontalBar, Pie, Doughnut, Line
//
// How it works:
//   1. Extracts label and numeric value columns from QueryResult
//   2. Builds a Chart.js configuration object
//   3. Serializes to JSON and URL-encodes it
//   4. Returns a QuickChart.io URL that renders the chart as a PNG
//
// Limitations:
//   - QuickChart URL limit is ~16KB; data is auto-trimmed if exceeded
//   - Requires at least one label column and one numeric column
//
// See also:
//   - Adaptive Cards (where the chart URL is embedded): `Services/AdaptiveCardService.cs`
//   - Result shape contract: `Models/QueryResult.cs`
//   - Chart type enum suggested by the LLM: `Models/NL2SqlRequest.cs` (`ChartType`)
//   - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Globalization;
using System.Text.Json;
using System.Web;
using Microsoft.Extensions.Logging;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Generates chart images via QuickChart.io — a free Chart.js rendering service.
/// Constructs a URL with the chart configuration; the URL itself IS the image.
/// No server-side image rendering is needed.
/// </summary>
public class ChartService : IChartService
{
    /// <summary>Base URL for the QuickChart.io chart API.</summary>
    private const string QuickChartBase = "https://quickchart.io/chart";

    /// <summary>Chart image width in pixels.</summary>
    private const int ChartWidth = 600;

    /// <summary>Chart image height in pixels.</summary>
    private const int ChartHeight = 400;

    /// <summary>Maximum characters for axis labels before truncation.</summary>
    private const int MaxLabelLength = 25;

    /// <summary>
    /// Professional color palette for chart datasets.
    /// Uses RGBA with 80% opacity for fill, 100% for borders.
    /// </summary>
    private static readonly string[] ChartColors = new[]
    {
        "rgba(54, 162, 235, 0.8)",   // Blue
        "rgba(255, 99, 132, 0.8)",   // Red
        "rgba(75, 192, 192, 0.8)",   // Teal
        "rgba(255, 206, 86, 0.8)",   // Yellow
        "rgba(153, 102, 255, 0.8)",  // Purple
        "rgba(255, 159, 64, 0.8)",   // Orange
        "rgba(46, 204, 113, 0.8)",   // Green
        "rgba(142, 68, 173, 0.8)",   // Dark Purple
        "rgba(52, 73, 94, 0.8)",     // Dark Blue-Grey
        "rgba(231, 76, 60, 0.8)",    // Dark Red
        "rgba(26, 188, 156, 0.8)",   // Turquoise
        "rgba(241, 196, 15, 0.8)"    // Dark Yellow
    };

    /// <summary>Matching border colors at 100% opacity.</summary>
    private static readonly string[] BorderColors = new[]
    {
        "rgba(54, 162, 235, 1)",
        "rgba(255, 99, 132, 1)",
        "rgba(75, 192, 192, 1)",
        "rgba(255, 206, 86, 1)",
        "rgba(153, 102, 255, 1)",
        "rgba(255, 159, 64, 1)",
        "rgba(46, 204, 113, 1)",
        "rgba(142, 68, 173, 1)",
        "rgba(52, 73, 94, 1)",
        "rgba(231, 76, 60, 1)",
        "rgba(26, 188, 156, 1)",
        "rgba(241, 196, 15, 1)"
    };

    private readonly ILogger<ChartService> _logger;

    /// <summary>
    /// Initializes the chart service.
    /// </summary>
    /// <param name="logger">Logger for diagnostics.</param>
    public ChartService(ILogger<ChartService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Determines whether a chart can be rendered for the given result and type.
    /// Requires at least 2 columns (label + value), at least one row,
    /// and both a label column and a numeric column.
    /// </summary>
    /// <param name="result">The query result to check.</param>
    /// <param name="chartType">The requested chart type.</param>
    /// <returns><c>true</c> if a chart can be rendered.</returns>
    public bool CanRenderChart(QueryResult result, ChartType chartType)
    {
        // Table type doesn't need chart rendering
        if (chartType == ChartType.Table) return false;
        if (!result.IsSuccess || result.Rows.Count == 0) return false;
        if (result.Columns.Count < 2) return false;

        // Need at least one string/label column and one numeric column
        var canRender = HasLabelsAndValues(result);
        _logger.LogDebug(
            "CanRenderChart({ChartType}): {CanRender} — " +
            "{RowCount} rows, {ColCount} columns",
            chartType, canRender, result.Rows.Count, result.Columns.Count);

        return canRender;
    }

    /// <summary>
    /// Generates a QuickChart.io URL that renders the query results as a chart image.
    /// Returns <c>null</c> if the chart cannot be generated (insufficient data,
    /// URL too large after trimming, etc.).
    /// </summary>
    /// <param name="result">The query result to visualize.</param>
    /// <param name="chartType">The type of chart to generate.</param>
    /// <returns>The chart image URL, or <c>null</c> on failure.</returns>
    public string? GenerateChartUrl(QueryResult result, ChartType chartType)
    {
        try
        {
            if (!CanRenderChart(result, chartType))
            {
                _logger.LogDebug("Cannot render {ChartType} chart for this result", chartType);
                return null;
            }

            // Extract label and value data from the query result
            var (labels, datasets) = ExtractChartData(result, chartType);

            if (labels.Count == 0)
            {
                _logger.LogWarning("No labels extracted from query result for {ChartType} chart", chartType);
                return null;
            }

            // Build the Chart.js configuration object
            var chartConfig = BuildChartConfig(chartType, labels, datasets);
            var chartJson = JsonSerializer.Serialize(chartConfig);

            // Construct the QuickChart URL with chart config as a query parameter
            var url = $"{QuickChartBase}?c={HttpUtility.UrlEncode(chartJson)}&w={ChartWidth}&h={ChartHeight}&bkg=white&f=png";

            // QuickChart has a URL length limit of ~16KB; trim data if exceeded
            if (url.Length > 16000)
            {
                _logger.LogWarning(
                    "Chart URL too long ({Length} chars), trimming to 15 rows and retrying",
                    url.Length);

                var trimmed = TrimResult(result, 15);
                var (tLabels, tDatasets) = ExtractChartData(trimmed, chartType);
                chartConfig = BuildChartConfig(chartType, tLabels, tDatasets);
                chartJson = JsonSerializer.Serialize(chartConfig);
                url = $"{QuickChartBase}?c={HttpUtility.UrlEncode(chartJson)}&w={ChartWidth}&h={ChartHeight}&bkg=white&f=png";

                if (url.Length > 16000)
                {
                    _logger.LogError(
                        "Chart URL still too long ({Length} chars) after trimming. Giving up.",
                        url.Length);
                    return null;
                }
            }

            _logger.LogInformation(
                "Generated {ChartType} chart URL ({Length} chars, {LabelCount} labels, {DatasetCount} datasets)",
                chartType, url.Length, labels.Count, datasets.Count);

            return url;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Failed to generate {ChartType} chart URL: {Error}",
                chartType, ex.Message);
            return null;
        }
    }

    /// <summary>
    /// Extracts label strings and numeric datasets from a <see cref="QueryResult"/>.
    /// The first non-numeric column becomes the label axis; all numeric columns
    /// become separate datasets.
    /// </summary>
    private static (List<string> Labels, List<DatasetInfo> Datasets) ExtractChartData(
        QueryResult result, ChartType chartType)
    {
        var labels = new List<string>();
        var datasets = new List<DatasetInfo>();

        // Identify which column is the label (first string/date column)
        // and which are the value columns (numeric)
        var labelColIndex = -1;
        var valueColIndices = new List<int>();

        for (int i = 0; i < result.Columns.Count; i++)
        {
            if (labelColIndex == -1 && IsLabelColumn(result, i))
            {
                labelColIndex = i;
            }
            else if (IsNumericColumn(result, i))
            {
                valueColIndices.Add(i);
            }
        }

        // Fallback: if no label column found, use first column; rest are values
        if (labelColIndex == -1)
        {
            labelColIndex = 0;
            valueColIndices = Enumerable.Range(1, result.Columns.Count - 1).ToList();
        }
        if (valueColIndices.Count == 0 && result.Columns.Count > 1)
        {
            valueColIndices.Add(labelColIndex == 0 ? 1 : 0);
        }

        var labelColName = result.Columns[labelColIndex].Name;

        // Extract labels from each row, truncating long text
        foreach (var row in result.Rows)
        {
            var labelVal = row.GetValueOrDefault(labelColName)?.ToString() ?? "N/A";
            if (labelVal.Length > MaxLabelLength)
                labelVal = labelVal[..MaxLabelLength] + "\u2026"; // Unicode ellipsis
            labels.Add(labelVal);
        }

        // Extract numeric values for each dataset column
        foreach (var valIdx in valueColIndices)
        {
            var colName = result.Columns[valIdx].Name;
            var values = new List<double>();

            foreach (var row in result.Rows)
            {
                var val = row.GetValueOrDefault(colName);
                values.Add(ToDouble(val));
            }

            datasets.Add(new DatasetInfo { Label = colName, Values = values });
        }

        return (labels, datasets);
    }

    /// <summary>
    /// Builds a Chart.js configuration object that QuickChart.io can render.
    /// Configures colors, legends, data labels, and axis formatting
    /// based on the chart type.
    /// </summary>
    private static object BuildChartConfig(ChartType chartType, List<string> labels, List<DatasetInfo> datasets)
    {
        // Map our enum to Chart.js type strings
        var type = chartType switch
        {
            ChartType.Bar => "bar",
            ChartType.HorizontalBar => "horizontalBar",
            ChartType.Pie => "pie",
            ChartType.Doughnut => "doughnut",
            ChartType.Line => "line",
            _ => "bar"
        };

        var isPieType = chartType is ChartType.Pie or ChartType.Doughnut;

        // Build dataset objects with appropriate colors
        var chartDatasets = datasets.Select((ds, dsIndex) =>
        {
            if (isPieType)
            {
                // Pie/doughnut: each slice gets a different color
                return new Dictionary<string, object>
                {
                    ["label"] = ds.Label,
                    ["data"] = ds.Values,
                    ["backgroundColor"] = labels.Select((_, i) => ChartColors[i % ChartColors.Length]).ToArray(),
                    ["borderColor"] = labels.Select((_, i) => BorderColors[i % BorderColors.Length]).ToArray(),
                    ["borderWidth"] = 2
                };
            }

            // Bar/line: each dataset gets a single color
            var color = ChartColors[dsIndex % ChartColors.Length];
            var border = BorderColors[dsIndex % BorderColors.Length];

            var dsObj = new Dictionary<string, object>
            {
                ["label"] = ds.Label,
                ["data"] = ds.Values,
                ["backgroundColor"] = color,
                ["borderColor"] = border,
                ["borderWidth"] = 2
            };

            // Line-specific styling: no fill, smooth curves, visible data points
            if (chartType == ChartType.Line)
            {
                dsObj["fill"] = false;
                dsObj["tension"] = 0.3;
                dsObj["pointRadius"] = 4;
            }

            return dsObj;
        }).ToArray();

        // Configure chart options (legend, data labels, scales)
        var options = new Dictionary<string, object>
        {
            ["plugins"] = new Dictionary<string, object>
            {
                ["legend"] = new Dictionary<string, object>
                {
                    ["display"] = true,
                    ["position"] = isPieType ? "right" : "top"
                },
                // Data labels plugin shows values/percentages on the chart
                ["datalabels"] = new Dictionary<string, object>
                {
                    ["display"] = isPieType,
                    ["color"] = "#fff",
                    ["font"] = new { weight = "bold", size = 11 },
                    ["formatter"] = isPieType
                        ? "(value, ctx) => { let sum = ctx.dataset.data.reduce((a,b) => a+b, 0); let pct = (value*100/sum).toFixed(1); return pct + '%'; }"
                        : "(value) => value"
                }
            }
        };

        // Add axis scales for non-pie charts
        if (!isPieType)
        {
            options["scales"] = new Dictionary<string, object>
            {
                ["yAxes"] = new object[]
                {
                    new Dictionary<string, object>
                    {
                        ["ticks"] = new { beginAtZero = true }
                    }
                },
                ["xAxes"] = new object[]
                {
                    new Dictionary<string, object>
                    {
                        ["ticks"] = new { autoSkip = true, maxTicksLimit = 20 }
                    }
                }
            };
        }

        return new
        {
            type,
            data = new
            {
                labels,
                datasets = chartDatasets
            },
            options
        };
    }

    /// <summary>
    /// Checks whether the result has at least one label column and one numeric column.
    /// Both are required for chart rendering.
    /// </summary>
    private static bool HasLabelsAndValues(QueryResult result)
    {
        bool hasLabel = false, hasValue = false;
        for (int i = 0; i < result.Columns.Count; i++)
        {
            if (IsLabelColumn(result, i)) hasLabel = true;
            if (IsNumericColumn(result, i)) hasValue = true;
        }
        return hasLabel && hasValue;
    }

    /// <summary>
    /// Determines if a column should be used as chart labels.
    /// String, char, and date types are considered label columns.
    /// Falls back to checking actual values if the data type is ambiguous.
    /// </summary>
    private static bool IsLabelColumn(QueryResult result, int colIndex)
    {
        var colName = result.Columns[colIndex].Name;
        var dataType = result.Columns[colIndex].DataType.ToLowerInvariant();

        // String/date types are natural label columns
        if (dataType.Contains("char") || dataType.Contains("text") || dataType.Contains("date")
            || dataType == "nvarchar" || dataType == "varchar" || dataType == "nchar")
            return true;

        // Check actual data: if the first value is a non-numeric string, treat as label
        if (result.Rows.Count > 0)
        {
            var firstVal = result.Rows[0].GetValueOrDefault(colName);
            return firstVal is string s && !double.TryParse(s, out _);
        }

        return false;
    }

    /// <summary>
    /// Determines if a column contains numeric data suitable for chart values.
    /// </summary>
    private static bool IsNumericColumn(QueryResult result, int colIndex)
    {
        var dataType = result.Columns[colIndex].DataType.ToLowerInvariant();
        return dataType is "int" or "bigint" or "smallint" or "tinyint"
            or "decimal" or "numeric" or "float" or "real" or "money" or "smallmoney";
    }

    /// <summary>
    /// Safely converts any value to a double for chart data.
    /// Returns 0 for null or non-convertible values.
    /// </summary>
    private static double ToDouble(object? value)
    {
        return value switch
        {
            null => 0,
            int i => i,
            long l => l,
            decimal d => (double)d,
            double dbl => dbl,
            float f => f,
            short s => s,
            byte b => b,
            string str => double.TryParse(str, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : 0,
            _ => 0
        };
    }

    /// <summary>
    /// Creates a trimmed copy of a <see cref="QueryResult"/> with fewer rows.
    /// Used when the chart URL would exceed QuickChart's size limit.
    /// </summary>
    /// <param name="original">The original query result.</param>
    /// <param name="maxRows">Maximum rows to keep.</param>
    /// <returns>A new <see cref="QueryResult"/> with at most <paramref name="maxRows"/> rows.</returns>
    private static QueryResult TrimResult(QueryResult original, int maxRows)
    {
        return new QueryResult
        {
            IsSuccess = original.IsSuccess,
            SqlQuery = original.SqlQuery,
            Columns = original.Columns,
            Rows = original.Rows.Take(maxRows).ToList(),
            TotalRowCount = original.TotalRowCount,
            IsTruncated = true,
            ExecutionTime = original.ExecutionTime
        };
    }

    /// <summary>
    /// Internal model for a chart dataset (one series of values).
    /// </summary>
    private class DatasetInfo
    {
        /// <summary>Dataset label (column name).</summary>
        public string Label { get; set; } = "";

        /// <summary>Numeric values for each data point.</summary>
        public List<double> Values { get; set; } = new();
    }
}
