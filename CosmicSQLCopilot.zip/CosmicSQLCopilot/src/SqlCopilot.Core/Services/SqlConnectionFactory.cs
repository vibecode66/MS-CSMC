// ============================================================================
// SqlConnectionFactory.cs — Azure SQL connection factory with Managed Identity
//
// Purpose:
//   Creates SqlConnection instances, handling both Managed Identity (MI) and
//   traditional SQL authentication. When MI is enabled, acquires an Azure AD
//   token using DefaultAzureCredential and attaches it to the connection.
//
// Auth modes:
//   UseManagedIdentity = true  → DefaultAzureCredential (MI, Azure CLI, VS)
//   UseManagedIdentity = false → SQL auth (user/password in connection string)
//
// Dependencies:
//   - Azure.Identity for DefaultAzureCredential
//   - Microsoft.Data.SqlClient for SqlConnection
//
// See also:
//   - Query execution: `Services/QueryExecutionService.cs`
//   - Schema discovery: `Services/SchemaDiscoveryService.cs`
//   - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Diagnostics;
using System.Collections.Concurrent;
using Azure.Core;
using Azure.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Creates <see cref="SqlConnection"/> instances with support for both Managed Identity
/// (DefaultAzureCredential) and traditional SQL authentication.
/// <para>
/// When <see cref="AzureSqlOptions.UseManagedIdentity"/> is <c>true</c>:
///   Uses <see cref="DefaultAzureCredential"/> to acquire an Azure AD token.
///   Works with System-assigned MI, User-assigned MI, Azure CLI, VS credentials, etc.
///   Connection string should NOT contain User ID / Password.
/// </para>
/// <para>
/// When <see cref="AzureSqlOptions.UseManagedIdentity"/> is <c>false</c>:
///   Uses the connection string as-is (SQL auth with embedded credentials).
/// </para>
/// </summary>
public class SqlConnectionFactory : ISqlConnectionFactory
{
    /// <summary>
    /// The OAuth2 scope required to acquire a token for Azure SQL Database.
    /// This is the standard resource URI for Azure SQL.
    /// </summary>
    private static readonly string[] AzureSqlScopes = new[] { "https://database.windows.net/.default" };

    private readonly AzureSqlOptions _options;
    private readonly ILogger<SqlConnectionFactory> _logger;
    private readonly string _connectionString;
    private readonly ConcurrentDictionary<string, DefaultAzureCredential> _credentialByClientId = new();

    /// <summary>
    /// Initializes the factory, configuring the credential based on app settings.
    /// </summary>
    /// <param name="options">Azure SQL configuration (connection string, MI settings).</param>
    /// <param name="logger">Logger for diagnostics.</param>
    public SqlConnectionFactory(
        IOptions<AzureSqlOptions> options,
        ILogger<SqlConnectionFactory> logger)
    {
        _options = (options ?? throw new ArgumentNullException(nameof(options))).Value;
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        _connectionString = (_options.ConnectionString ?? "").Trim();

        if (_options.UseManagedIdentity)
        {
            _logger.LogInformation(
                "SqlConnectionFactory initialized with Managed Identity (MI ClientId: {ClientId})",
                string.IsNullOrWhiteSpace(_options.ManagedIdentityClientId) ? "<system-assigned>" : _options.ManagedIdentityClientId);
        }
        else
        {
            _logger.LogInformation(
                "SqlConnectionFactory initialized with SQL connection string authentication");
        }
    }

    /// <summary>
    /// Creates and opens a new <see cref="SqlConnection"/>.
    /// If Managed Identity is configured, acquires an Azure AD token first.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>An open <see cref="SqlConnection"/> ready for use.</returns>
    /// <exception cref="ConnectionFactoryException">
    /// Thrown when connection or token acquisition fails.
    /// </exception>
    public async Task<SqlConnection> CreateConnectionAsync(CancellationToken cancellationToken = default)
    {
        var stopwatch = Stopwatch.StartNew();
        SqlConnection? connection = null;

        try
        {
            _logger.LogDebug("Creating SQL connection to Azure SQL Database...");

            connection = new SqlConnection(_connectionString);

            if (_options.UseManagedIdentity)
            {
                var tokenRequest = new TokenRequestContext(AzureSqlScopes);
                var miClientId = (_options.ManagedIdentityClientId ?? "").Trim();

                try
                {
                    var sys = GetOrCreateCredential("");
                    _logger.LogDebug("Acquiring Azure AD token for SQL Database (MI: <system-assigned>)...");
                    var token = await sys.GetTokenAsync(tokenRequest, cancellationToken);
                    connection.AccessToken = token.Token;
                    _logger.LogDebug(
                        "Azure AD token acquired successfully, expires at {ExpiresOn}",
                        token.ExpiresOn);
                }
                catch (AuthenticationFailedException exSys) when (!string.IsNullOrWhiteSpace(miClientId))
                {
                    _logger.LogWarning(exSys,
                        "System-assigned MI token acquisition failed. Trying user-assigned MI ClientId={ClientId}.",
                        miClientId);

                    var uai = GetOrCreateCredential(miClientId);
                    var token = await uai.GetTokenAsync(tokenRequest, cancellationToken);
                    connection.AccessToken = token.Token;
                    _logger.LogInformation(
                        "User-assigned MI token acquisition succeeded (ClientId={ClientId}). ExpiresAt={ExpiresOn}",
                        miClientId,
                        token.ExpiresOn);
                }
            }

            await connection.OpenAsync(cancellationToken);

            stopwatch.Stop();
            _logger.LogInformation(
                "SQL connection established to {Database} in {ElapsedMs}ms",
                connection.Database, stopwatch.ElapsedMilliseconds);

            return connection;
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("SQL connection creation was cancelled");
            connection?.Dispose();
            throw;
        }
        catch (AuthenticationFailedException ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex,
                "Azure AD authentication failed after {ElapsedMs}ms. Error: {ErrorMessage}",
                stopwatch.ElapsedMilliseconds, ex.Message);

            connection?.Dispose();
            throw new ConnectionFactoryException(
                $"Failed to authenticate with Azure AD: {ex.Message}",
                ex,
                usingMI: true);
        }
        catch (SqlException ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex,
                "SQL connection failed after {ElapsedMs}ms. SqlError #{ErrorNumber}: {ErrorMessage}",
                stopwatch.ElapsedMilliseconds, ex.Number, ex.Message);

            connection?.Dispose();
            throw new ConnectionFactoryException(
                $"SQL connection failed (Error #{ex.Number}): {ex.Message}",
                ex,
                usingMI: _options.UseManagedIdentity);
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            _logger.LogError(ex,
                "Unexpected error creating SQL connection after {ElapsedMs}ms: {ErrorMessage}",
                stopwatch.ElapsedMilliseconds, ex.Message);

            connection?.Dispose();
            throw new ConnectionFactoryException(
                $"Unexpected error creating SQL connection: {ex.Message}",
                ex,
                usingMI: _options.UseManagedIdentity);
        }
    }

    private DefaultAzureCredential GetOrCreateCredential(string managedIdentityClientId)
    {
        var key = (managedIdentityClientId ?? "").Trim();
        return _credentialByClientId.GetOrAdd(key, _ =>
        {
            var credentialOptions = new DefaultAzureCredentialOptions
            {
                ExcludeInteractiveBrowserCredential = true
            };

            if (!string.IsNullOrWhiteSpace(key))
                credentialOptions.ManagedIdentityClientId = key;

            return new DefaultAzureCredential(credentialOptions);
        });
    }
}
