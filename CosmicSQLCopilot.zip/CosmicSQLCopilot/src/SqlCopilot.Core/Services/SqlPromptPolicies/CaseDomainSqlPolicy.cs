using System.Text;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services.SqlPromptPolicies;

internal static class CaseDomainSqlPolicy
{
    public static string For(DatabaseSchema? schema)
    {
        var tables = schema?.Tables ?? new List<TableSchema>();
        if (tables.Count == 0) return "";

        // Only apply in environments that actually expose the case tables.
        if (!HasTable(tables, "eh_incident")) return "";

        var sb = new StringBuilder();
        sb.AppendLine();
        sb.AppendLine("CASE-DOMAIN SQL POLICY (Cosmic / EH case tables):");
        sb.AppendLine("- You are answering questions about Cases/Incidents and related child tables.");
        sb.AppendLine();

        sb.AppendLine("Table selection:");
        sb.AppendLine("- Cases / incidents / tickets / customer / revenue / business function / LOB → dbo.eh_incident");
        sb.AppendLine("- Hold activity / on hold / hold reasons → dbo.eh_msdyn_holdactivity");
        sb.AppendLine("- Action items / automation / manual touch / human touch / executed-by → dbo.eh_msdyn_caseaction");
        sb.AppendLine("- Documents / attachments / form name → dbo.eh_msdyn_casedocument");
        sb.AppendLine();

        sb.AppendLine("Join keys (DO NOT guess; use only these joins when needed):");
        sb.AppendLine("- dbo.eh_incident.[incidentid] = dbo.eh_msdyn_holdactivity.[regardingobjectid]");
        sb.AppendLine("- dbo.eh_incident.[incidentid] = dbo.eh_msdyn_caseaction.[msdyn_case]");
        sb.AppendLine("- dbo.eh_incident.[incidentid] = dbo.eh_msdyn_casedocument.[msdyn_case]");
        sb.AppendLine();

        sb.AppendLine("Key semantics (GUIDs):");
        sb.AppendLine("- Case GUID: dbo.eh_incident.[incidentid] (this is the unique case identifier).");
        sb.AppendLine("- CaseAction row GUID: dbo.eh_msdyn_caseaction.[Id] (unique per action row; not unique per case).");
        sb.AppendLine("- CaseAction foreign key to case: dbo.eh_msdyn_caseaction.[msdyn_case] (joins to incidentid).");
        sb.AppendLine();

        sb.AppendLine("Join rules:");
        sb.AppendLine("- ALWAYS use the join keys above; NEVER invent/guess joins.");
        sb.AppendLine("- Prefer INNER JOIN unless you explicitly need to include cases without matching child rows (then use LEFT JOIN).");
        sb.AppendLine();

        sb.AppendLine("Field selection rules (user-friendly outputs):");
        sb.AppendLine("- Prefer *name columns over *id columns everywhere (IDs are GUIDs and not user-friendly).");
        sb.AppendLine("  Example: use [msdyn_lineofbusinessidname] not [msdyn_lineofbusinessid].");
        sb.AppendLine("- When the user asks for revenue, ALWAYS use dbo.eh_incident.[msdyn_caserevenue_base].");
        sb.AppendLine("- Case classification dimensions are important for analysis: type/subtype/reason/subreason.");
        sb.AppendLine("  Prefer the corresponding ...idname columns (e.g., [msdyn_casetypeidname], [msdyn_casesubtypeidname],");
        sb.AppendLine("  [msdyn_casereasonidname], [msdyn_casesubreasonidname]) over the GUID id columns.");
        sb.AppendLine();

        sb.AppendLine("Common field mappings:");
        sb.AppendLine("- If user asks for created date/created on → use [createdon].");
        sb.AppendLine("- If user asks for resolved/resolution date → use [msdyn_resolveddate].");
        sb.AppendLine("  - Resolved case filter: [msdyn_resolveddate] IS NOT NULL.");
        sb.AppendLine("  - Unresolved case filter: [msdyn_resolveddate] IS NULL.");
        sb.AppendLine("- If user asks for title/subject → use [title].");
        sb.AppendLine("- If user asks for document name/form name → use dbo.eh_msdyn_casedocument.[msdyn_formname].");
        sb.AppendLine();

        sb.AppendLine("Document table selection guidance (dbo.eh_msdyn_casedocument):");
        sb.AppendLine("- Prefer these columns when possible: [msdyn_casenumber], [msdyn_case], [msdyn_formname].");
        sb.AppendLine("- Keep document outputs user-friendly (avoid GUID-only outputs).");
        sb.AppendLine();

        sb.AppendLine("Case action / human-touch policy (dbo.eh_msdyn_caseaction):");
        sb.AppendLine("- For human-touch classification, applicable rows use: ISNULL([statuscodename], '') <> 'Not Applicable'.");
        sb.AppendLine("- Treat names like '%# uami%' as automation identities.");
        sb.AppendLine("- Row flags (apply after the applicable-row filter):");
        sb.AppendLine("  - IsHumanTouch if: [msdyn_execution] = 'Manual'");
        sb.AppendLine("    OR ([msdyn_executedbyname] IS NOT NULL AND [msdyn_executedbyname] NOT LIKE '%# uami%')");
        sb.AppendLine("    OR ([modifiedbyname] IS NOT NULL AND [modifiedbyname] NOT LIKE '%# uami%').");
        sb.AppendLine("  - IsNoHumanTouch if: [msdyn_execution] = 'Automatic'");
        sb.AppendLine("    AND ([msdyn_executedbyname] IS NULL OR [msdyn_executedbyname] LIKE '%# uami%')");
        sb.AppendLine("    AND ([modifiedbyname] IS NULL OR [modifiedbyname] LIKE '%# uami%').");
        sb.AppendLine("- Case-level aggregation (PER CASE; GROUP BY [msdyn_case]):");
        sb.AppendLine("  - HasEvidence = 1 if ANY applicable rows exist for the case.");
        sb.AppendLine("  - HasHumanTouch = MAX(CASE WHEN IsHumanTouch THEN 1 ELSE 0 END).");
        sb.AppendLine("  - HasNoHumanTouch = MAX(CASE WHEN IsNoHumanTouch THEN 1 ELSE 0 END).");
        sb.AppendLine("  - WithoutHumanTouch = HasEvidence=1 AND HasNoHumanTouch=1 AND HasHumanTouch=0 (UNKNOWN if HasEvidence=0).");
        sb.AppendLine("- Percent without human touch: use cases with evidence as the denominator (exclude UNKNOWN).");
        sb.AppendLine("- For \"last N resolved cases\": pick TOP (N) cases from dbo.eh_incident first, then join/aggregate caseaction.");
        sb.AppendLine();

        sb.AppendLine("Counting cases vs. caseaction rows (IMPORTANT):");
        sb.AppendLine("- Joining dbo.eh_incident to dbo.eh_msdyn_caseaction produces multiple rows per case.");
        sb.AppendLine("- If the user asks for a case count / unique cases while selecting caseaction detail rows, do NOT use COUNT(*).");
        sb.AppendLine("- Use COUNT(DISTINCT dbo.eh_incident.[incidentid]) (same id as dbo.eh_msdyn_caseaction.[msdyn_case]).");
        sb.AppendLine("- If you must keep the detailed rowset AND include the unique case count, add a single CaseCount column using a CROSS JOIN to a scalar subquery/CTE that computes COUNT(DISTINCT incidentid) using the SAME filters as the detail query.");
        sb.AppendLine("- When adding a CaseCount to a detail rowset, do NOT change the main query into an aggregate (do NOT add GROUP BY for the detail SELECT). Keep the detail rows and compute CaseCount separately (scalar subquery/CROSS JOIN).");
        sb.AppendLine("- T-SQL limitation: SQL Server does NOT allow COUNT(DISTINCT ...) OVER(). Do not use a DISTINCT window aggregate.");
        sb.AppendLine();

        sb.AppendLine("Action type / action group questions:");
        sb.AppendLine("- If the user asks for top action types or action groups ON CASES, anchor the query on dbo.eh_incident and join dbo.eh_msdyn_caseaction via dbo.eh_incident.[incidentid] = dbo.eh_msdyn_caseaction.[msdyn_case].");
        sb.AppendLine("- For \"last N days on cases\", if the user does not explicitly say action created date, default the time filter to dbo.eh_incident.[createdon].");
        sb.AppendLine("- If the user explicitly asks about resolved cases / resolved date, use dbo.eh_incident.[msdyn_resolveddate] instead.");
        sb.AppendLine("- Preserve the exact requested time window. If the user says last 10 days, do not broaden it to 30 days.");
        sb.AppendLine("- For top action types, group by dbo.eh_msdyn_caseaction.[msdyn_actiontype] and order by the count descending.");
        sb.AppendLine("- For top action groups, group by dbo.eh_msdyn_caseaction.[msdyn_actiongroup] and order by the count descending.");
        sb.AppendLine("- Do NOT exclude Not Applicable action rows by default for general action type/group reporting unless the user explicitly asks for applicable-only actions or the question is about human-touch classification.");
        sb.AppendLine();

        sb.AppendLine("When selecting from child tables (hold/actions/documents):");
        sb.AppendLine("- If the user asks about a specific case by ticket number, filter dbo.eh_incident (e.g., [ticketnumber]) then join to child tables via [incidentid].");
        sb.AppendLine("- Keep SELECT outputs readable (prefer <= 8 columns); include name fields instead of GUID IDs.");
        sb.AppendLine("- Use NULL-safe string filters when needed (e.g., ISNULL([statuscodename], '') <> 'Rejected').");
        sb.AppendLine();

        return sb.ToString();
    }

    private static bool HasTable(List<TableSchema> tables, string tableName)
    {
        tableName = (tableName ?? "").Trim();
        if (tableName.Length == 0) return false;
        return tables.Any(t => string.Equals((t.TableName ?? "").Trim(), tableName, StringComparison.OrdinalIgnoreCase));
    }
}

