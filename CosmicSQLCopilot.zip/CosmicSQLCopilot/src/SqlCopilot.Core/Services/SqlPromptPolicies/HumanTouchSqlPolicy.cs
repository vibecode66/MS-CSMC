using System.Text;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services.SqlPromptPolicies;

/// <summary>
/// Adds highly specific, copy/paste-ready SQL predicates and patterns for
/// "human touch" and "no human touch" (automation-only) questions.
/// Included conditionally to keep the main system prompt smaller.
/// </summary>
internal static class HumanTouchSqlPolicy
{
    public static string For(DatabaseSchema? schema)
    {
        var tables = schema?.Tables ?? new List<TableSchema>();
        if (tables.Count == 0) return "";

        // Only apply when the caseaction table is present.
        if (!HasTable(tables, "eh_msdyn_caseaction")) return "";

        // Ensure required columns exist; otherwise don't include brittle snippets.
        if (!HasColumns(tables, "eh_msdyn_caseaction",
                "Id",
                "msdyn_case",
                "msdyn_execution",
                "msdyn_executedbyname",
                "modifiedbyname",
                "statuscodename"))
            return "";

        var sb = new StringBuilder();
        sb.AppendLine();
        sb.AppendLine("HUMAN TOUCH / NO HUMAN TOUCH SQL SNIPPETS (use EXACT predicates; do not approximate):");
        sb.AppendLine("- Table: dbo.eh_msdyn_caseaction AS ca");
        sb.AppendLine();

        sb.AppendLine("Automation-only (NO HUMAN TOUCH) row filter (copy/paste):");
        sb.AppendLine("  ISNULL(ca.[statuscodename], '') <> 'Not Applicable'");
        sb.AppendLine("  AND ca.[msdyn_execution] = 'Automatic'");
        sb.AppendLine("  AND (ca.[msdyn_executedbyname] IS NULL OR ca.[msdyn_executedbyname] LIKE '%# uami%')");
        sb.AppendLine("  AND (ca.[modifiedbyname] IS NULL OR ca.[modifiedbyname] LIKE '%# uami%')");
        sb.AppendLine();

        sb.AppendLine("If you need only 1 matching automation-only row per case (latest by Id):");
        sb.AppendLine("  ROW_NUMBER() OVER (PARTITION BY ca.[msdyn_case] ORDER BY ca.[Id] DESC) AS rn");
        sb.AppendLine("  ... WHERE rn = 1");
        sb.AppendLine();

        sb.AppendLine("For last-N resolved case questions:");
        sb.AppendLine("  Build the TOP (N) resolved-case cohort from dbo.eh_incident first.");
        sb.AppendLine("  Then aggregate dbo.eh_msdyn_caseaction per case (GROUP BY ca.[msdyn_case]) to compute HasEvidence / HasHumanTouch / HasNoHumanTouch.");
        sb.AppendLine("  Then LEFT JOIN that per-case aggregate back to the cohort so cases with no applicable caseaction rows stay visible as UNKNOWN / no evidence.");
        sb.AppendLine("  Do NOT use an INNER JOIN from the cohort directly to caseaction when the user asked about the last N cases.");
        sb.AppendLine();

        sb.AppendLine("For count questions about human touch:");
        sb.AppendLine("  Do NOT answer with only a single CasesWithHumanTouch or CasesWithoutHumanTouch number.");
        sb.AppendLine("  Return a single summary row that keeps cohort coverage visible.");
        sb.AppendLine("  Include: TotalResolvedCases, CasesWithEvidence, ExcludedNoEvidence, and the requested human-touch count.");
        sb.AppendLine();

        sb.AppendLine("Important notes:");
        sb.AppendLine("- Filter out 'Not Applicable' with ISNULL(statuscodename,'') <> 'Not Applicable' (NULL-safe).");
        sb.AppendLine("- Use the above automation-only predicate when building larger queries (joins/cohorts/KPIs).");
        sb.AppendLine("- Do not LEFT JOIN classify missing caseaction rows as human/no-human touch; treat them as UNKNOWN evidence.");
        sb.AppendLine();

        return sb.ToString();
    }

    private static bool HasTable(List<TableSchema> tables, string tableName)
    {
        tableName = (tableName ?? "").Trim();
        if (tableName.Length == 0) return false;
        return tables.Any(t => string.Equals((t.TableName ?? "").Trim(), tableName, StringComparison.OrdinalIgnoreCase));
    }

    private static bool HasColumns(List<TableSchema> tables, string tableName, params string[] requiredColumns)
    {
        requiredColumns ??= Array.Empty<string>();
        if (requiredColumns.Length == 0) return true;

        var table = tables.FirstOrDefault(t =>
            string.Equals((t.TableName ?? "").Trim(), (tableName ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
        if (table is null) return false;

        var cols = (table.Columns ?? new List<ColumnSchema>())
            .Select(c => (c.ColumnName ?? "").Trim())
            .Where(s => s.Length > 0)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var rc in requiredColumns)
        {
            var name = (rc ?? "").Trim();
            if (name.Length == 0) continue;
            if (!cols.Contains(name)) return false;
        }

        return true;
    }
}

