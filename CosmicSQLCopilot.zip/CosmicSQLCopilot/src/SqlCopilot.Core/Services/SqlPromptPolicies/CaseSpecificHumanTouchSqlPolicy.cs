using System.Text;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services.SqlPromptPolicies;

/// <summary>
/// Adds narrower guidance for single-case human-touch questions so the model
/// does not answer a case-specific question with cohort/KPI-style logic.
/// </summary>
internal static class CaseSpecificHumanTouchSqlPolicy
{
    public static string For(DatabaseSchema? schema)
    {
        var tables = schema?.Tables ?? new List<TableSchema>();
        if (tables.Count == 0) return "";

        if (!HasTable(tables, "eh_incident")) return "";
        if (!HasTable(tables, "eh_msdyn_caseaction")) return "";

        if (!HasColumns(tables, "eh_incident",
                "incidentid",
                "ticketnumber"))
            return "";

        if (!HasColumns(tables, "eh_msdyn_caseaction",
                "msdyn_case",
                "msdyn_execution",
                "msdyn_executedbyname",
                "modifiedbyname",
                "statuscodename"))
            return "";

        var sb = new StringBuilder();
        sb.AppendLine();
        sb.AppendLine("CASE-SPECIFIC HUMAN TOUCH POLICY (single case / ticket questions):");
        sb.AppendLine("- Applies when the user asks about one specific case or ticket.");
        sb.AppendLine("- For a single case, first filter dbo.eh_incident to the exact case/ticket, then join dbo.eh_msdyn_caseaction using dbo.eh_incident.[incidentid] = dbo.eh_msdyn_caseaction.[msdyn_case].");
        sb.AppendLine("- Do NOT answer a single-case question with cohort fields like TotalResolvedCases, CasesWithEvidence, or ExcludedNoEvidence unless the user explicitly asked for a cohort.");
        sb.AppendLine("- If the user says \"how many human actions were needed\", interpret that narrowly as: how many applicable dbo.eh_msdyn_caseaction rows for that case match the human-touch heuristic.");
        sb.AppendLine("- Do NOT claim the query proves whether human work was truly needed; it only counts rows classified as human-touch by the available caseaction data.");
        sb.AppendLine("- Prefer a compact result for one case: TicketNumber, ApplicableCaseActionCount, HumanTouchActionCount, AutomationOnlyActionCount.");
        sb.AppendLine("- If the user asks only for the human count, returning HumanTouchActionCount is fine, but keep the explanation explicit that this is a count of matching caseaction rows.");
        sb.AppendLine("- When counting actions for one case, count dbo.eh_msdyn_caseaction rows after filtering out ISNULL(ca.[statuscodename], '') = 'Not Applicable'.");
        sb.AppendLine("- A zero count means no applicable caseaction rows matched the human-touch predicate. It does NOT prove no human work happened anywhere outside this table.");
        sb.AppendLine("- For case-specific detail questions, it is acceptable to return the matching action rows with executed/modified-by fields instead of only a KPI.");
        sb.AppendLine();

        return sb.ToString();
    }

    private static bool HasTable(List<TableSchema> tables, string tableName)
    {
        tableName = (tableName ?? "").Trim();
        if (tableName.Length == 0) return false;
        return tables.Any(t => string.Equals((t.TableName ?? "").Trim(), tableName, StringComparison.OrdinalIgnoreCase));
    }

    private static bool HasColumns(List<TableSchema> tables, string tableName, params string[] requiredColumns)
    {
        requiredColumns ??= Array.Empty<string>();
        if (requiredColumns.Length == 0) return true;

        var table = tables.FirstOrDefault(t =>
            string.Equals((t.TableName ?? "").Trim(), (tableName ?? "").Trim(), StringComparison.OrdinalIgnoreCase));
        if (table is null) return false;

        var cols = (table.Columns ?? new List<ColumnSchema>())
            .Select(c => (c.ColumnName ?? "").Trim())
            .Where(s => s.Length > 0)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var rc in requiredColumns)
        {
            var name = (rc ?? "").Trim();
            if (name.Length == 0) continue;
            if (!cols.Contains(name)) return false;
        }

        return true;
    }
}
