// ============================================================================
// InputSanitizer.cs — Sanitize untrusted text before LLM prompt injection
//
// Provides utilities to clean user input and database sample data before
// they are included in LLM prompts, reducing prompt injection attack surface.
// ============================================================================

using System.Text;
using System.Text.RegularExpressions;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Sanitizes untrusted input before inclusion in LLM prompts to mitigate
/// prompt injection attacks.
/// </summary>
public static class InputSanitizer
{
    private const int MaxUserQueryLength = 2000;
    private const int MaxSampleValueLength = 100;

    // Matches markdown code fences (``` or ~~~) which could trick LLM parsing
    private static readonly Regex CodeFenceRegex = new(@"(`{3,}|~{3,})", RegexOptions.Compiled);

    // Matches sequences that look like system prompt delimiters
    private static readonly Regex PromptDelimiterRegex = new(
        @"(---+|===+|###\s*(SYSTEM|DATABASE|ABSOLUTE|RULES|RESPONSE))",
        RegexOptions.Compiled | RegexOptions.IgnoreCase);

    /// <summary>
    /// Sanitizes a user's natural language query before passing to the LLM.
    /// Strips control characters, code fences, and caps length.
    /// </summary>
    public static string SanitizeUserQuery(string? input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        // Truncate to max length
        if (input.Length > MaxUserQueryLength)
            input = input[..MaxUserQueryLength];

        // Remove null bytes and control characters (keep newlines and tabs)
        var sb = new StringBuilder(input.Length);
        foreach (var c in input)
        {
            if (c == '\n' || c == '\r' || c == '\t' || !char.IsControl(c))
                sb.Append(c);
        }

        var cleaned = sb.ToString();

        // Remove code fences that could confuse LLM response parsing
        cleaned = CodeFenceRegex.Replace(cleaned, " ");

        // Neutralize sequences that look like prompt section delimiters
        cleaned = PromptDelimiterRegex.Replace(cleaned, " ");

        return cleaned.Trim();
    }

    /// <summary>
    /// Sanitizes a database sample value before inclusion in schema prompt.
    /// Prevents stored prompt injection via malicious data values.
    /// </summary>
    public static string SanitizeSampleValue(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return string.Empty;

        // Truncate
        if (value.Length > MaxSampleValueLength)
            value = value[..MaxSampleValueLength] + "…";

        // Strip control characters
        var sb = new StringBuilder(value.Length);
        foreach (var c in value)
        {
            if (!char.IsControl(c) || c == ' ')
                sb.Append(c);
        }

        var cleaned = sb.ToString();

        // Neutralize code fences and prompt-like delimiters in data
        cleaned = CodeFenceRegex.Replace(cleaned, "'");
        cleaned = PromptDelimiterRegex.Replace(cleaned, " ");

        return cleaned.Trim();
    }
}
