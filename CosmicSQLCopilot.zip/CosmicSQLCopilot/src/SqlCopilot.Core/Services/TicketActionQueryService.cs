using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Runs a deterministic, parameterized ticket-action query that classifies each
/// action row as AI or Human using a simplified modified-by identity rule.
/// </summary>
public sealed class TicketActionQueryService : ITicketActionQueryService
{
    internal const string DisplaySql = """
SELECT
    ca.[Id] AS [CaseActionId],
    ca.[msdyn_actiontype],
    ca.[msdyn_actiongroup],
    ca.[msdyn_execution],
    ca.[msdyn_executedbyname],
    ca.[modifiedbyname],
    ca.[statuscodename],
    CASE
        WHEN ca.[modifiedbyname] LIKE '%# uami%'
            THEN 'AI'
        ELSE 'Human'
    END AS [AIHuman]
FROM dbo.eh_incident i
LEFT JOIN dbo.eh_msdyn_caseaction ca
    ON i.[incidentid] = ca.[msdyn_case]
WHERE i.[ticketnumber] = @ticketNumber
  AND ISNULL(i.[IsDeleted], 0) = 0
  AND ISNULL(ca.[statuscodename], '') <> 'Not Applicable'
ORDER BY ca.[createdon] DESC, ca.[Id] DESC;
""";

    private readonly ISqlConnectionFactory _connectionFactory;
    private readonly ILogger<TicketActionQueryService> _logger;

    public TicketActionQueryService(
        ISqlConnectionFactory connectionFactory,
        ILogger<TicketActionQueryService> logger)
    {
        _connectionFactory = connectionFactory ?? throw new ArgumentNullException(nameof(connectionFactory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<QueryResult> ExecuteTicketActionsAsync(
        string ticketNumber,
        CancellationToken cancellationToken = default)
    {
        ticketNumber = (ticketNumber ?? "").Trim();
        var result = new QueryResult { SqlQuery = DisplaySql };
        if (ticketNumber.Length == 0)
        {
            result.IsSuccess = false;
            result.ErrorMessage = "Ticket number is required.";
            return result;
        }

        var stopwatch = Stopwatch.StartNew();

        try
        {
            await using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
            await using var cmd = new SqlCommand(DisplaySql, connection)
            {
                CommandTimeout = 30
            };
            cmd.Parameters.Add(new SqlParameter("@ticketNumber", System.Data.SqlDbType.NVarChar, 100) { Value = ticketNumber });

            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            for (var i = 0; i < reader.FieldCount; i++)
            {
                result.Columns.Add(new QueryColumn
                {
                    Name = reader.GetName(i),
                    DataType = reader.GetDataTypeName(i)
                });
            }

            var rowCount = 0;
            while (await reader.ReadAsync(cancellationToken))
            {
                rowCount++;
                var row = new Dictionary<string, object?>();
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    var value = reader.IsDBNull(i) ? null : reader.GetValue(i);
                    row[reader.GetName(i)] = value switch
                    {
                        DateTime dt => dt.ToString("yyyy-MM-dd HH:mm:ss"),
                        DateTimeOffset dto => dto.ToString("yyyy-MM-dd HH:mm:ss zzz"),
                        decimal d => d,
                        byte[] bytes => $"[Binary: {bytes.Length} bytes]",
                        _ => value
                    };
                }
                result.Rows.Add(row);
            }

            stopwatch.Stop();
            result.IsSuccess = true;
            result.TotalRowCount = rowCount;
            result.IsTruncated = false;
            result.ExecutionTime = stopwatch.Elapsed;

            _logger.LogInformation(
                "TICKET_ACTION_QUERY_DONE ticket={Ticket} rows={Rows} elapsedMs={ElapsedMs}",
                ticketNumber,
                rowCount,
                stopwatch.ElapsedMilliseconds);
            return result;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            stopwatch.Stop();
            result.IsSuccess = false;
            result.ErrorMessage = ex.Message;
            result.ExecutionTime = stopwatch.Elapsed;
            _logger.LogError(ex,
                "TICKET_ACTION_QUERY_FAILED ticket={Ticket} error={Error}",
                ticketNumber,
                ex.Message);
            return result;
        }
    }
}
