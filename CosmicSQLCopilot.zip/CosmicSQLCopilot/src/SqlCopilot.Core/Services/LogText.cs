using System.Text.Json;
using System.Text.RegularExpressions;

namespace SqlCopilot.Core.Services;

internal static class LogText
{
    private static readonly Regex MultiWhitespace = new(@"\s+", RegexOptions.Compiled);

    public static string Trunc(string? s, int maxChars)
    {
        s ??= "";
        maxChars = Math.Clamp(maxChars, 16, 200_000);
        return s.Length <= maxChars ? s : s[..maxChars] + "...";
    }

    public static string OneLine(string? s, int maxChars)
    {
        s ??= "";
        s = s.Replace("\r\n", "\n").Replace('\r', '\n');
        s = MultiWhitespace.Replace(s, " ").Trim();
        return Trunc(s, maxChars);
    }

    public static string Json(JsonElement el, int maxChars)
    {
        try
        {
            var s = JsonSerializer.Serialize(el);
            return Trunc(s, maxChars);
        }
        catch
        {
            return "<unserializable_json>";
        }
    }
}

