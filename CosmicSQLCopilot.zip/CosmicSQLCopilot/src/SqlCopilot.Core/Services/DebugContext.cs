using System.Text.RegularExpressions;

namespace SqlCopilot.Core.Services;

/// <summary>
/// Async-scoped debug emitter for a single user turn.
/// When enabled, emits step-by-step messages to the Teams progress callback.
/// </summary>
internal sealed record DebugContext(
    bool Enabled,
    Func<string, Task>? Emit,
    string ConversationId,
    string TurnId)
{
    private static readonly AsyncLocal<DebugContext?> _current = new();

    // Keep Teams messages bounded.
    private const int MaxDebugMessageChars = 3500;

    // Best-effort redaction (avoid accidental key leakage if config ever appears in prompts).
    private static readonly Regex ApiKeyRegex =
        new(@"(api[\s_\-]*key\s*[:=]\s*)([^\s""']+)", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public static DebugContext? Current => _current.Value;

    public static void Set(DebugContext? ctx) => _current.Value = ctx;

    public static void Clear() => _current.Value = null;

    public static bool IsEnabled() => _current.Value?.Enabled == true;

    public static Task WriteAsync(string message)
    {
        var ctx = _current.Value;
        if (ctx is null || !ctx.Enabled) return Task.CompletedTask;
        if (ctx.Emit is null) return Task.CompletedTask;

        message = (message ?? "").Trim();
        if (message.Length == 0) return Task.CompletedTask;

        message = Redact(message);
        message = LogText.Trunc(message, MaxDebugMessageChars);

        // Prefix so users can quickly distinguish debug from “answer” text.
        var payload = $"DEBUG [{ctx.TurnId}]: {message}";
        return ctx.Emit(payload);
    }

    public static Task WriteBlockAsync(string title, string content)
    {
        title = (title ?? "").Trim();
        content = (content ?? "").Trim();
        if (title.Length == 0) title = "debug";

        // Use fenced block; Teams generally renders this cleanly.
        var msg = $"{title}\n```\n{content}\n```";
        return WriteAsync(msg);
    }

    private static string Redact(string s)
    {
        // Replace "apikey=..." or "api key: ..." with "<redacted>".
        return ApiKeyRegex.Replace(s, "$1<redacted>");
    }
}

