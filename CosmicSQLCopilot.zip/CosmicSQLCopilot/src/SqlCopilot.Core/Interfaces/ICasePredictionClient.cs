using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Invokes the upstream SLA prediction service (typically an Azure Function).
///
/// This interface isolates HTTP + serialization from orchestration.
/// See implementation: `Services/CasePredictionClient.cs`.
/// </summary>
public interface ICasePredictionClient
{
    Task<CasePredictionApiResponse> PredictAsync(
        CasePredictionInvokeRequest request,
        CancellationToken cancellationToken = default);
}

