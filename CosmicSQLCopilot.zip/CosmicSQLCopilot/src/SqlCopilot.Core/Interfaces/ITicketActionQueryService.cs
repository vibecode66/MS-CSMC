using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Executes deterministic ticket-specific action queries so Teams questions with
/// a concrete ticket number do not depend on LLM-generated SQL.
/// </summary>
public interface ITicketActionQueryService
{
    Task<QueryResult> ExecuteTicketActionsAsync(
        string ticketNumber,
        CancellationToken cancellationToken = default);
}
