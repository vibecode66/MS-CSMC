using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Orchestrates a single inbound user turn and produces one or more outbound replies.
///
/// This is the primary "business logic" entrypoint for chat channels:
/// the Teams bot passes user text + conversation id and receives structured replies
/// (text and/or Adaptive Card attachments).
///
/// See also:
/// - Implementation: `Services/ConversationOrchestratorService.cs`
/// - Web bot bridge: `src/SqlCopilot.Web/Bot/SqlCopilotBot.cs`
/// - Developer map: `docs/CODE_TOUR.md`
/// </summary>
public interface IConversationOrchestratorService
{
    Task<ConversationTurnResult> HandleAsync(
        string userText,
        string? conversationId,
        CancellationToken cancellationToken = default,
        Func<string, Task>? progress = null,
        string? userAadObjectId = null);
}

