using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Post-query "supervisor" that validates results and chooses final rendering intent
/// (chart vs table, or request a rerun/escalation) before sending to Teams.
/// </summary>
public interface IResultSupervisorService
{
    Task<ResultSupervisorDecision> DecideAsync(
        string userQuery,
        DatabaseSchema schema,
        NL2SqlResponse sqlResponse,
        QueryResult queryResult,
        CancellationToken cancellationToken = default);
}

public enum ResultSupervisorAction
{
    Render,
    RerunSqlQuery,
    UseSqlAgent,
    Clarify
}

public sealed record ResultSupervisorDecision(
    ResultSupervisorAction Action,
    string? Reason = null,
    ChartType? ChartType = null,
    string? UpdatedQuestion = null,
    string? ClarifyQuestion = null,
    string? UserNote = null);

