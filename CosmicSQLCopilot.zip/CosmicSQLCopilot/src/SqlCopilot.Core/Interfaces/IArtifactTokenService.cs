// ============================================================================
// IArtifactTokenService.cs — Interface for signed artifact URL tokens
// ============================================================================

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Generates signed tokens for secure artifact file downloads.
/// Tokens are time-limited and verified server-side.
/// </summary>
public interface IArtifactTokenService
{
    /// <summary>Generates a signed token for the given artifact filename.</summary>
    string GenerateToken(string filename, TimeSpan? expiry = null);

    /// <summary>Validates a token and returns the filename if valid, null otherwise.</summary>
    string? ValidateToken(string token);
}
