// ============================================================================
// ISqlConnectionFactory.cs — Interface for SQL connection creation
// ============================================================================

using Microsoft.Data.SqlClient;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Creates <see cref="SqlConnection"/> instances, handling Managed Identity
/// or SQL authentication based on configuration. The connection is returned
/// in an open state, ready for use.
/// </summary>
public interface ISqlConnectionFactory
{
    /// <summary>
    /// Creates and opens a new <see cref="SqlConnection"/>.
    /// If Managed Identity is configured, an Azure AD token is acquired automatically.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>An open <see cref="SqlConnection"/>.</returns>
    Task<SqlConnection> CreateConnectionAsync(CancellationToken cancellationToken = default);
}
