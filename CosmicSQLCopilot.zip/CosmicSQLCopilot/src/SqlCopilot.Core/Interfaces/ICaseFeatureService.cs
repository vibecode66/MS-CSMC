using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Best-effort feature loader used to enrich case prediction inputs.
///
/// See also:
/// - Implementation: `Services/CaseFeatureService.cs`
/// - Prediction orchestration: `Services/ConversationOrchestratorService.cs`
/// </summary>
public interface ICaseFeatureService
{
    /// <summary>
    /// Attempts to load a case feature record (for prediction) from the database.
    /// Returns null if the case cannot be found or required columns are unavailable.
    /// </summary>
    Task<CasePredictionRecord?> TryGetCasePredictionRecordAsync(
        string ticketNumber,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Attempts to load the latest N case records (for prediction) from the database.
    /// </summary>
    /// <param name="count">Number of latest cases to load (TOP N).</param>
    Task<IReadOnlyList<CasePredictionRecord>> TryGetLatestCasePredictionRecordsAsync(
        int count,
        CancellationToken cancellationToken = default);
}

