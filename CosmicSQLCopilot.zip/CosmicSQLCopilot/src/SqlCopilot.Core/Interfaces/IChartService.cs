// ============================================================================
// IChartService.cs — Interface for chart image generation
// ============================================================================

using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Generates chart image URLs from query results using QuickChart.io.
/// The generated URL is a direct link to a PNG image that can be
/// embedded in Adaptive Cards.
/// </summary>
public interface IChartService
{
    /// <summary>
    /// Generates a QuickChart.io chart image URL for the given result.
    /// </summary>
    /// <param name="result">The query result to visualize.</param>
    /// <param name="chartType">The type of chart to generate.</param>
    /// <returns>The chart image URL, or <c>null</c> if generation fails.</returns>
    string? GenerateChartUrl(QueryResult result, ChartType chartType);

    /// <summary>
    /// Checks whether a chart can be rendered for the given result and type.
    /// Requires at least one label column and one numeric column.
    /// </summary>
    /// <param name="result">The query result to check.</param>
    /// <param name="chartType">The requested chart type.</param>
    /// <returns><c>true</c> if a chart can be rendered.</returns>
    bool CanRenderChart(QueryResult result, ChartType chartType);
}
