// ============================================================================
// IAdaptiveCardService.cs — Interface for Adaptive Card rendering
// ============================================================================

using Microsoft.Bot.Schema;
using SqlCopilot.Core.Agent;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Builds Adaptive Card attachments from query results for display in
/// Teams and M365 Copilot. Automatically selects the best card layout
/// (table, KPI, chart, key-value, etc.) based on the result shape.
/// </summary>
public interface IAdaptiveCardService
{
    /// <summary>
    /// Creates the appropriate Adaptive Card for a successful query result.
    /// Selects the best visualization (table, KPI, chart, etc.) based on
    /// result shape and the LLM's chart suggestion.
    /// </summary>
    /// <param name="result">The SQL query execution result.</param>
    /// <param name="sqlResponse">The LLM response with explanation and chart suggestion.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> containing the Adaptive Card.</returns>
    Attachment CreateResultCard(QueryResult result, NL2SqlResponse sqlResponse);

    /// <summary>
    /// Creates an error card with a warning icon and error description.
    /// </summary>
    /// <param name="errorMessage">The error message to display.</param>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the error card.</returns>
    Attachment CreateErrorCard(string errorMessage);

    /// <summary>
    /// Creates a welcome/onboarding card with example questions and usage tips.
    /// </summary>
    /// <returns>A Bot Framework <see cref="Attachment"/> with the welcome card.</returns>
    Attachment CreateWelcomeCard();

    /// <summary>
    /// Creates a compact summary card for multi-step agent runs.
    /// </summary>
    /// <param name="userQuery">The original user query.</param>
    /// <param name="summary">Bullet summary (each bullet on a new line, prefixed with "- ").</param>
    /// <param name="steps">Steps executed (name + SQL) to optionally reveal.</param>
    Attachment CreateAgentSummaryCard(
        string userQuery,
        string summary,
        IReadOnlyList<(string Name, string Sql)> steps);

    /// <summary>
    /// Creates an Adaptive Card with links to generated report artifacts.
    /// </summary>
    Attachment CreateAgentReportCard(AgentReportLinks reportLinks);

    /// <summary>
    /// Creates an Adaptive Card that renders a schema snapshot directly in the card.
    /// </summary>
    Attachment CreateAgentSchemaCard(string source, string schemaText, int partNumber, int totalParts, bool isTruncated);

    /// <summary>
    /// Creates an Adaptive Card for a case prediction response.
    /// </summary>
    Attachment CreateCasePredictionCard(
        string ticketNumber,
        string? predictedResolutionDateTime,
        string? modelBlob,
        string featuresSummary);

    /// <summary>
    /// Creates an Adaptive Card for a ticket that is already resolved.
    /// Shows the resolved date and the same feature summary used for prediction.
    /// </summary>
    Attachment CreateCaseResolvedCard(
        string ticketNumber,
        string resolvedDateTime,
        string featuresSummary);
}
