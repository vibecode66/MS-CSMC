// ============================================================================
// ISchemaDiscoveryService.cs — Interface for database schema discovery
// ============================================================================

using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Interfaces;

/// <summary>
/// Discovers and caches database schema information from Azure SQL.
/// Schema includes table names, column definitions, primary/foreign keys,
/// and sample data rows for LLM context.
/// </summary>
public interface ISchemaDiscoveryService
{
    /// <summary>
    /// Gets the database schema, returning a cached copy if available.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns>The discovered <see cref="DatabaseSchema"/>.</returns>
    Task<DatabaseSchema> GetSchemaAsync(CancellationToken cancellationToken = default);

    /// <summary>
    /// Forces a refresh of the cached schema by re-reading from the database.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task RefreshSchemaAsync(CancellationToken cancellationToken = default);
}
