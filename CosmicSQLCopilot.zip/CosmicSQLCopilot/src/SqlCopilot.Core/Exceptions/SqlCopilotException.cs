// ============================================================================
// SqlCopilotException.cs — Custom exception hierarchy for the SqlCopilot solution
//
// Purpose:
//   Provides strongly-typed exceptions so callers can distinguish between
//   different failure modes (schema issues, OpenAI errors, SQL execution errors,
//   connection failures) and handle each appropriately.
//
// Hierarchy:
//   SqlCopilotException (base)
//     ├── SchemaDiscoveryException   — failed to read database schema
//     ├── SqlGenerationException     — Azure OpenAI failed to produce valid SQL
//     ├── QueryExecutionException    — SQL query execution failed
//     ├── ConnectionFactoryException — could not establish Azure SQL connection
//     └── CardRenderingException     — Adaptive Card construction failed
// ============================================================================

namespace SqlCopilot.Core.Exceptions;

/// <summary>
/// Base exception for all SqlCopilot-specific errors.
/// Allows top-level handlers to catch any domain error with a single catch block.
/// </summary>
public class SqlCopilotException : Exception
{
    /// <summary>
    /// Initializes a new <see cref="SqlCopilotException"/> with a descriptive message.
    /// </summary>
    /// <param name="message">Human-readable description of the error.</param>
    public SqlCopilotException(string message) : base(message) { }

    /// <summary>
    /// Initializes a new <see cref="SqlCopilotException"/> with a message and inner exception.
    /// </summary>
    /// <param name="message">Human-readable description of the error.</param>
    /// <param name="innerException">The underlying exception that caused this error.</param>
    public SqlCopilotException(string message, Exception innerException)
        : base(message, innerException) { }
}

/// <summary>
/// Thrown when the <see cref="Services.SchemaDiscoveryService"/> cannot read
/// the database schema from INFORMATION_SCHEMA views (e.g., permission denied,
/// connectivity loss, or unexpected metadata format).
/// </summary>
public class SchemaDiscoveryException : SqlCopilotException
{
    /// <summary>The database that was being queried when the error occurred.</summary>
    public string? DatabaseName { get; }

    public SchemaDiscoveryException(string message, string? databaseName = null)
        : base(message)
    {
        DatabaseName = databaseName;
    }

    public SchemaDiscoveryException(string message, Exception innerException, string? databaseName = null)
        : base(message, innerException)
    {
        DatabaseName = databaseName;
    }
}

/// <summary>
/// Thrown when Azure OpenAI fails to generate a valid SQL query from the
/// user's natural-language prompt (e.g., API timeout, malformed JSON response,
/// or all retry attempts exhausted).
/// </summary>
public class SqlGenerationException : SqlCopilotException
{
    /// <summary>The original natural-language query that failed.</summary>
    public string? NaturalLanguageQuery { get; }

    /// <summary>Number of attempts made before giving up.</summary>
    public int AttemptsExhausted { get; }

    public SqlGenerationException(string message, string? query = null, int attempts = 0)
        : base(message)
    {
        NaturalLanguageQuery = query;
        AttemptsExhausted = attempts;
    }

    public SqlGenerationException(string message, Exception innerException,
        string? query = null, int attempts = 0)
        : base(message, innerException)
    {
        NaturalLanguageQuery = query;
        AttemptsExhausted = attempts;
    }
}

/// <summary>
/// Thrown when a generated SQL query fails to execute against Azure SQL Database
/// (e.g., syntax error after all self-healing retries, timeout, or permission issue).
/// </summary>
public class QueryExecutionException : SqlCopilotException
{
    /// <summary>The SQL query that failed.</summary>
    public string? SqlQuery { get; }

    public QueryExecutionException(string message, string? sqlQuery = null)
        : base(message)
    {
        SqlQuery = sqlQuery;
    }

    public QueryExecutionException(string message, Exception innerException, string? sqlQuery = null)
        : base(message, innerException)
    {
        SqlQuery = sqlQuery;
    }
}

/// <summary>
/// Thrown when <see cref="Services.SqlConnectionFactory"/> cannot establish
/// a connection to Azure SQL (e.g., Managed Identity token acquisition failure,
/// network error, or invalid connection string).
/// </summary>
public class ConnectionFactoryException : SqlCopilotException
{
    /// <summary>Whether Managed Identity authentication was being used.</summary>
    public bool WasUsingManagedIdentity { get; }

    public ConnectionFactoryException(string message, bool usingMI = false)
        : base(message)
    {
        WasUsingManagedIdentity = usingMI;
    }

    public ConnectionFactoryException(string message, Exception innerException, bool usingMI = false)
        : base(message, innerException)
    {
        WasUsingManagedIdentity = usingMI;
    }
}

/// <summary>
/// Thrown when Adaptive Card rendering fails (e.g., JSON serialization error
/// or unsupported result shape).
/// </summary>
public class CardRenderingException : SqlCopilotException
{
    /// <summary>The type of card that failed to render.</summary>
    public string? CardType { get; }

    public CardRenderingException(string message, string? cardType = null)
        : base(message)
    {
        CardType = cardType;
    }

    public CardRenderingException(string message, Exception innerException, string? cardType = null)
        : base(message, innerException)
    {
        CardType = cardType;
    }
}
