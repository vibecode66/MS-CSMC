// ============================================================================
// ConversationTurnResult.cs — Bot reply envelope for a single turn
//
// A user "turn" can produce multiple outbound activities:
// - A sequence of Adaptive Cards (e.g., multi-step agent mode)
// - A text clarification question
// - A mixture of text + attachment replies
//
// This file defines the minimal reply shape used by the Web bot layer
// (`src/SqlCopilot.Web/Bot/SqlCopilotBot.cs`) and produced by the Core orchestrator
// (`src/SqlCopilot.Core/Services/ConversationOrchestratorService.cs`).
//
// See also:
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using Microsoft.Bot.Schema;

namespace SqlCopilot.Core.Models;

/// <summary>
/// One outbound bot reply. Exactly one of <see cref="Text"/> or <see cref="Attachment"/>
/// is typically set, but the type allows both to keep composition simple.
/// </summary>
public sealed record BotReply(string? Text = null, Attachment? Attachment = null);

/// <summary>
/// The result of handling a single user turn. A turn may yield multiple replies,
/// especially in agent mode (multiple step cards + a final summary card).
/// </summary>
public sealed record ConversationTurnResult(IReadOnlyList<BotReply> Replies)
{
    public static ConversationTurnResult Text(string text)
        => new(new[] { new BotReply(Text: text) });

    public static ConversationTurnResult Attachment(Attachment attachment)
        => new(new[] { new BotReply(Attachment: attachment) });
}

