namespace SqlCopilot.Core.Models;

/// <summary>
/// Teams-bot access control for SLA (case) prediction.
/// Configure via appsettings.json / App Service Configuration.
/// </summary>
public sealed class SlaPredictionAccessOptions
{
    public const string SectionName = "SlaPredictionAccess";

    /// <summary>Global on/off switch for Teams case prediction.</summary>
    public bool Enabled { get; set; } = true;
}

