namespace SqlCopilot.Core.Models;

/// <summary>
/// Additional, app-specific configuration options for SqlCopilot beyond connection/model settings.
/// Maps to the "SqlCopilot" section in appsettings.json.
/// </summary>
public sealed class SqlCopilotOptions
{
    /// <summary>The configuration section name in appsettings.json.</summary>
    public const string SectionName = "SqlCopilot";

    public SchemaDiscoveryTuningOptions SchemaDiscovery { get; set; } = new();
    public SqlGenerationTuningOptions SqlGeneration { get; set; } = new();
    public AdaptiveCardTuningOptions AdaptiveCards { get; set; } = new();
    public ChartTuningOptions Charts { get; set; } = new();
    public QueryExecutionTuningOptions QueryExecution { get; set; } = new();
}

public sealed class SchemaDiscoveryTuningOptions
{
    /// <summary>Schema to discover tables from (e.g., "dbo").</summary>
    public string TableSchema { get; set; } = "dbo";

    /// <summary>
    /// Optional allowlist of table names to include. When empty, all base tables in <see cref="TableSchema"/> are discovered.
    /// Defaults to the current project’s allowlist.
    /// </summary>
    public List<string> TableAllowList { get; set; } = new() {};

    /// <summary>Sample row count per table included in the schema prompt.</summary>
    public int SampleRowsPerTable { get; set; } = 3;

    /// <summary>Maximum number of columns to include in sample rows (to keep prompts compact).</summary>
    public int SampleMaxColumns { get; set; } = 10;

    /// <summary>Maximum length for any single sample value (long values are truncated).</summary>
    public int SampleValueMaxLength { get; set; } = 50;

    /// <summary>Timeout (seconds) for sample row queries (best-effort).</summary>
    public int SampleQueryTimeoutSeconds { get; set; } = 10;

    /// <summary>When true, uses WITH (NOLOCK) on sample row queries.</summary>
    public bool UseNoLockForSamples { get; set; } = true;
}

public sealed class SqlGenerationTuningOptions
{
    /// <summary>Maximum LLM attempts for execution-error self-healing.</summary>
    public int MaxRetries { get; set; } = 3;
}

public sealed class AdaptiveCardTuningOptions
{
    /// <summary>
    /// Teams message size limit is 28KB; keep card under 25KB for safety margin.
    /// If exceeded, a summary card is returned.
    /// </summary>
    public int MaxCardSizeBytes { get; set; } = 25_000;

    /// <summary>Maximum rows to display in a table card.</summary>
    public int MaxTableRows { get; set; } = 15;

    /// <summary>Maximum columns to display in a table card.</summary>
    public int MaxColumnsInTable { get; set; } = 8;

    /// <summary>Maximum rows to show in the "Show Data Table" toggle for chart cards.</summary>
    public int ChartToggleMaxRows { get; set; } = 20;
}

public sealed class ChartTuningOptions
{
    /// <summary>Base URL for the QuickChart.io chart API.</summary>
    public string QuickChartBaseUrl { get; set; } = "https://quickchart.io/chart";

    /// <summary>Chart image width in pixels.</summary>
    public int Width { get; set; } = 600;

    /// <summary>Chart image height in pixels.</summary>
    public int Height { get; set; } = 400;

    /// <summary>Maximum characters for axis labels before truncation.</summary>
    public int MaxLabelLength { get; set; } = 25;

    /// <summary>Maximum QuickChart URL length (QuickChart limit is ~16KB).</summary>
    public int MaxUrlLength { get; set; } = 16_000;
}

public sealed class QueryExecutionTuningOptions
{
    /// <summary>
    /// When true, wraps query execution in a READ UNCOMMITTED transaction (extra safety + fewer locks).
    /// </summary>
    public bool UseReadUncommittedTransaction { get; set; } = true;
}

