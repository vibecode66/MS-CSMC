namespace SqlCopilot.Core.Models;

/// <summary>
/// Configuration options for the case prediction (SLA regressor) Azure Function.
/// Maps to the "CasePrediction" section in appsettings.json.
/// </summary>
public sealed class CasePredictionOptions
{
    /// <summary>The configuration section name in appsettings.json.</summary>
    public const string SectionName = "CasePrediction";

    /// <summary>
    /// Full HTTP endpoint for the Azure Function.
    /// Example: "https://func-...azurewebsites.net/api/sla-regressor-lightgbm-infer"
    /// </summary>
    // Defaults match the working example in api.txt (UAT).
    public string Endpoint { get; set; } =
        "https://func-sla-lightgbm-infer-uat-eastus.azurewebsites.net/api/sla-regressor-lightgbm-infer";

    public string StorageAccount { get; set; } = "stslalightgbmuateu";
    public string Container { get; set; } = "train-data";
    public string ModelPrefix { get; set; } = "sla-regressor-lightgbm/models/";
    public string OutputPrefix { get; set; } = "sla-regressor-lightgbm/inference-outputs/";

    public bool UploadOutput { get; set; } = false;
    public int MaxReturnRows { get; set; } = 1;

    /// <summary>HTTP timeout for the upstream function call.</summary>
    public int TimeoutSeconds { get; set; } = 60;
}

