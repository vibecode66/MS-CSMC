// ============================================================================
// TableSchema.cs — Database schema models
//
// Purpose:
//   Represents the discovered database schema (tables, columns, keys, sample data).
//   Used to provide context to the LLM for accurate SQL generation.
//   The ToSchemaPrompt() method generates a concise text representation
//   that's appended to the LLM system prompt.
// ============================================================================

using SqlCopilot.Core.Services;

namespace SqlCopilot.Core.Models;

/// <summary>
/// Represents the schema of a database table including its columns,
/// primary/foreign keys, and sample data rows.
/// </summary>
public class TableSchema
{
    /// <summary>The schema name (e.g., "dbo").</summary>
    public string SchemaName { get; set; } = "dbo";

    /// <summary>The table name.</summary>
    public string TableName { get; set; } = string.Empty;

    /// <summary>Fully qualified table name (e.g., "dbo.Cases").</summary>
    public string FullName => SchemaName + "." + TableName;

    /// <summary>Column definitions for this table.</summary>
    public List<ColumnSchema> Columns { get; set; } = new();

    /// <summary>Names of primary key columns.</summary>
    public List<string> PrimaryKeys { get; set; } = new();

    /// <summary>Foreign key relationships from this table to others.</summary>
    public List<ForeignKeyInfo> ForeignKeys { get; set; } = new();

    /// <summary>
    /// Sample rows (up to 3) for LLM context.
    /// Helps the model understand actual data values (e.g., status codes,
    /// category names) so it can generate accurate WHERE clauses.
    /// </summary>
    public List<Dictionary<string, string>> SampleRows { get; set; } = new();
}

/// <summary>
/// Represents a column in a database table.
/// </summary>
public class ColumnSchema
{
    /// <summary>The column name.</summary>
    public string ColumnName { get; set; } = string.Empty;

    /// <summary>The SQL data type (e.g., "nvarchar", "int", "datetime2").</summary>
    public string DataType { get; set; } = string.Empty;

    /// <summary>Maximum character length (null for non-string types).</summary>
    public int? MaxLength { get; set; }

    /// <summary>Whether the column allows NULL values.</summary>
    public bool IsNullable { get; set; }

    /// <summary>Whether this column is part of the primary key.</summary>
    public bool IsPrimaryKey { get; set; }

    /// <summary>Whether this column is a foreign key to another table.</summary>
    public bool IsForeignKey { get; set; }

    /// <summary>Default value expression (null if no default).</summary>
    public string? DefaultValue { get; set; }
}

/// <summary>
/// Represents a foreign key relationship between tables.
/// </summary>
public class ForeignKeyInfo
{
    /// <summary>The constraint name in the database.</summary>
    public string ConstraintName { get; set; } = string.Empty;

    /// <summary>The column in the source table that references another table.</summary>
    public string ColumnName { get; set; } = string.Empty;

    /// <summary>
    /// The fully qualified referenced table (e.g., "dbo.Orders").
    /// </summary>
    public string ReferencedTable { get; set; } = string.Empty;

    /// <summary>The column in the referenced table.</summary>
    public string ReferencedColumn { get; set; } = string.Empty;
}

/// <summary>
/// Represents the complete discovered database schema including all tables.
/// Provides a <see cref="ToSchemaPrompt"/> method to generate a text
/// representation for the LLM system prompt.
/// </summary>
public class DatabaseSchema
{
    /// <summary>The database name.</summary>
    public string DatabaseName { get; set; } = string.Empty;

    /// <summary>All discovered tables with their schemas.</summary>
    public List<TableSchema> Tables { get; set; } = new();

    /// <summary>When the schema was discovered (UTC).</summary>
    public DateTime DiscoveredAt { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Generates a concise schema summary for use in the LLM system prompt.
    /// Includes table names, column definitions with PK/FK/NOT NULL flags,
    /// foreign key relationships, and sample data rows.
    /// </summary>
    /// <returns>A multi-line text representation of the database schema.</returns>
    public string ToSchemaPrompt()
    {
        // Keep prompt rich for NL→SQL (includes sample data).
        return ToSchemaSnapshot(includeSampleData: true);
    }

    /// <summary>
    /// Generates a human-readable schema snapshot. By default this is schema-only (no sample data),
    /// suitable for displaying directly in Teams cards.
    /// </summary>
    public string ToSchemaSnapshot(bool includeSampleData)
    {
        var tables = Tables ?? new List<TableSchema>();
        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Database: " + DatabaseName);
        sb.AppendLine("DiscoveredAtUtc: " + DiscoveredAt.ToString("O"));
        sb.AppendLine("Tables: " + tables.Count);
        if (tables.Count > 0)
            sb.AppendLine("Table list: " + string.Join(", ", tables.Select(t => t.FullName)));
        sb.AppendLine();

        foreach (var table in tables)
        {
            sb.AppendLine("Table: " + table.FullName);
            sb.AppendLine("Columns:");

            // List each column with data type and constraint flags
            foreach (var col in table.Columns)
            {
                var flags = new List<string>();
                if (col.IsPrimaryKey) flags.Add("PK");
                if (col.IsForeignKey) flags.Add("FK");
                if (!col.IsNullable) flags.Add("NOT NULL");
                var flagStr = flags.Count > 0 ? " [" + string.Join(", ", flags) + "]" : "";
                sb.AppendLine("  - " + col.ColumnName + " (" + FormatType(col) + ")" + flagStr);
            }

            // List foreign key relationships
            if (table.ForeignKeys.Count > 0)
            {
                sb.AppendLine("Foreign Keys:");
                foreach (var fk in table.ForeignKeys)
                {
                    sb.AppendLine("  - " + fk.ColumnName + " -> " + fk.ReferencedTable + "." + fk.ReferencedColumn);
                }
            }

            // Optional: include sample data (used for LLM prompts — sanitized to prevent stored prompt injection)
            if (includeSampleData && table.SampleRows.Count > 0)
            {
                sb.AppendLine("Sample Data (first 3 rows):");
                foreach (var row in table.SampleRows)
                {
                    var values = row.Select(kvp =>
                        kvp.Key + "=" + InputSanitizer.SanitizeSampleValue(kvp.Value));
                    sb.AppendLine("  | " + string.Join(" | ", values) + " |");
                }
            }

            sb.AppendLine();
        }

        return sb.ToString();
    }

    private static string FormatType(ColumnSchema col)
    {
        var dt = (col.DataType ?? "").Trim();
        if (col.MaxLength is null) return dt;
        if (col.MaxLength <= 0) return dt;
        return dt + "(" + col.MaxLength + ")";
    }
}
