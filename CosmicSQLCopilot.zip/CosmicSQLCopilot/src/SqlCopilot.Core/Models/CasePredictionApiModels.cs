using System.Text.Json.Serialization;

namespace SqlCopilot.Core.Models;

/// <summary>
/// Request model exposed by SqlCopilot for invoking a case prediction.
/// The server fills storage/model configuration from appsettings.
/// </summary>
public sealed class CasePredictionInvokeRequest
{
    [JsonPropertyName("records")]
    public List<CasePredictionRecord> Records { get; set; } = new();

    [JsonPropertyName("uploadOutput")]
    public bool? UploadOutput { get; set; }

    [JsonPropertyName("maxReturnRows")]
    public int? MaxReturnRows { get; set; }
}

/// <summary>
/// One case record (feature row) used for prediction.
/// Property names match the upstream Azure Function's expected JSON keys.
/// </summary>
public sealed class CasePredictionRecord
{
    [JsonPropertyName("TicketNumber")]
    public string TicketNumber { get; set; } = string.Empty;

    [JsonPropertyName("createdon")]
    public string? CreatedOn { get; set; }

    [JsonPropertyName("msdyn_caserocname")]
    public string? MsdynCaseRocName { get; set; }

    [JsonPropertyName("msdyn_businessfunctionidname")]
    public string? MsdynBusinessFunctionIdName { get; set; }

    [JsonPropertyName("msdyn_lineofbusinessidname")]
    public string? MsdynLineOfBusinessIdName { get; set; }

    [JsonPropertyName("msdyn_programidname")]
    public string? MsdynProgramIdName { get; set; }

    [JsonPropertyName("msdyn_casetypeidname")]
    public string? MsdynCaseTypeIdName { get; set; }

    [JsonPropertyName("msdyn_casesubtypeidname")]
    public string? MsdynCaseSubTypeIdName { get; set; }

    [JsonPropertyName("msdyn_casereasonidname")]
    public string? MsdynCaseReasonIdName { get; set; }

    [JsonPropertyName("msdyn_casesubreasonidname")]
    public string? MsdynCaseSubReasonIdName { get; set; }

    [JsonPropertyName("prioritycodename")]
    public string? PriorityCodeName { get; set; }

    [JsonPropertyName("msdyn_complexityname")]
    public string? MsdynComplexityName { get; set; }

    [JsonPropertyName("msdyn_countrysubmitteridname")]
    public string? MsdynCountrySubmitterIdName { get; set; }

    [JsonPropertyName("msdyn_countryprocessedidname")]
    public string? MsdynCountryProcessedIdName { get; set; }

    [JsonPropertyName("statuscodename")]
    public string? StatusCodeName { get; set; }

    [JsonPropertyName("onholdtime")]
    public string? OnHoldTime { get; set; }

    // This is intentionally excluded from the upstream LightGBM API payload.
    // We use it only to short-circuit prediction when a case is already resolved.
    [JsonIgnore]
    public string? MsdynResolvedDate { get; set; }
}

/// <summary>
/// Response model returned by the upstream Azure Function.
/// </summary>
public sealed class CasePredictionApiResponse
{
    [JsonPropertyName("status")]
    public string? Status { get; set; }

    [JsonPropertyName("storageAccount")]
    public string? StorageAccount { get; set; }

    [JsonPropertyName("input")]
    public CasePredictionApiInput? Input { get; set; }

    [JsonPropertyName("artifacts")]
    public CasePredictionApiArtifacts? Artifacts { get; set; }

    [JsonPropertyName("output")]
    public CasePredictionApiOutput? Output { get; set; }

    [JsonPropertyName("preview")]
    public List<CasePredictionPreviewRow>? Preview { get; set; }
}

public sealed class CasePredictionApiInput
{
    [JsonPropertyName("container")]
    public string? Container { get; set; }

    [JsonPropertyName("blob")]
    public string? Blob { get; set; }

    [JsonPropertyName("inlineRecords")]
    public bool? InlineRecords { get; set; }
}

public sealed class CasePredictionApiArtifacts
{
    [JsonPropertyName("container")]
    public string? Container { get; set; }

    [JsonPropertyName("modelBlob")]
    public string? ModelBlob { get; set; }

    [JsonPropertyName("peaksBlob")]
    public string? PeaksBlob { get; set; }

    [JsonPropertyName("encodingsBlob")]
    public string? EncodingsBlob { get; set; }
}

public sealed class CasePredictionApiOutput
{
    [JsonPropertyName("container")]
    public string? Container { get; set; }

    [JsonPropertyName("blob")]
    public string? Blob { get; set; }

    [JsonPropertyName("rows")]
    public int? Rows { get; set; }
}

public sealed class CasePredictionPreviewRow
{
    [JsonPropertyName("case_id")]
    public string? CaseId { get; set; }

    [JsonPropertyName("predicted_resolution_dt")]
    public string? PredictedResolutionDt { get; set; }
}

