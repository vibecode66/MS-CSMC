namespace SqlCopilot.Core.Tracing;

/// <summary>
/// Per-turn mutable state for the trace sink (file path + step counter).
/// Stored in AsyncLocal so a singleton sink can safely serve concurrent turns.
/// </summary>
public sealed class TraceTurnState
{
    public TraceTurnState(string filePath, string dateSegment)
    {
        FilePath = filePath;
        DateSegment = dateSegment;
    }

    public string FilePath { get; }

    public string DateSegment { get; }

    public int StepIdx;
}

public static class TraceTurnStateAccessor
{
    private static readonly AsyncLocal<TraceTurnState?> CurrentValue = new();

    public static TraceTurnState? Current => CurrentValue.Value;

    public static void Set(TraceTurnState state) => CurrentValue.Value = state;

    public static void Clear() => CurrentValue.Value = null;
}

