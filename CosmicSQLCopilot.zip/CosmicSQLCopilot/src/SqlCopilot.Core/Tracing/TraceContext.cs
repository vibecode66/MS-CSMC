using System.Diagnostics;

namespace SqlCopilot.Core.Tracing;

/// <summary>
/// Per-turn trace context. Uses AsyncLocal so deep services can append trace steps
/// without plumbing IDs through every method.
/// </summary>
public sealed record TraceContext(
    string TraceId,
    string Channel,
    string ConversationId,
    string TurnId,
    DateTimeOffset ReceivedAtUtc,
    long StartTimestamp)
{
    public long ElapsedMs()
        => (long)(Stopwatch.GetElapsedTime(StartTimestamp).TotalMilliseconds);
}

public static class TraceContextAccessor
{
    private static readonly AsyncLocal<TraceContext?> CurrentValue = new();

    public static TraceContext? Current => CurrentValue.Value;

    public static void Set(TraceContext ctx) => CurrentValue.Value = ctx;

    public static void Clear() => CurrentValue.Value = null;
}

