using System.Text.Json;

namespace SqlCopilot.Core.Tracing;

public interface IConversationTraceSink
{
    bool IsEnabled { get; }

    void StartTurn(string channel, string? conversationId, string turnId, string userText);

    void Step(
        string stepKind,
        string toolOrStage,
        object? outgoing = null,
        object? incoming = null,
        bool success = true,
        string? error = null,
        string? sqlText = null,
        int? sqlAttempt = null,
        int? dbRows = null,
        int? dbCols = null,
        bool? dbTruncated = null);

    Task EndTurnAsync(
        string? finalAnswer,
        string? answeredRight = null,
        string? feedback = null,
        CancellationToken cancellationToken = default);
}

public sealed class NoopConversationTraceSink : IConversationTraceSink
{
    public bool IsEnabled => false;
    public void StartTurn(string channel, string? conversationId, string turnId, string userText) { }
    public void Step(string stepKind, string toolOrStage, object? outgoing = null, object? incoming = null, bool success = true, string? error = null, string? sqlText = null, int? sqlAttempt = null, int? dbRows = null, int? dbCols = null, bool? dbTruncated = null) { }
    public Task EndTurnAsync(string? finalAnswer, string? answeredRight = null, string? feedback = null, CancellationToken cancellationToken = default) => Task.CompletedTask;
}

