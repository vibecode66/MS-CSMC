using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace SqlCopilot.Core.Tracing;

public sealed class LocalNdjsonConversationTraceSink : IConversationTraceSink
{
    private readonly ConversationTraceOptions _options;
    private readonly ILogger<LocalNdjsonConversationTraceSink> _logger;

    public bool IsEnabled => _options.Enabled;

    public LocalNdjsonConversationTraceSink(
        IOptions<ConversationTraceOptions> options,
        ILogger<LocalNdjsonConversationTraceSink> logger)
    {
        _options = (options ?? throw new ArgumentNullException(nameof(options))).Value;
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public void StartTurn(string channel, string? conversationId, string turnId, string userText)
    {
        if (!IsEnabled) return;

        try
        {
            var traceId = Guid.NewGuid().ToString("N");
            var receivedAt = DateTimeOffset.UtcNow;
            var convId = (conversationId ?? "").Trim();
            if (convId.Length == 0) convId = "<none>";

            var ctx = new TraceContext(
                TraceId: traceId,
                Channel: (channel ?? "").Trim().Length == 0 ? "unknown" : channel.Trim(),
                ConversationId: convId,
                TurnId: (turnId ?? "").Trim().Length == 0 ? Guid.NewGuid().ToString("N")[..8] : turnId.Trim(),
                ReceivedAtUtc: receivedAt,
                StartTimestamp: Stopwatch.GetTimestamp());

            TraceContextAccessor.Set(ctx);

            var dir = ResolveLocalDir(_options.LocalDirectory);
            var dateSegment = receivedAt.UtcDateTime.ToString("yyyy-MM-dd");
            var datedDir = Path.Combine(dir, dateSegment);
            Directory.CreateDirectory(datedDir);

            var safeTurn = SanitizeForFilename(ctx.TurnId);
            var fileName = $"trace_{receivedAt:yyyyMMdd_HHmmss_fff}_{safeTurn}_{traceId[..8]}.ndjson";
            var path = Path.Combine(datedDir, fileName);
            TraceTurnStateAccessor.Set(new TraceTurnState(path, dateSegment));

            // First event: RECEIVE
            Step(
                stepKind: "RECEIVE",
                toolOrStage: "user",
                outgoing: new { userText },
                incoming: new { });

            PruneOldFiles(dir, _options.KeepLastFiles);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Trace StartTurn failed: {Error}", ex.Message);
        }
    }

    public void Step(
        string stepKind,
        string toolOrStage,
        object? outgoing = null,
        object? incoming = null,
        bool success = true,
        string? error = null,
        string? sqlText = null,
        int? sqlAttempt = null,
        int? dbRows = null,
        int? dbCols = null,
        bool? dbTruncated = null)
    {
        if (!IsEnabled) return;
        var ctx = TraceContextAccessor.Current;
        if (ctx is null) return;
        var state = TraceTurnStateAccessor.Current;
        if (state is null) return;

        try
        {
            var ev = new TraceEvent(
                TraceId: ctx.TraceId,
                Channel: ctx.Channel,
                ConversationId: ctx.ConversationId,
                TurnId: ctx.TurnId,
                ReceivedAtUtc: ctx.ReceivedAtUtc,
                StepIdx: Interlocked.Increment(ref state.StepIdx),
                StepKind: (stepKind ?? "").Trim(),
                ToolOrStage: (toolOrStage ?? "").Trim(),
                LatencyMs: ctx.ElapsedMs(),
                Success: success,
                Error: string.IsNullOrWhiteSpace(error) ? null : error.Trim(),
                Outgoing: outgoing is null ? TraceJson.EmptyObject() : TraceJson.Obj(outgoing),
                Incoming: incoming is null ? TraceJson.EmptyObject() : TraceJson.Obj(incoming),
                SqlText: string.IsNullOrWhiteSpace(sqlText) ? null : sqlText,
                SqlAttempt: sqlAttempt,
                DbRows: dbRows,
                DbCols: dbCols,
                DbTruncated: dbTruncated,
                FinalAnswer: null,
                AnsweredRight: null,
                Feedback: null);

            AppendLine(state.FilePath, JsonSerializer.Serialize(ev, TraceJson.Options));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Trace Step failed: {Error}", ex.Message);
        }
    }

    public async Task EndTurnAsync(
        string? finalAnswer,
        string? answeredRight = null,
        string? feedback = null,
        CancellationToken cancellationToken = default)
    {
        if (!IsEnabled) return;
        var ctx = TraceContextAccessor.Current;
        if (ctx is null) return;
        var state = TraceTurnStateAccessor.Current;
        if (state is null) return;

        try
        {
            var ev = new TraceEvent(
                TraceId: ctx.TraceId,
                Channel: ctx.Channel,
                ConversationId: ctx.ConversationId,
                TurnId: ctx.TurnId,
                ReceivedAtUtc: ctx.ReceivedAtUtc,
                StepIdx: Interlocked.Increment(ref state.StepIdx),
                StepKind: "FINAL_RESPONSE",
                ToolOrStage: "render",
                LatencyMs: ctx.ElapsedMs(),
                Success: true,
                Error: null,
                Outgoing: TraceJson.EmptyObject(),
                Incoming: TraceJson.EmptyObject(),
                SqlText: null,
                SqlAttempt: null,
                DbRows: null,
                DbCols: null,
                DbTruncated: null,
                FinalAnswer: (finalAnswer ?? "").Trim().Length == 0 ? null : finalAnswer.Trim(),
                AnsweredRight: (answeredRight ?? "").Trim().Length == 0 ? null : answeredRight.Trim(),
                Feedback: (feedback ?? "").Trim().Length == 0 ? null : feedback.Trim());

            AppendLine(state.FilePath, JsonSerializer.Serialize(ev, TraceJson.Options));

            // Optional blob upload is implemented in a separate wrapper sink to keep this sink simple.
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Trace EndTurn failed: {Error}", ex.Message);
        }
        finally
        {
            TraceContextAccessor.Clear();
            TraceTurnStateAccessor.Clear();
        }

        await Task.CompletedTask;
    }

    private static string ResolveLocalDir(string configured)
    {
        configured = (configured ?? "").Trim();
        if (configured.Length == 0) configured = "sqlcopilot-traces";
        if (Path.IsPathRooted(configured)) return configured;
        var home = (Environment.GetEnvironmentVariable("HOME") ?? "").Trim();
        if (home.Length > 0)
            return Path.Combine(home, "data", "sqlcopilot", configured);
        return Path.Combine(Directory.GetCurrentDirectory(), configured);
    }

    private static void AppendLine(string path, string line)
    {
        // Single-line append; keep it simple and resilient.
        File.AppendAllText(path, line + Environment.NewLine, Encoding.UTF8);
    }

    private static void PruneOldFiles(string rootDir, int keepLast)
    {
        try
        {
            keepLast = Math.Clamp(keepLast, 0, 50);
            if (keepLast == 0) return;

            if (!Directory.Exists(rootDir)) return;

            // Keep last N trace files across all date folders.
            var files = Directory.EnumerateFiles(rootDir, "trace_*.ndjson", SearchOption.AllDirectories)
                .Select(p => new FileInfo(p))
                .OrderByDescending(f => f.LastWriteTimeUtc)
                .ToList();

            foreach (var f in files.Skip(keepLast))
            {
                try { f.Delete(); } catch { /* best-effort */ }
            }

            // Best-effort cleanup: remove empty date directories.
            foreach (var d in Directory.EnumerateDirectories(rootDir))
            {
                try
                {
                    if (!Directory.EnumerateFileSystemEntries(d).Any())
                        Directory.Delete(d);
                }
                catch { /* best-effort */ }
            }
        }
        catch
        {
            // best-effort
        }
    }

    private static string SanitizeForFilename(string s)
    {
        s ??= "";
        var invalid = Path.GetInvalidFileNameChars();
        var cleaned = new string(s.Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray());
        cleaned = cleaned.Trim();
        return cleaned.Length == 0 ? "turn" : cleaned.Length > 80 ? cleaned[..80] : cleaned;
    }
}

