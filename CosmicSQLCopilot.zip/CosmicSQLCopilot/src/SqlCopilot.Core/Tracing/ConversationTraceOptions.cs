namespace SqlCopilot.Core.Tracing;

public sealed class ConversationTraceOptions
{
    public const string SectionName = "ConversationTrace";

    /// <summary>
    /// Master switch. When false, all tracing becomes a no-op.
    /// </summary>
    public bool Enabled { get; set; } = false;

    /// <summary>
    /// Where to write per-turn trace files (NDJSON). If relative, it's resolved under the current working directory.
    /// </summary>
    public string LocalDirectory { get; set; } = "sqlcopilot-traces";

    /// <summary>
    /// Keep only the most recent N per-turn files locally.
    /// </summary>
    public int KeepLastFiles { get; set; } = 5;

    /// <summary>
    /// If true, includes a small preview of result data (first row, capped) in DB execution events.
    /// </summary>
    public bool IncludeDbPreview { get; set; } = true;

    public ConversationTraceBlobOptions Blob { get; set; } = new();
}

public sealed class ConversationTraceBlobOptions
{
    /// <summary>
    /// When true, uploads the per-turn NDJSON file to Azure Blob Storage on EndTurn.
    /// </summary>
    public bool Enabled { get; set; } = false;

    /// <summary>
    /// Optional. If blank, the uploader will fall back to the CasePrediction storage account (if available).
    /// </summary>
    public string StorageAccount { get; set; } = "";

    /// <summary>
    /// Optional. If blank, the uploader will fall back to the CasePrediction container (if available).
    /// </summary>
    public string Container { get; set; } = "";

    /// <summary>
    /// Prefix inside the container, e.g. "sqlcopilot-traces/".
    /// </summary>
    public string Prefix { get; set; } = "sqlcopilot-traces/";

    /// <summary>
    /// If set, uploads using a connection string (local/dev convenience). Otherwise uses Managed Identity.
    /// </summary>
    public string ConnectionString { get; set; } = "";

    /// <summary>
    /// Optional user-assigned managed identity client id (when using MI auth).
    /// </summary>
    public string ManagedIdentityClientId { get; set; } = "";
}

