using System.Text.Json;

namespace SqlCopilot.Core.Tracing;

public sealed record TraceEvent(
    string TraceId,
    string Channel,
    string ConversationId,
    string TurnId,
    DateTimeOffset ReceivedAtUtc,
    int StepIdx,
    string StepKind,
    string ToolOrStage,
    long LatencyMs,
    bool Success,
    string? Error,
    JsonElement Outgoing,
    JsonElement Incoming,
    string? SqlText,
    int? SqlAttempt,
    int? DbRows,
    int? DbCols,
    bool? DbTruncated,
    string? FinalAnswer,
    string? AnsweredRight,
    string? Feedback);

public static class TraceJson
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = null,
        WriteIndented = false
    };

    public static JsonElement Obj(object value)
    {
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value, Options);
        using var doc = JsonDocument.Parse(bytes);
        return doc.RootElement.Clone();
    }

    public static JsonElement EmptyObject()
    {
        using var doc = JsonDocument.Parse("{}");
        return doc.RootElement.Clone();
    }
}

