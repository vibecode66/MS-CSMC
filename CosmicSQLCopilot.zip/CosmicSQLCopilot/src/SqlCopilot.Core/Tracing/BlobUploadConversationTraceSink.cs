using Azure.Core;
using Azure.Identity;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Tracing;

/// <summary>
/// Wraps a local trace sink and, on EndTurn, uploads the produced file to Azure Blob Storage.
/// </summary>
public sealed class BlobUploadConversationTraceSink : IConversationTraceSink
{
    private readonly ConversationTraceOptions _options;
    private readonly CasePredictionOptions _casePredictionOptions;
    private readonly LocalNdjsonConversationTraceSink _local;
    private readonly ILogger<BlobUploadConversationTraceSink> _logger;

    public bool IsEnabled => _options.Enabled;

    public BlobUploadConversationTraceSink(
        IOptions<ConversationTraceOptions> options,
        IOptions<CasePredictionOptions> casePredictionOptions,
        LocalNdjsonConversationTraceSink local,
        ILogger<BlobUploadConversationTraceSink> logger)
    {
        _options = (options ?? throw new ArgumentNullException(nameof(options))).Value;
        _casePredictionOptions = (casePredictionOptions ?? throw new ArgumentNullException(nameof(casePredictionOptions))).Value;
        _local = local ?? throw new ArgumentNullException(nameof(local));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public void StartTurn(string channel, string? conversationId, string turnId, string userText)
    {
        _local.StartTurn(channel, conversationId, turnId, userText);
    }

    public void Step(string stepKind, string toolOrStage, object? outgoing = null, object? incoming = null, bool success = true, string? error = null, string? sqlText = null, int? sqlAttempt = null, int? dbRows = null, int? dbCols = null, bool? dbTruncated = null)
        => _local.Step(stepKind, toolOrStage, outgoing, incoming, success, error, sqlText, sqlAttempt, dbRows, dbCols, dbTruncated);

    public async Task EndTurnAsync(string? finalAnswer, string? answeredRight = null, string? feedback = null, CancellationToken cancellationToken = default)
    {
        // Capture turn-scoped info before the local sink clears AsyncLocal context.
        var dateSegment = TraceTurnStateAccessor.Current?.DateSegment;
        var localPath = TraceTurnStateAccessor.Current?.FilePath;

        await _local.EndTurnAsync(finalAnswer, answeredRight, feedback, cancellationToken);

        if (!_options.Enabled) return;
        if (!_options.Blob.Enabled) return;
        if (string.IsNullOrWhiteSpace(localPath) || !File.Exists(localPath)) return;

        try
        {
            var (account, container, prefix) = ResolveBlobTarget();
            if (string.IsNullOrWhiteSpace(account) || string.IsNullOrWhiteSpace(container))
            {
                _logger.LogWarning("Trace blob upload skipped: StorageAccount/Container not configured.");
                return;
            }

            var blobName = BuildBlobName(prefix, dateSegment, Path.GetFileName(localPath));

            var client = CreateContainerClient(account, container);
            await client.CreateIfNotExistsAsync(cancellationToken: cancellationToken);

            var blob = client.GetBlobClient(blobName);
            await using var stream = File.OpenRead(localPath);
            await blob.UploadAsync(stream, overwrite: true, cancellationToken);

            _logger.LogInformation(
                "Trace uploaded to blob. account={Account} container={Container} blob={Blob}",
                account, container, blobName);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Trace blob upload failed: {Error}", ex.Message);
        }
    }

    private (string Account, string Container, string Prefix) ResolveBlobTarget()
    {
        var b = _options.Blob;
        var account = (b.StorageAccount ?? "").Trim();
        var container = (b.Container ?? "").Trim();
        var prefix = (b.Prefix ?? "").Trim();

        if (account.Length == 0) account = (_casePredictionOptions.StorageAccount ?? "").Trim();
        if (container.Length == 0) container = (_casePredictionOptions.Container ?? "").Trim();
        if (prefix.Length == 0) prefix = "sqlcopilot-traces/";

        return (account, container, prefix);
    }

    private BlobContainerClient CreateContainerClient(string account, string container)
    {
        var conn = (_options.Blob.ConnectionString ?? "").Trim();
        if (conn.Length > 0)
            return new BlobContainerClient(conn, container);

        var uri = new Uri($"https://{account}.blob.core.windows.net/{container}");
        TokenCredential cred;
        var miClientId = (_options.Blob.ManagedIdentityClientId ?? "").Trim();
        if (miClientId.Length > 0)
            cred = new DefaultAzureCredential(new DefaultAzureCredentialOptions
            {
                ExcludeInteractiveBrowserCredential = true,
                ManagedIdentityClientId = miClientId
            });
        else
            cred = new DefaultAzureCredential(new DefaultAzureCredentialOptions
            {
                ExcludeInteractiveBrowserCredential = true
            });

        return new BlobContainerClient(uri, cred);
    }

    private static string BuildBlobName(string prefix, string? dateSegment, string fileName)
    {
        prefix = (prefix ?? "").Trim();
        if (prefix.Length > 0 && !prefix.EndsWith("/")) prefix += "/";
        dateSegment = (dateSegment ?? "").Trim();
        if (dateSegment.Length > 0 && !dateSegment.EndsWith("/")) dateSegment += "/";
        fileName = (fileName ?? "").Trim();
        return prefix + dateSegment + fileName;
    }

    private static string ResolveLocalDir(string configured)
    {
        configured = (configured ?? "").Trim();
        if (configured.Length == 0) configured = "sqlcopilot-traces";
        if (Path.IsPathRooted(configured)) return configured;
        return Path.Combine(Directory.GetCurrentDirectory(), configured);
    }
}

