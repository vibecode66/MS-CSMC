// ============================================================================
// SqlGuard.cs — Lightweight read-only SQL guardrail (best-effort)
//
// This helper enforces that a SQL string appears to be read-only.
//
// Important limitations (intent + trade-off):
// - This is a heuristic string/regex gate, not a full SQL parser.
// - It is designed to catch obvious unsafe statements early and cheaply.
// - The system also relies on LLM prompting + code-level constraints (e.g., only executing
//   SELECT/WITH in `QueryExecutionService`) for defense in depth.
//
// See also:
// - Execution gate: `Services/QueryExecutionService.cs` (rejects non-SELECT/WITH)
// - NL→SQL prompt rules: `Services/SqlGeneratorService.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Text.RegularExpressions;

namespace SqlCopilot.Core.AgentPort.Sql;

/// <summary>
/// Best-effort SQL safety check to ensure the query is read-only.
/// </summary>
public static class SqlGuard
{
    private static readonly Regex ReadonlyPrefix =
        new(@"^\s*(select|with|explain)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static readonly Regex Forbidden =
        new(@"\b(insert|update|delete|drop|alter|create|attach|detach|replace|truncate|merge|grant|revoke)\b",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    /// <summary>
    /// Throws if <paramref name="sql"/> does not look like read-only SQL.
    /// </summary>
    public static void EnsureReadOnly(string sql)
    {
        if (string.IsNullOrWhiteSpace(sql))
            throw new ArgumentException("SQL is empty.");
        if (!ReadonlyPrefix.IsMatch(sql) || Forbidden.IsMatch(sql))
            throw new ArgumentException("Only read-only SQL is allowed (SELECT/WITH/EXPLAIN).");
    }
}

