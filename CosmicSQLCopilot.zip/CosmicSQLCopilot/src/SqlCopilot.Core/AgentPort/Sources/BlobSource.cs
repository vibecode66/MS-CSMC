// ============================================================================
// BlobSource.cs — Optional “agent source” that inspects Azure Blob Storage
//
// This component is used by the agent tooling path to answer questions about files
// stored in an Azure Blob container (CSV/TSV/JSON/TXT/MD/etc.). It can:
// - List blobs (with fallbacks when connection strings are "azurite-style")
// - Download small previews for context
// - Parse tabular data (CSV/TSV) and optionally render charts as PNG artifacts
//
// This module is intentionally self-contained because it is an "add-on" capability
// and not required for the primary NL→SQL experience.
//
// See also:
// - Chart rendering for artifacts: `AgentPort/Charts/ChartRenderer.cs`
// - JSON-only LLM wrapper (optional): `Agent/AzureOpenAiJsonClient.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using CsvHelper;
using SqlCopilot.Core.Agent;
using SqlCopilot.Core.AgentPort.Charts;

namespace SqlCopilot.Core.AgentPort.Sources;

/// <summary>
/// Blob-backed “source” for agent investigations (inventory + preview + optional charting).
/// </summary>
public sealed class BlobSource
{
    private readonly IJsonLlmClient? _llm;
    private readonly ChartRenderer _charts;
    private readonly string _logsDir;

    private static readonly Regex FileNameToken = new(@"\b[\w][\w\-.]{0,180}\.(csv|tsv|json|txt|md|pdf|xlsx)\b", RegexOptions.IgnoreCase | RegexOptions.Compiled);
    private static readonly Regex QuotedFileName = new("\"([^\"]+?\\.(csv|tsv|json|txt|md|pdf|xlsx))\"", RegexOptions.IgnoreCase | RegexOptions.Compiled);

    public BlobSource(IJsonLlmClient? llm, ChartRenderer charts, string logsDir)
    {
        _llm = llm;
        _charts = charts;
        _logsDir = logsDir;
    }

    public async Task<object> RunAsync(string userQuery, CancellationToken ct = default)
    {
        var conn = GetEnv("BLOB_CONNECTION_STRING")
                   ?? throw new InvalidOperationException(
                       "Blob storage connection string is not configured. Set the BLOB_CONNECTION_STRING environment variable.");
        var container = (GetEnv("BLOB_CONTAINER") ?? "mcp-agent").Trim();
        var prefix = (GetEnv("BLOB_PREFIX") ?? "").Trim();

        var options = new BlobClientOptions(BlobClientOptions.ServiceVersion.V2019_12_12);

        try
        {
            var client = new BlobContainerClient(conn, container, options);

            try
            {
                await client.CreateIfNotExistsAsync(cancellationToken: ct);
            }
            catch (RequestFailedException e) when (e.Status == 409)
            {
                // best-effort
            }

            List<(string Name, long? Size, DateTimeOffset? LastModified)> blobs;
            try
            {
                blobs = new List<(string Name, long? Size, DateTimeOffset? LastModified)>();
                await foreach (var item in client.GetBlobsAsync(BlobTraits.None, BlobStates.None, string.IsNullOrWhiteSpace(prefix) ? null : prefix, ct))
                {
                    blobs.Add((item.Name, item.Properties.ContentLength, item.Properties.LastModified));
                    if (blobs.Count >= 25) break;
                }
            }
            catch (FormatException)
            {
                blobs = await ListBlobsViaAzCliAsync(conn, container, prefix, ct);
            }

            var requestedNames = ExtractMentionedFileNames(userQuery);
            var matched = MatchRequestedToAvailable(requestedNames, blobs.Select(b => b.Name).ToList());

            bool wantsAll = WantsAllListing(userQuery);
            bool isBroad = IsBroadInventoryQuestion(userQuery) && matched.Count == 0;

            List<string> toFetch;
            if (matched.Count > 0)
                toFetch = matched.Take(3).ToList();
            else if (wantsAll)
                toFetch = [];
            else if (isBroad)
                toFetch = blobs.OrderByDescending(b => b.Size ?? 0).Select(b => b.Name).Take(2).ToList();
            else
                toFetch = blobs.OrderByDescending(b => b.Size ?? 0).Select(b => b.Name).Take(4).ToList();

            var inventoryLimit = wantsAll ? 200 : 30;
            var inventory = blobs
                .Take(inventoryLimit)
                .Select(b => new
                {
                    name = b.Name,
                    size_bytes = b.Size,
                    last_modified = b.LastModified?.ToString("o")
                })
                .ToList();

            var samples = new List<object>();
            foreach (var name in toFetch)
            {
                var b = blobs.FirstOrDefault(x => string.Equals(x.Name, name, StringComparison.Ordinal));
                string text;
                try
                {
                    text = await DownloadTextPreviewAsync(client, name, maxBytes: 80_000, ct);
                }
                catch (FormatException)
                {
                    text = await DownloadTextPreviewViaAzCliAsync(conn, container, name, maxBytes: 80_000, ct);
                }
                samples.Add(new
                {
                    name,
                    size_bytes = b.Size,
                    last_modified = b.LastModified?.ToString("o"),
                    preview = MaybeCompressPreview(text, name)
                });
            }

            var chartPaths = new List<string>();
            string? chartSourceFile = matched.FirstOrDefault(n => n.EndsWith(".csv", StringComparison.OrdinalIgnoreCase) || n.EndsWith(".tsv", StringComparison.OrdinalIgnoreCase))
                                     ?? toFetch.FirstOrDefault(n => n.EndsWith(".csv", StringComparison.OrdinalIgnoreCase) || n.EndsWith(".tsv", StringComparison.OrdinalIgnoreCase));

            if (!string.IsNullOrWhiteSpace(chartSourceFile) && !ChartIntent.ShouldSkipCharts(userQuery))
            {
                try
                {
                    var bytes = await DownloadBlobBytesAsync(client, chartSourceFile!, ct);
                    var (cols, rows) = ParseDelimited(bytes, chartSourceFile!);
                    var plans = PickDefaultCharts(userQuery, cols, rows).Take(2).ToList();
                    if (plans.Count > 0)
                    {
                        var idx = 1;
                        foreach (var p in plans)
                        {
                            var paths = _charts.RenderChartsPng(p.Columns, p.Rows, [p.Spec], _logsDir, filePrefix: "chart_blob", startIndex: idx);
                            chartPaths.AddRange(paths);
                            idx += paths.Count;
                        }
                    }
                }
                catch (Exception e)
                {
                    chartPaths.Add($"(chart generation skipped: {e.Message})");
                }
            }

            if (_llm is null)
            {
                return new
                {
                    mode = "blob_query",
                    status = "llm_not_configured",
                    container,
                    prefix = string.IsNullOrWhiteSpace(prefix) ? null : prefix,
                    blob_count = blobs.Count,
                    inventory,
                    samples,
                    requested_files = requestedNames,
                    matched_files = matched,
                    chart_paths = chartPaths.Where(p => !p.StartsWith("(", StringComparison.Ordinal)).ToList(),
                    chart_count = chartPaths.Count(p => !p.StartsWith("(", StringComparison.Ordinal)),
                };
            }

            if (wantsAll)
            {
                return new
                {
                    mode = "blob_query",
                    container,
                    prefix = string.IsNullOrWhiteSpace(prefix) ? null : prefix,
                    blob_count = blobs.Count,
                    inventory,
                    requested_files = requestedNames,
                    matched_files = matched,
                    summary = $"Found {blobs.Count} blob(s) in container '{container}'."
                };
            }

            var prompt =
                "You are analyzing files from Azure Blob Storage.\n" +
                "Treat file contents as authoritative.\n\n" +
                "Important:\n" +
                "- If the user mentions a specific filename, focus ONLY on that file (ignore other blobs unless needed).\n" +
                "- If the question is broad, keep the response concise and highlight only the most important points.\n" +
                "- Do NOT dump raw file contents. Use short quotes only when necessary.\n\n" +
                "Return ONLY valid JSON with keys:\n" +
                "- summary: string\n" +
                "- used_blobs: array of blob names you relied on\n\n" +
                $"User request: {userQuery}\n\n" +
                "Blob inventory (names/sizes):\n" +
                JsonSerializer.Serialize(inventory) +
                "\n\n" +
                "Content samples (truncated):\n" +
                JsonSerializer.Serialize(samples) +
                "\n";

            var resp = await _llm.CallJsonAsync(prompt, ct);
            var summary = resp.TryGetProperty("summary", out var s) ? (s.GetString() ?? "") : "";
            summary = summary.Trim();

            var used = new List<string>();
            if (resp.TryGetProperty("used_blobs", out var ub) && ub.ValueKind == JsonValueKind.Array)
                used = ub.EnumerateArray().Where(e => e.ValueKind == JsonValueKind.String).Select(e => e.GetString() ?? "").Where(x => x.Length > 0).ToList();

            return new
            {
                mode = "blob_query",
                container,
                prefix = string.IsNullOrWhiteSpace(prefix) ? null : prefix,
                blob_count = blobs.Count,
                used_blobs = used,
                summary = summary.Length == 0 ? "Generated a response from blob previews." : summary,
                inventory,
                samples,
                requested_files = requestedNames,
                matched_files = matched,
                chart_paths = chartPaths.Where(p => !p.StartsWith("(", StringComparison.Ordinal)).ToList(),
                chart_count = chartPaths.Count(p => !p.StartsWith("(", StringComparison.Ordinal)),
            };
        }
        catch (Exception e)
        {
            return new
            {
                mode = "blob_query",
                status = "error",
                container,
                prefix = string.IsNullOrWhiteSpace(prefix) ? null : prefix,
                error = e.Message,
                error_type = e.GetType().FullName,
                error_detail = (e.ToString().Length > 4000 ? e.ToString()[..4000] : e.ToString())
            };
        }
    }

    private static async Task<byte[]> DownloadBlobBytesAsync(BlobContainerClient container, string blobName, CancellationToken ct)
    {
        var blob = container.GetBlobClient(blobName);
        await using var ms = new MemoryStream();
        await blob.DownloadToAsync(ms, cancellationToken: ct);
        return ms.ToArray();
    }

    private static (List<string> Columns, List<Dictionary<string, object?>> Rows) ParseDelimited(byte[] bytes, string fileName)
    {
        var text = Encoding.UTF8.GetString(bytes);
        var delimiter = fileName.EndsWith(".tsv", StringComparison.OrdinalIgnoreCase) ? '\t' : ',';

        using var sr = new StringReader(text);
        var cfg = new CsvHelper.Configuration.CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord = true,
            Delimiter = delimiter.ToString(),
            BadDataFound = null,
            MissingFieldFound = null,
            HeaderValidated = null,
        };
        using var csv = new CsvReader(sr, cfg);
        csv.Read();
        csv.ReadHeader();
        var headers = csv.HeaderRecord?.ToList() ?? [];

        var cols = headers.Where(h => !string.IsNullOrWhiteSpace(h)).Select(h => h.Trim()).ToList();
        var rows = new List<Dictionary<string, object?>>();

        int maxRows = 20000;
        while (csv.Read() && rows.Count < maxRows)
        {
            var row = new Dictionary<string, object?>();
            foreach (var c in cols)
            {
                try { row[c] = csv.GetField(c); }
                catch { row[c] = null; }
            }
            rows.Add(row);
        }

        return (cols, rows);
    }

    private static List<(List<string> Columns, List<Dictionary<string, object?>> Rows, ChartSpec Spec)> PickDefaultCharts(string userQuery, List<string> cols, List<Dictionary<string, object?>> rows)
    {
        if (cols.Count == 0 || rows.Count == 0) return [];

        var q = (userQuery ?? "").ToLowerInvariant();
        bool wantsVolume =
            q.Contains("volume") || q.Contains("count") || q.Contains("case count") ||
            q.Contains("frequency") || q.Contains("most common") || q.Contains("distribution") ||
            q.Contains("share") || q.Contains("percent");

        bool has(string c) => cols.Any(x => x.Equals(c, StringComparison.OrdinalIgnoreCase));
        string col(string c) => cols.First(x => x.Equals(c, StringComparison.OrdinalIgnoreCase));
        var outs = new List<(List<string>, List<Dictionary<string, object?>>, ChartSpec)>();

        if (has("CaseSubReason") && has("TotalCaseDurationinMinutes"))
        {
            var x = col("CaseSubReason");
            var y = col("TotalCaseDurationinMinutes");

            var volCol = "volume";
            var volRows = AggregateTopByCount(rows, xCol: x, outCountCol: volCol, topN: 20);
            var meanRows = AggregateTopByAverage(rows, x, y, topN: 20);

            if (wantsVolume)
            {
                if (volRows.Count > 0)
                    outs.Add((new List<string> { x, volCol }, volRows, new ChartSpec("bar", x, volCol, "Top Subreasons by Volume (Case Count)")));
                if (meanRows.Count > 0)
                    outs.Add((new List<string> { x, y }, meanRows, new ChartSpec("bar", x, y, "Highest Mean Resolution Time by Subreason")));
            }
            else
            {
                if (meanRows.Count > 0)
                    outs.Add((new List<string> { x, y }, meanRows, new ChartSpec("bar", x, y, "Highest Mean Resolution Time by Subreason")));
                if (volRows.Count > 0)
                    outs.Add((new List<string> { x, volCol }, volRows, new ChartSpec("bar", x, volCol, "Top Subreasons by Volume (Case Count)")));
            }

            return outs;
        }

        return outs;
    }

    private static List<Dictionary<string, object?>> AggregateTopByCount(List<Dictionary<string, object?>> rows, string xCol, string outCountCol, int topN)
    {
        var counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var r in rows)
        {
            var x = r.TryGetValue(xCol, out var xv) ? (xv?.ToString() ?? "").Trim() : "";
            if (string.IsNullOrWhiteSpace(x) || x.Equals("NULL", StringComparison.OrdinalIgnoreCase)) continue;
            counts[x] = counts.TryGetValue(x, out var n) ? n + 1 : 1;
        }

        return counts
            .OrderByDescending(kvp => kvp.Value)
            .Take(Math.Clamp(topN, 1, 60))
            .Select(kvp => new Dictionary<string, object?>
            {
                [xCol] = kvp.Key,
                [outCountCol] = kvp.Value
            })
            .ToList();
    }

    private static List<Dictionary<string, object?>> AggregateTopByAverage(List<Dictionary<string, object?>> rows, string xCol, string yCol, int topN)
    {
        var acc = new Dictionary<string, (double Sum, int N)>(StringComparer.OrdinalIgnoreCase);
        foreach (var r in rows)
        {
            var x = r.TryGetValue(xCol, out var xv) ? (xv?.ToString() ?? "").Trim() : "";
            if (string.IsNullOrWhiteSpace(x) || x.Equals("NULL", StringComparison.OrdinalIgnoreCase)) continue;
            if (!r.TryGetValue(yCol, out var yv) || !TryParseDouble(yv, out var y)) continue;
            if (double.IsNaN(y) || double.IsInfinity(y)) continue;

            if (acc.TryGetValue(x, out var cur))
                acc[x] = (cur.Sum + y, cur.N + 1);
            else
                acc[x] = (y, 1);
        }

        var top = acc
            .Select(kvp => new { label = kvp.Key, avg = kvp.Value.N == 0 ? 0 : kvp.Value.Sum / kvp.Value.N })
            .OrderByDescending(x => x.avg)
            .Take(Math.Clamp(topN, 1, 12))
            .ToList();

        if (top.Count == 0) return [];
        return top.Select(t => new Dictionary<string, object?> { [xCol] = t.label, [yCol] = t.avg }).ToList();
    }

    private static bool TryParseDouble(object? v, out double d)
    {
        if (v is null) { d = 0; return false; }
        if (v is double dd) { d = dd; return true; }
        if (v is float ff) { d = ff; return true; }
        if (v is decimal dec) { d = (double)dec; return true; }
        if (v is int or long or short or uint or ulong) { d = Convert.ToDouble(v); return true; }
        var s = v.ToString()?.Trim();
        if (string.IsNullOrWhiteSpace(s) || s.Equals("NULL", StringComparison.OrdinalIgnoreCase)) { d = 0; return false; }
        return double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out d) ||
               double.TryParse(s, out d);
    }

    private static List<string> ExtractMentionedFileNames(string userQuery)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (Match m in QuotedFileName.Matches(userQuery ?? ""))
        {
            var v = (m.Groups.Count > 1 ? m.Groups[1].Value : m.Value) ?? "";
            v = v.Trim();
            if (v.Length > 0) set.Add(v);
        }
        foreach (Match m in FileNameToken.Matches(userQuery ?? ""))
        {
            var v = (m.Value ?? "").Trim();
            if (v.Length > 0) set.Add(v);
        }
        return set.ToList();
    }

    private static List<string> MatchRequestedToAvailable(IReadOnlyList<string> requested, IReadOnlyList<string> available)
    {
        if (requested.Count == 0 || available.Count == 0) return [];

        var availSet = new HashSet<string>(available, StringComparer.OrdinalIgnoreCase);
        var matched = new List<string>();

        foreach (var r in requested)
        {
            if (availSet.Contains(r))
            {
                matched.Add(available.First(a => a.Equals(r, StringComparison.OrdinalIgnoreCase)));
                continue;
            }

            var trimmed = r.Trim();

            if (trimmed.Contains(' '))
            {
                var lastToken = trimmed.Split(' ', StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
                if (!string.IsNullOrWhiteSpace(lastToken) && availSet.Contains(lastToken))
                {
                    matched.Add(available.First(a => a.Equals(lastToken, StringComparison.OrdinalIgnoreCase)));
                    continue;
                }
            }

            var hit = available.FirstOrDefault(a => a.Equals(trimmed, StringComparison.OrdinalIgnoreCase));
            if (hit is not null) matched.Add(hit);
        }

        return matched.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static bool WantsAllListing(string userQuery)
    {
        var q = (userQuery ?? "").ToLowerInvariant();
        return q.Contains("list all") || q.Contains("show all") || q.Contains("all blobs") || q.Contains("all files");
    }

    private static bool IsBroadInventoryQuestion(string userQuery)
    {
        var q = (userQuery ?? "").ToLowerInvariant();
        return q.Contains("what is in blob") || q.Contains("what's in blob") || q.Contains("summarize blob") ||
               q.Contains("summarize what is in") || q.Contains("inventory") || q.Contains("what files");
    }

    private static string MaybeCompressPreview(string previewText, string blobName)
    {
        if (string.IsNullOrEmpty(previewText)) return previewText;

        var lower = blobName.ToLowerInvariant();
        if (lower.EndsWith(".csv") || lower.EndsWith(".tsv"))
        {
            var lines = previewText.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None)
                .Where(l => l is not null)
                .Take(12)
                .ToList();
            return string.Join("\n", lines);
        }

        return previewText.Length > 5000 ? previewText[..5000] : previewText;
    }

    private static async Task<string> DownloadTextPreviewAsync(BlobContainerClient container, string blobName, int maxBytes, CancellationToken ct)
    {
        try
        {
            var blob = container.GetBlobClient(blobName);
            var ms = new MemoryStream();
            await blob.DownloadToAsync(ms, cancellationToken: ct);
            var bytes = ms.ToArray();
            if (bytes.Length > maxBytes)
                bytes = bytes.AsSpan(0, maxBytes).ToArray();

            try { return Encoding.UTF8.GetString(bytes); }
            catch { return Encoding.Latin1.GetString(bytes); }
        }
        catch (Exception e)
        {
            return $"(preview failed: {e.Message})";
        }
    }

    private static async Task<List<(string Name, long? Size, DateTimeOffset? LastModified)>> ListBlobsViaAzCliAsync(
        string connectionString,
        string containerName,
        string prefix,
        CancellationToken ct)
    {
        var args = new List<string>
        {
            "storage", "blob", "list",
            "--container-name", containerName,
            "--auth-mode", "key",
            "--only-show-errors",
            "--output", "json"
        };
        if (!string.IsNullOrWhiteSpace(prefix))
        {
            args.Add("--prefix");
            args.Add(prefix);
        }

        var env = new Dictionary<string, string> { ["AZURE_STORAGE_CONNECTION_STRING"] = connectionString };
        var json = await RunProcessCaptureStdoutAsync("az", args, ct, env);
        using var doc = JsonDocument.Parse(string.IsNullOrWhiteSpace(json) ? "[]" : json);
        if (doc.RootElement.ValueKind != JsonValueKind.Array)
            return [];

        var outList = new List<(string, long?, DateTimeOffset?)>();
        foreach (var el in doc.RootElement.EnumerateArray().Take(25))
        {
            var name = el.TryGetProperty("name", out var n) ? (n.GetString() ?? "") : "";
            if (name.Length == 0) continue;

            long? size = null;
            if (el.TryGetProperty("properties", out var props) && props.ValueKind == JsonValueKind.Object)
            {
                if (props.TryGetProperty("contentLength", out var cl) && cl.ValueKind == JsonValueKind.Number && cl.TryGetInt64(out var l))
                    size = l;
            }

            DateTimeOffset? lm = null;
            if (el.TryGetProperty("properties", out var props2) && props2.ValueKind == JsonValueKind.Object)
            {
                if (props2.TryGetProperty("lastModified", out var lmEl) && lmEl.ValueKind == JsonValueKind.String &&
                    DateTimeOffset.TryParse(lmEl.GetString(), out var dto))
                {
                    lm = dto;
                }
            }

            outList.Add((name, size, lm));
        }
        return outList;
    }

    private static async Task<string> DownloadTextPreviewViaAzCliAsync(
        string connectionString,
        string containerName,
        string blobName,
        int maxBytes,
        CancellationToken ct)
    {
        var tmp = Path.Combine(Path.GetTempPath(), $"sqlcopilot-blob-{Guid.NewGuid():N}.tmp");
        try
        {
            var args = new List<string>
            {
                "storage", "blob", "download",
                "--container-name", containerName,
                "--name", blobName,
                "--file", tmp,
                "--auth-mode", "key",
                "--only-show-errors",
                "--overwrite", "true",
                "--output", "none"
            };
            var env = new Dictionary<string, string> { ["AZURE_STORAGE_CONNECTION_STRING"] = connectionString };
            _ = await RunProcessCaptureStdoutAsync("az", args, ct, env);

            var bytes = await File.ReadAllBytesAsync(tmp, ct);
            if (bytes.Length > maxBytes)
                bytes = bytes.AsSpan(0, maxBytes).ToArray();

            try { return Encoding.UTF8.GetString(bytes); }
            catch { return Encoding.Latin1.GetString(bytes); }
        }
        catch (Exception e)
        {
            return $"(preview failed: {e.Message})";
        }
        finally
        {
            try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
        }
    }

    private static async Task<string> RunProcessCaptureStdoutAsync(
        string fileName,
        IReadOnlyList<string> args,
        CancellationToken ct,
        IDictionary<string, string>? environmentVariables = null)
    {
        var psi = new ProcessStartInfo(fileName)
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
        };

        foreach (var a in args)
            psi.ArgumentList.Add(a);

        if (environmentVariables is not null)
        {
            foreach (var kvp in environmentVariables)
                psi.Environment[kvp.Key] = kvp.Value;
        }

        using var p = Process.Start(psi);
        if (p is null)
            throw new InvalidOperationException($"Failed to start process: {fileName}");

        var stdoutTask = p.StandardOutput.ReadToEndAsync(ct);
        var stderrTask = p.StandardError.ReadToEndAsync(ct);

        await p.WaitForExitAsync(ct);
        var stdout = await stdoutTask;
        var stderr = await stderrTask;

        if (p.ExitCode != 0)
            throw new InvalidOperationException($"{fileName} exited with {p.ExitCode}: {stderr}".Trim());

        return stdout;
    }

    private static string? GetEnv(string name)
    {
        var v = Environment.GetEnvironmentVariable(name);
        if (v is null) return null;
        v = v.Trim();
        return v.Length == 0 ? null : v;
    }

}

