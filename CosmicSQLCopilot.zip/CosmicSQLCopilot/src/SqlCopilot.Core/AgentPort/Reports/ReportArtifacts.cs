// ============================================================================
// ReportArtifacts.cs — Output paths for generated agent reports
//
// This record is returned by `ReportBuilder` after writing the PDF/HTML/charts.
// The agent orchestrator then converts these local paths into public URLs
// (depending on host configuration).
//
// See also:
// - Builder: `AgentPort/Reports/ReportBuilder.cs`
// - URL construction + hosting: `Agent/AgentOrchestratorService.cs` and `src/SqlCopilot.Web/Program.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

namespace SqlCopilot.Core.AgentPort.Reports;

/// <summary>
/// Local filesystem paths for report artifacts written by <see cref="ReportBuilder"/>.
/// </summary>
public sealed record ReportArtifacts(
    string PdfPath,
    string? HtmlPath,
    IReadOnlyList<string> ChartPngPaths
);

