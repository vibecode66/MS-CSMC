// ============================================================================
// ReportBuilder.cs — Build report artifacts (PDF and optional HTML)
//
// The multi-step agent can produce downloadable artifacts when requested.
// This builder focuses on a lightweight, dependency-contained report:
// - A4 PDF via QuestPDF
// - Optional companion HTML file (useful for quick viewing / debugging)
// - Embeds locally rendered chart PNGs (see `AgentPort/Charts/ChartRenderer.cs`)
// - Includes a small table preview to keep reports readable
//
// See also:
// - Orchestrator that triggers artifact generation: `Agent/AgentOrchestratorService.cs`
// - Artifact envelope: `AgentPort/Reports/ReportArtifacts.cs`
// - Static file hosting in the web app: `src/SqlCopilot.Web/Program.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace SqlCopilot.Core.AgentPort.Reports;

/// <summary>
/// Creates report artifacts (PDF/HTML) from an agent run and its outputs.
/// </summary>
public sealed class ReportBuilder
{
    public ReportArtifacts BuildPdf(
        string outDir,
        string reportTitle,
        string userQuery,
        string sql,
        string executiveSummary,
        IReadOnlyList<string> chartPngPaths,
        IReadOnlyList<string> tableColumns,
        IReadOnlyList<Dictionary<string, object?>> tableRows,
        bool alsoWriteHtml = false)
    {
        Directory.CreateDirectory(outDir);
        var timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        var pdfPath = Path.Combine(outDir, $"report_{timestamp}.pdf");
        string? htmlPath = alsoWriteHtml ? Path.Combine(outDir, $"report_{timestamp}.html") : null;

        var previewRows = tableRows.Take(12).ToList();

        if (alsoWriteHtml && htmlPath is not null)
        {
            var html = BuildHtml(reportTitle, userQuery, sql, executiveSummary, chartPngPaths, tableColumns, previewRows);
            File.WriteAllText(htmlPath, html);
        }

        Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(20);
                page.DefaultTextStyle(x => x.FontSize(11));

                page.Header()
                    .Row(row =>
                    {
                        row.RelativeItem().Text(reportTitle).FontSize(18).SemiBold();
                        row.ConstantItem(160).AlignRight().Text(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
                            .FontSize(9).FontColor(Colors.Grey.Darken2);
                    });

                page.Content().Column(col =>
                {
                    col.Spacing(10);

                    col.Item().Text("Question").FontSize(13).SemiBold();
                    col.Item().Text(userQuery);

                    col.Item().PaddingTop(6).Text("SQL").FontSize(13).SemiBold();
                    col.Item().Background(Colors.Grey.Lighten4).Padding(8).Text(sql).FontFamily(Fonts.CourierNew).FontSize(9);

                    col.Item().PaddingTop(6).Text("Executive summary").FontSize(13).SemiBold();
                    col.Item().Text(executiveSummary);

                    col.Item().PaddingTop(6).Text("Charts").FontSize(13).SemiBold();
                    if (chartPngPaths.Count == 0)
                    {
                        col.Item().Text("(No chart generated)");
                    }
                    else
                    {
                        foreach (var p in chartPngPaths)
                        {
                            col.Item().PaddingVertical(4).Border(1).BorderColor(Colors.Grey.Lighten2).Padding(6)
                                .Image(p, ImageScaling.FitWidth);
                        }
                    }

                    col.Item().PaddingTop(6).Text("Preview").FontSize(13).SemiBold();
                    if (tableColumns.Count == 0 || previewRows.Count == 0)
                    {
                        col.Item().Text("(No rows)");
                    }
                    else
                    {
                        col.Item().Table(t =>
                        {
                            t.ColumnsDefinition(cols =>
                            {
                                foreach (var _ in tableColumns)
                                    cols.RelativeColumn();
                            });

                            t.Header(header =>
                            {
                                foreach (var c in tableColumns)
                                {
                                    header.Cell().Background(Colors.Grey.Lighten3).Padding(4)
                                        .Text(c).SemiBold().FontSize(9);
                                }
                            });

                            foreach (var r in previewRows)
                            {
                                foreach (var c in tableColumns)
                                {
                                    var text = r.TryGetValue(c, out var v) ? (v?.ToString() ?? "") : "";
                                    t.Cell().BorderBottom(1).BorderColor(Colors.Grey.Lighten3).Padding(4)
                                        .Text(text).FontSize(8);
                                }
                            }
                        });
                    }
                });

                page.Footer().AlignRight().Text(txt =>
                {
                    var style = TextStyle.Default.FontSize(9).FontColor(Colors.Grey.Darken2);
                    txt.Span("Page ").Style(style);
                    txt.CurrentPageNumber().Style(style);
                    txt.Span(" / ").Style(style);
                    txt.TotalPages().Style(style);
                });
            });
        }).GeneratePdf(pdfPath);

        return new ReportArtifacts(pdfPath, htmlPath, chartPngPaths.ToList());
    }

    private static string HtmlEscape(string s)
        => System.Net.WebUtility.HtmlEncode(s ?? "");

    private static string BuildHtml(
        string reportTitle,
        string userQuery,
        string sql,
        string executiveSummary,
        IReadOnlyList<string> chartPngPaths,
        IReadOnlyList<string> tableColumns,
        IReadOnlyList<Dictionary<string, object?>> previewRows)
    {
        var generatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        var chartsHtml = chartPngPaths.Count == 0
            ? "<div class=\"muted\">(No chart generated)</div>"
            : string.Join("\n", chartPngPaths.Select(p =>
                $"<div class=\"chart\"><img src=\"{HtmlEscape(p)}\" alt=\"chart\" /></div>"));

        var tableHtml = "(No rows)";
        if (tableColumns.Count > 0 && previewRows.Count > 0)
        {
            var header = string.Join("", tableColumns.Select(c => $"<th>{HtmlEscape(c)}</th>"));
            var body = string.Join("\n", previewRows.Select(r =>
            {
                var tds = string.Join("", tableColumns.Select(c =>
                {
                    var text = r.TryGetValue(c, out var v) ? (v?.ToString() ?? "") : "";
                    return $"<td>{HtmlEscape(text)}</td>";
                }));
                return $"<tr>{tds}</tr>";
            }));
            tableHtml = $"<table><thead><tr>{header}</tr></thead><tbody>{body}</tbody></table>";
        }

        return $$"""
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{{HtmlEscape(reportTitle)}}</title>
  <style>
    body { font-family: Segoe UI, Arial, sans-serif; margin: 24px; color: #0f172a; }
    h1 { font-size: 22px; margin: 0; }
    .meta { color: #475569; font-size: 12px; margin-top: 6px; }
    .section { margin-top: 18px; }
    .label { font-weight: 600; margin-bottom: 6px; }
    pre { background: #f1f5f9; padding: 12px; border-radius: 8px; overflow-x: auto; }
    .muted { color: #64748b; }
    .chart img { max-width: 100%; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border-bottom: 1px solid #e2e8f0; text-align: left; padding: 6px 8px; font-size: 12px; }
    th { background: #f8fafc; }
  </style>
</head>
<body>
  <h1>{{HtmlEscape(reportTitle)}}</h1>
  <div class="meta">{{HtmlEscape(generatedAt)}}</div>

  <div class="section">
    <div class="label">Question</div>
    <div>{{HtmlEscape(userQuery)}}</div>
  </div>

  <div class="section">
    <div class="label">SQL</div>
    <pre>{{HtmlEscape(sql)}}</pre>
  </div>

  <div class="section">
    <div class="label">Executive summary</div>
    <div>{{HtmlEscape(executiveSummary)}}</div>
  </div>

  <div class="section">
    <div class="label">Charts</div>
    {{chartsHtml}}
  </div>

  <div class="section">
    <div class="label">Preview</div>
    {{tableHtml}}
  </div>
</body>
</html>
""";
    }
}

