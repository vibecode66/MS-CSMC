// ============================================================================
// ChartAnalyzer.cs — Infer or parse chart intents for offline report rendering
//
// The agent can produce downloadable report artifacts (PDF/HTML) that embed charts.
// For those artifacts we render PNG charts locally (no external chart service).
//
// This file contains two related utilities:
// - ParseChartSpecs: parse a JSON "chart spec" array (type/x/y/title) when provided
// - InferCharts: infer a reasonable chart (line vs bar) from a simple 2-column dataset
//
// Note: This is distinct from chat cards:
// - Chat cards use QuickChart URLs (`Services/ChartService.cs`) embedded into Adaptive Cards.
//
// See also:
// - Renderer that consumes specs: `AgentPort/Charts/ChartRenderer.cs`
// - Report builder that embeds PNGs: `AgentPort/Reports/ReportBuilder.cs`
// - Agent orchestrator that calls this path: `Agent/AgentOrchestratorService.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Text.Json;

namespace SqlCopilot.Core.AgentPort.Charts;

/// <summary>
/// Utilities for turning tabular results into chart specifications.
/// </summary>
public static class ChartAnalyzer
{
    public static List<ChartSpec> ParseChartSpecs(JsonElement? value)
    {
        var specs = new List<ChartSpec>();
        if (value is null) return specs;
        if (value.Value.ValueKind != JsonValueKind.Array) return specs;

        foreach (var item in value.Value.EnumerateArray())
        {
            if (item.ValueKind != JsonValueKind.Object) continue;
            var type = (item.TryGetProperty("type", out var t) ? t.GetString() : null)?.Trim().ToLowerInvariant() ?? "";
            var x = (item.TryGetProperty("x", out var xEl) ? xEl.GetString() : null)?.Trim() ?? "";
            string? y = null;
            if (item.TryGetProperty("y", out var yEl) && yEl.ValueKind != JsonValueKind.Null)
                y = yEl.GetString()?.Trim();
            string? title = null;
            if (item.TryGetProperty("title", out var ti) && ti.ValueKind != JsonValueKind.Null)
                title = ti.GetString()?.Trim();

            if (type is "bar" or "line" or "scatter")
            {
                if (!string.IsNullOrWhiteSpace(x) && !string.IsNullOrWhiteSpace(y))
                    specs.Add(new ChartSpec(type, x, y, title));
            }
            else if (type == "pie")
            {
                if (!string.IsNullOrWhiteSpace(x))
                    specs.Add(new ChartSpec(type, x, y, title));
            }
        }

        return specs;
    }

    public static List<ChartSpec> InferCharts(List<string> columns, List<Dictionary<string, object?>> rows)
    {
        if (columns.Count != 2 || rows.Count == 0)
            return [];

        var c1 = columns[0];
        var c2 = columns[1];

        bool c1Date = rows.Any(r => r.TryGetValue(c1, out var v) && v is DateTime);
        bool c2Num = rows.Any(r => r.TryGetValue(c2, out var v) && IsNumeric(v));
        bool c1Num = rows.Any(r => r.TryGetValue(c1, out var v) && IsNumeric(v));
        bool c2Date = rows.Any(r => r.TryGetValue(c2, out var v) && v is DateTime);

        if (c1Date && c2Num)
            return [new ChartSpec("line", c1, c2, "Trend")];
        if (c2Date && c1Num)
            return [new ChartSpec("line", c2, c1, "Trend")];
        if (!c1Num && c2Num)
            return [new ChartSpec("bar", c1, c2, "Bar chart")];
        if (!c2Num && c1Num)
            return [new ChartSpec("bar", c2, c1, "Bar chart")];

        return [];
    }

    public static bool ShouldHorizontalBar(IEnumerable<string> labels)
    {
        var list = labels.Take(200).ToList();
        if (list.Count == 0) return false;
        var maxLen = list.Max(s => (s ?? "").Length);
        var uniq = list.Distinct().Count();
        return maxLen >= 12 || uniq >= 8;
    }

    private static bool IsNumeric(object? v) =>
        v is sbyte or byte or short or ushort or int or uint or long or ulong or float or double or decimal;
}

