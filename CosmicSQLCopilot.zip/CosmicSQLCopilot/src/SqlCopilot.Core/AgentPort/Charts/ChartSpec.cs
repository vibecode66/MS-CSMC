// ============================================================================
// ChartSpec.cs — Small chart specification contract (type/x/y/title)
//
// Used by the agent report pipeline to represent "what to draw" independent of
// any specific rendering library. A spec can be inferred from data (`ChartAnalyzer`)
// or parsed from JSON when another component provides it.
//
// See also:
// - Spec inference/parsing: `AgentPort/Charts/ChartAnalyzer.cs`
// - Spec rendering to PNG: `AgentPort/Charts/ChartRenderer.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

namespace SqlCopilot.Core.AgentPort.Charts;

/// <summary>
/// A minimal chart specification for offline rendering.
/// </summary>
public sealed record ChartSpec(
    string Type,
    string X,
    string? Y,
    string? Title
);

