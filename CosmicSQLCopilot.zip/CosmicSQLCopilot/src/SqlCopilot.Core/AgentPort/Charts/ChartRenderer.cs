// ============================================================================
// ChartRenderer.cs — Render chart PNGs locally (ScottPlot) for reports
//
// This renderer is used for *report artifacts* (PDF/HTML) produced by the agent.
// It writes PNGs to disk, then the report builder embeds them.
//
// Why local PNG rendering exists:
// - Teams chat cards can rely on externally hosted images (QuickChart URLs).
// - Report PDFs/HTML should be self-contained and stable, so we render locally.
//
// See also:
// - Spec inference: `AgentPort/Charts/ChartAnalyzer.cs`
// - Chart spec model: `AgentPort/Charts/ChartSpec.cs`
// - Report embedding: `AgentPort/Reports/ReportBuilder.cs`
// - Agent orchestration: `Agent/AgentOrchestratorService.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using ScottPlot;
using System.Text.Json;

namespace SqlCopilot.Core.AgentPort.Charts;

/// <summary>
/// Renders one or more chart images from tabular row data.
/// </summary>
public sealed class ChartRenderer
{
    private static string EnsureUniquePath(string path)
    {
        if (!File.Exists(path))
            return path;

        var dir = Path.GetDirectoryName(path) ?? "";
        var baseName = Path.GetFileNameWithoutExtension(path);
        var ext = Path.GetExtension(path);

        for (int i = 1; i <= 2000; i++)
        {
            var candidate = Path.Combine(dir, $"{baseName}_{i}{ext}");
            if (!File.Exists(candidate))
                return candidate;
        }

        return Path.Combine(dir, $"{baseName}_{Guid.NewGuid():N}{ext}");
    }

    public List<string> RenderChartsPng(
        List<string> columns,
        List<Dictionary<string, object?>> rows,
        IReadOnlyList<ChartSpec> specs,
        string outDir,
        string filePrefix = "chart",
        int startIndex = 1)
    {
        Directory.CreateDirectory(outDir);
        var outputs = new List<string>();

        for (int i = 0; i < specs.Count; i++)
        {
            var spec = specs[i];
            var type = (spec.Type ?? "").Trim().ToLowerInvariant();
            var title = spec.Title ?? (type switch
            {
                "line" => "Trend",
                "pie" => "Distribution",
                "scatter" => "Scatter plot",
                _ => "Chart"
            });

            var idx = startIndex + i;
            var safePrefix = string.IsNullOrWhiteSpace(filePrefix) ? "chart" : filePrefix.Trim();
            var path = EnsureUniquePath(Path.Combine(outDir, $"{safePrefix}_{idx}_{type}.png"));

            if (type is "bar" or "line" or "scatter")
            {
                if (string.IsNullOrWhiteSpace(spec.X) || string.IsNullOrWhiteSpace(spec.Y))
                    continue;
                if (!columns.Contains(spec.X) || !columns.Contains(spec.Y))
                    continue;

                if (type == "bar")
                    RenderBar(rows, spec.X, spec.Y!, title, path);
                else if (type == "line")
                    RenderLine(rows, spec.X, spec.Y!, title, path);
                else
                    RenderScatter(rows, spec.X, spec.Y!, title, path);
            }
            else if (type == "pie")
            {
                if (string.IsNullOrWhiteSpace(spec.X) || !columns.Contains(spec.X))
                    continue;
                var y = spec.Y;
                if (string.IsNullOrWhiteSpace(y) || !columns.Contains(y))
                {
                    y = columns.FirstOrDefault(c =>
                        !c.Equals(spec.X, StringComparison.OrdinalIgnoreCase) &&
                        rows.Any(r => r.TryGetValue(c, out var v) && TryParseDouble(v, out _)));
                }
                RenderPie(rows, spec.X, y, title, path);
            }
            else
            {
                continue;
            }

            outputs.Add(path);
        }

        return outputs;
    }

    private static void RenderBar(List<Dictionary<string, object?>> rows, string xCol, string yCol, string title, string outPath)
    {
        var labels = rows.Select(r => (r.TryGetValue(xCol, out var v) ? v : null)?.ToString() ?? "").ToList();
        var values = rows.Select(r => ToDouble(r.TryGetValue(yCol, out var v) ? v : null)).ToArray();

        var plt = new Plot();
        double[] positions = Enumerable.Range(0, values.Length).Select(i => (double)i + 1).ToArray();

        bool horizontal = ChartAnalyzer.ShouldHorizontalBar(labels);

        if (horizontal)
        {
            var bars = values.Select((v, idx) => new ScottPlot.Bar { Position = positions[idx], Value = v }).ToArray();
            var barPlot = plt.Add.Bars(bars);
            barPlot.Horizontal = true;

            plt.Axes.Left.SetTicks(positions, labels.ToArray());
            plt.Axes.Left.Label.Text = xCol;
            plt.Axes.Bottom.Label.Text = yCol;
            plt.Axes.Margins(left: 0, bottom: 0.05, right: 0.05, top: 0.1);

            if (values.Length > 0 && values.All(v => v >= 0))
            {
                var max = values.Max();
                plt.Axes.SetLimitsX(0, max <= 0 ? 1 : max * 1.05);
            }
        }
        else
        {
            var bars = values.Select((v, idx) => new ScottPlot.Bar
            {
                Position = positions[idx],
                Value = v,
                Size = 0.85,
                FillColor = Colors.Gray,
                LineColor = Colors.Black,
                LineWidth = 1
            }).ToArray();
            plt.Add.Bars(bars);
            plt.Axes.Bottom.SetTicks(positions, labels.ToArray());
            plt.Axes.Bottom.Label.Text = xCol;
            plt.Axes.Left.Label.Text = yCol;

            var maxLen = labels.Count == 0 ? 0 : labels.Max(s => (s ?? "").Length);
            plt.Axes.Bottom.TickLabelStyle.Rotation = (labels.Count > 6 || maxLen > 12) ? 35 : 0;
            plt.Axes.Bottom.MinimumSize = 80;
            plt.Axes.Margins(left: 0.05, bottom: 0.05, right: 0.05, top: 0.1);

            if (values.Length > 0 && values.All(v => v >= 0))
            {
                var max = values.Max();
                plt.Axes.SetLimitsY(0, max <= 0 ? 1 : max * 1.05);
            }
        }

        plt.Title(title);

        int n = Math.Max(1, labels.Count);
        int width = Math.Clamp(520 + (horizontal ? 0 : 90 * n), 800, 1600);
        int height = Math.Clamp((horizontal ? 220 + 48 * n : 520), 520, 1400);
        plt.SavePng(outPath, width, height);
    }

    private static void RenderLine(List<Dictionary<string, object?>> rows, string xCol, string yCol, string title, string outPath)
    {
        var labels = rows.Select(r => (r.TryGetValue(xCol, out var v) ? v : null)?.ToString() ?? "").ToList();
        var ys = rows.Select(r => ToDouble(r.TryGetValue(yCol, out var v) ? v : null)).ToArray();
        var xs = Enumerable.Range(0, ys.Length).Select(i => (double)i).ToArray();

        var plt = new Plot();
        plt.Add.Scatter(xs, ys);
        plt.Axes.Bottom.SetTicks(xs, labels.ToArray());
        plt.Axes.Bottom.Label.Text = xCol;
        plt.Axes.Left.Label.Text = yCol;
        plt.Axes.Bottom.TickLabelStyle.Rotation = 30;
        plt.Title(title);
        plt.SavePng(outPath, 1100, 600);
    }

    private static void RenderScatter(List<Dictionary<string, object?>> rows, string xCol, string yCol, string title, string outPath)
    {
        var xs = rows.Select(r => ToDouble(r.TryGetValue(xCol, out var v) ? v : null)).ToArray();
        var ys = rows.Select(r => ToDouble(r.TryGetValue(yCol, out var v) ? v : null)).ToArray();

        var plt = new Plot();
        plt.Add.Scatter(xs, ys);
        plt.Axes.Bottom.Label.Text = xCol;
        plt.Axes.Left.Label.Text = yCol;
        plt.Title(title);
        plt.SavePng(outPath, 1100, 600);
    }

    private static void RenderPie(List<Dictionary<string, object?>> rows, string namesCol, string? valuesCol, string title, string outPath)
    {
        var labels = rows.Select(r => (r.TryGetValue(namesCol, out var v) ? v : null)?.ToString() ?? "").ToArray();
        double[] values;
        if (!string.IsNullOrWhiteSpace(valuesCol))
            values = rows.Select(r => ToDouble(r.TryGetValue(valuesCol!, out var v) ? v : null)).ToArray();
        else
            values = rows.Select(_ => 1.0).ToArray();

        var plt = new Plot();
        var pie = plt.Add.Pie(values);

        plt.Grid.IsVisible = false;
        plt.Axes.Frameless();

        double total = values.Sum();
        for (int i = 0; i < pie.Slices.Count; i++)
        {
            var raw = i < labels.Length ? labels[i] : "";
            var name = string.IsNullOrWhiteSpace(raw) ? $"(blank {i + 1})" : raw.Trim();
            pie.Slices[i].LegendText = name;

            if (total > 0)
            {
                var frac = Math.Max(0, values[i]) / total;
                pie.Slices[i].Label = frac >= 0.04 ? $"{frac:0.0%}" : "";
            }
        }

        plt.ShowLegend();
        plt.Title(title);
        plt.SavePng(outPath, 1050, 650);
    }

    private static bool TryParseDouble(object? v, out double value)
    {
        value = 0;
        if (v is null) return false;
        if (v is JsonElement je)
        {
            if (je.ValueKind == JsonValueKind.Number)
            {
                if (je.TryGetDouble(out var jd)) { value = jd; return true; }
                if (je.TryGetInt64(out var jl)) { value = jl; return true; }
                if (je.TryGetDecimal(out var jdec)) { value = (double)jdec; return true; }
                return false;
            }
            if (je.ValueKind == JsonValueKind.String)
            {
                var s = je.GetString();
                return s is not null && double.TryParse(s, out value);
            }
            return false;
        }
        if (v is double d) { value = d; return true; }
        if (v is float f) { value = f; return true; }
        if (v is decimal m) { value = (double)m; return true; }
        if (v is int i) { value = i; return true; }
        if (v is long l) { value = l; return true; }
        if (v is short s2) { value = s2; return true; }
        if (v is uint ui) { value = ui; return true; }
        if (v is ulong ul) { value = ul; return true; }
        if (v is string str) return double.TryParse(str, out value);
        return false;
    }

    private static double ToDouble(object? v)
    {
        if (v is null) return 0;
        if (v is JsonElement je)
        {
            if (je.ValueKind == JsonValueKind.Number)
            {
                if (je.TryGetDouble(out var jd)) return jd;
                if (je.TryGetInt64(out var jl)) return jl;
                if (je.TryGetDecimal(out var jdec)) return (double)jdec;
                return 0;
            }
            if (je.ValueKind == JsonValueKind.String)
            {
                var s2 = je.GetString();
                if (s2 is not null && double.TryParse(s2, out var parsed2)) return parsed2;
                return 0;
            }
            return 0;
        }
        if (v is double d) return d;
        if (v is float f) return f;
        if (v is decimal m) return (double)m;
        if (v is int i) return i;
        if (v is long l) return l;
        if (v is short s) return s;
        if (v is uint ui) return ui;
        if (v is ulong ul) return ul;
        if (v is string str && double.TryParse(str, out var parsed)) return parsed;
        return 0;
    }
}

