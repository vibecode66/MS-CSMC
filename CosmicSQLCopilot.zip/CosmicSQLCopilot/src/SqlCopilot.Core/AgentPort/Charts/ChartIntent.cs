// ============================================================================
// ChartIntent.cs — Heuristics to decide when charts are not appropriate
//
// Some user requests are “lookup/detail” oriented (e.g., "show ticket 1-0000123").
// In those cases, charts can be distracting or misleading. This helper provides
// lightweight heuristics to skip charting in such scenarios.
//
// This is intentionally heuristic and conservative; it complements the LLM’s
// chart suggestion logic rather than replacing it.
//
// See also:
// - Card rendering + chart embedding: `Services/AdaptiveCardService.cs`
// - QuickChart URL generation: `Services/ChartService.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Text.RegularExpressions;

namespace SqlCopilot.Core.AgentPort.Charts;

/// <summary>
/// Small intent helpers for deciding whether chart output should be suppressed.
/// </summary>
public static class ChartIntent
{
    private static readonly Regex TicketLikeId = new(@"\b\d-\d{10,20}\b", RegexOptions.Compiled);

    public static bool TryExtractTicketId(string userQuery, out string ticketId)
    {
        ticketId = "";
        var q = userQuery ?? "";
        var m = TicketLikeId.Match(q);
        if (!m.Success) return false;
        ticketId = m.Value.Trim();
        return ticketId.Length > 0;
    }

    public static bool ShouldSkipCharts(string userQuery)
    {
        var q = (userQuery ?? "").Trim();
        if (q.Length == 0) return false;

        var ql = q.ToLowerInvariant();

        bool mentionsTicketOrCase =
            ql.Contains("ticket") || ql.Contains("case") || ql.Contains("sr ") || ql.Contains("sr#") || ql.Contains("incident");
        bool wantsDetails =
            ql.Contains("details") || ql.Contains("detail") || ql.Contains("show me") || ql.Contains("tell me") || ql.Contains("lookup");
        bool hasId = TryExtractTicketId(q, out _);

        if (mentionsTicketOrCase && hasId) return true;
        if (wantsDetails && hasId) return true;

        return false;
    }
}

