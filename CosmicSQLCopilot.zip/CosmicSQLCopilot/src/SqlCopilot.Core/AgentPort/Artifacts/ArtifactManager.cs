// ============================================================================
// ArtifactManager.cs — Simple artifact directory utilities + retention pruning
//
// The agent can emit "artifacts" (logs, intermediate JSON, reports, chart PNGs).
// This helper provides:
// - A stable directory root (created on demand)
// - Timestamp naming
// - Best-effort pruning to keep disk usage bounded
//
// See also:
// - Agent artifact configuration: `Agent/AgentArtifactsOptions.cs`
// - Report generation: `AgentPort/Reports/ReportBuilder.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Globalization;

namespace SqlCopilot.Core.AgentPort.Artifacts;

/// <summary>
/// Utility for managing an artifact folder (paths + pruning).
/// </summary>
public sealed class ArtifactManager
{
    public string LogsDir { get; }
    public int KeepLastFiles { get; }

    public ArtifactManager(string logsDir, int keepLastFiles = 4)
    {
        LogsDir = logsDir;
        KeepLastFiles = Math.Max(0, keepLastFiles);
        Directory.CreateDirectory(LogsDir);
    }

    public string Timestamp() =>
        DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture);

    public string Combine(string fileName) => Path.Combine(LogsDir, fileName);

    public void Prune()
    {
        if (KeepLastFiles <= 0) return;
        if (!Directory.Exists(LogsDir)) return;

        var files = new DirectoryInfo(LogsDir)
            .EnumerateFiles("*", SearchOption.TopDirectoryOnly)
            .OrderByDescending(f => f.LastWriteTimeUtc)
            .ToList();

        if (files.Count <= KeepLastFiles) return;

        foreach (var f in files.Skip(KeepLastFiles))
        {
            try { f.Delete(); }
            catch { /* best effort */ }
        }
    }
}

