// ============================================================================
// CsvUtil.cs — Write tabular results to CSV (artifact helper)
//
// Used by the agent/report pipeline to persist results in a simple portable format.
// This keeps debugging and downstream analysis easy (Excel, pandas, etc.).
//
// See also:
// - Report generation: `AgentPort/Reports/ReportBuilder.cs`
// - Artifact management: `AgentPort/Artifacts/ArtifactManager.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.Globalization;
using CsvHelper;

namespace SqlCopilot.Core.AgentPort.Artifacts;

/// <summary>
/// CSV serialization helpers for artifact output.
/// </summary>
public static class CsvUtil
{
    public static void WriteCsv(string path, IReadOnlyList<string> columns, IReadOnlyList<Dictionary<string, object?>> rows)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        using var writer = new StreamWriter(path);
        using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);

        foreach (var c in columns)
            csv.WriteField(c);
        csv.NextRecord();

        foreach (var r in rows)
        {
            foreach (var c in columns)
                csv.WriteField(r.TryGetValue(c, out var v) ? v : null);
            csv.NextRecord();
        }
    }
}

