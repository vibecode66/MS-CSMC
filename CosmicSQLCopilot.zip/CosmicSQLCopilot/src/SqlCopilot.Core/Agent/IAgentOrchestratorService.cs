namespace SqlCopilot.Core.Agent;

/// <summary>
/// Runs the multi-step investigation agent ("sql_agent" mode).
///
/// See also:
/// - Implementation: `Agent/AgentOrchestratorService.cs`
/// - Planner and summary prompts: `Agent/AgentPrompts.cs`
/// - Conversation routing: `Services/ConversationOrchestratorService.cs`
/// </summary>
public interface IAgentOrchestratorService
{
    Task<AgentRunResult> RunAsync(string userQuery, CancellationToken cancellationToken = default);
}

