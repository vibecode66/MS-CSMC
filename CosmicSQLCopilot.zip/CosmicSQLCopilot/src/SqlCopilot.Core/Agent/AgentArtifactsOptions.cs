namespace SqlCopilot.Core.Agent;

/// <summary>
/// Configuration for *agent-generated artifacts* (report PDF/HTML and chart PNGs).
///
/// Artifacts are created by <see cref="AgentOrchestratorService"/> when the caller asks
/// for a downloadable report (e.g. "include report" / "pdf" / "artifacts").
///
/// Hosting note:
/// - When running under <c>SqlCopilot.Web</c>, the web app typically serves these files
///   via static files middleware so Teams can open links.
///   See `src/SqlCopilot.Web/Program.cs` ("Serve agent artifacts").
/// </summary>
public sealed class AgentArtifactsOptions
{
    /// <summary>
    /// Configuration section name in <c>appsettings.json</c>.
    /// </summary>
    public const string SectionName = "AgentArtifacts";

    /// <summary>
    /// Local directory where artifacts are written (PDF/HTML/PNG/CSV).
    /// If empty, the host may choose a default temp/data folder.
    /// </summary>
    public string Directory { get; set; } = "";

    /// <summary>
    /// Best-effort retention control. When new artifacts are produced, older files may
    /// be cleaned up to keep the directory bounded.
    ///
    /// See also: `src/SqlCopilot.Core/AgentPort/Artifacts/ArtifactManager.cs`.
    /// </summary>
    public int KeepLastFiles { get; set; } = 20;

    /// <summary>
    /// Public path prefix where the host serves artifacts (relative URL path).
    /// Defaults to <c>/artifacts</c>.
    ///
    /// In the default web host, this is wired via static files middleware in
    /// `src/SqlCopilot.Web/Program.cs`.
    /// </summary>
    public string PublicBasePath { get; set; } = "/artifacts";

    /// <summary>
    /// Optional absolute base URL for artifact links (e.g. <c>https://app.azurewebsites.net</c>).
    ///
    /// If empty, links are returned as relative paths (e.g. <c>/artifacts/report_...pdf</c>)
    /// and rely on the channel/host to resolve them.
    /// </summary>
    public string PublicBaseUrl { get; set; } = "";
}

