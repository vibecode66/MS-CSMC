// ============================================================================
// AgentOrchestratorService.cs — Multi-step “investigate, execute, summarize” agent
//
// This orchestrator powers the "sql_agent" mode: it decomposes a user request into
// 1–N concrete sub-questions, runs each as a safe read-only query, and then produces
// a concise summary. Optionally, it can build report artifacts (PDF/HTML + chart PNGs).
//
// Separation of concerns (why there are multiple chart paths):
// - Teams chat cards embed a QuickChart image URL (see `Services/ChartService.cs`).
// - Report artifacts render PNG charts locally via `AgentPort/Charts/*` so they can be
//   packaged in PDFs/HTML without external dependencies.
//
// Key collaborators:
// - Planning prompts: `AgentPrompts.cs` (step planner + evidence summarizer)
// - NL→SQL: `Services/SqlGeneratorService.cs`
// - Execution: `Services/QueryExecutionService.cs`
// - Card rendering (per-step attachments): `Services/AdaptiveCardService.cs`
// - Artifact/report generation: `AgentPort/Reports/ReportBuilder.cs` and `AgentPort/Artifacts/*`
//
// See also:
// - Developer map: `docs/CODE_TOUR.md`
// - Step/result contracts (including `ChartUrl`): `Agent/AgentContracts.cs`
// ============================================================================

using System.ClientModel;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Azure.AI.OpenAI;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpenAI.Chat;
using SqlCopilot.Core.AgentPort.Charts;
using SqlCopilot.Core.AgentPort.Reports;
using SqlCopilot.Core.AgentPort.Sources;
using SqlCopilot.Core.Exceptions;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Services;
using SqlCopilot.Core.Tracing;

namespace SqlCopilot.Core.Agent;

public sealed class AgentOrchestratorService : IAgentOrchestratorService
{
    private readonly AgentOptions _agentOptions;
    private readonly AgentArtifactsOptions _artifactsOptions;
    private readonly AzureOpenAIOptions _openAiOptions;
    private readonly ChatClient _chatClient;
    private readonly IJsonLlmClient _jsonLlm;
    private readonly ISchemaDiscoveryService _schemaService;
    private readonly ISqlGeneratorService _sqlGenerator;
    private readonly IQueryExecutionService _queryExecutor;
    private readonly IChartService _chartService;
    private readonly ChartRenderer _pngChartRenderer = new();
    private readonly ReportBuilder _reportBuilder = new();
    private readonly ILogger<AgentOrchestratorService> _logger;
    private readonly IArtifactTokenService _artifactTokenService;
    private readonly IConversationTraceSink _trace;

    public AgentOrchestratorService(
        IOptions<AgentOptions> agentOptions,
        IOptions<AgentArtifactsOptions> artifactsOptions,
        IOptions<AzureOpenAIOptions> openAiOptions,
        IJsonLlmClient jsonLlm,
        ISchemaDiscoveryService schemaService,
        ISqlGeneratorService sqlGenerator,
        IQueryExecutionService queryExecutor,
        IChartService chartService,
        IArtifactTokenService artifactTokenService,
        IConversationTraceSink trace,
        ILogger<AgentOrchestratorService> logger)
    {
        _agentOptions = (agentOptions ?? throw new ArgumentNullException(nameof(agentOptions))).Value;
        _artifactsOptions = (artifactsOptions ?? throw new ArgumentNullException(nameof(artifactsOptions))).Value;
        _openAiOptions = (openAiOptions ?? throw new ArgumentNullException(nameof(openAiOptions))).Value;
        _jsonLlm = jsonLlm ?? throw new ArgumentNullException(nameof(jsonLlm));
        _schemaService = schemaService ?? throw new ArgumentNullException(nameof(schemaService));
        _sqlGenerator = sqlGenerator ?? throw new ArgumentNullException(nameof(sqlGenerator));
        _queryExecutor = queryExecutor ?? throw new ArgumentNullException(nameof(queryExecutor));
        _chartService = chartService ?? throw new ArgumentNullException(nameof(chartService));
        _artifactTokenService = artifactTokenService ?? throw new ArgumentNullException(nameof(artifactTokenService));
        _trace = trace ?? throw new ArgumentNullException(nameof(trace));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        // Reuse the same Azure OpenAI deployment as SQL generation.
        var client = new AzureOpenAIClient(
            new Uri(_openAiOptions.Endpoint),
            new ApiKeyCredential(_openAiOptions.ApiKey));
        _chatClient = client.GetChatClient(_openAiOptions.DeploymentName);
    }

    public async Task<AgentRunResult> RunAsync(string userQuery, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(userQuery))
            throw new ArgumentException("User query is required.", nameof(userQuery));

        userQuery = userQuery.Trim();

        if (LooksLikeSchemaRequest(userQuery))
            return await RunSchemaSnapshotAsync(userQuery, cancellationToken);

        var source = RouteSource(userQuery);
        if (source == AgentSource.Blob)
            return await RunBlobAsync(userQuery, cancellationToken);

        // Azure SQL default.
        return await RunAzureSqlAsync(userQuery, cancellationToken);
    }

    private enum AgentSource { AzureSql, Blob }

    private static readonly Regex BlobFileMention =
        new(@"\b[\w][\w\-.]{0,180}\.(csv|tsv|json|txt|md|pdf|xlsx)\b|\""[^\\""]+?\.(csv|tsv|json|txt|md|pdf|xlsx)\""",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

    private static AgentSource RouteSource(string userQuery)
    {
        if (BlobFileMention.IsMatch(userQuery) || LooksLikeBlobRequest(userQuery))
            return AgentSource.Blob;

        return AgentSource.AzureSql;
    }

    private static bool LooksLikeSchemaRequest(string userQuery)
    {
        var q = (userQuery ?? "").Trim().ToLowerInvariant();
        if (q.Length == 0) return false;

        // Strong intent phrases
        if (q.Contains("/schema")) return true;
        if (q.Contains("show schema") || q.Contains("schema snapshot") || q.Contains("schema dump")) return true;
        if (q.Contains("what tables") || q.Contains("list tables") || q.Contains("show tables")) return true;
        if (q.StartsWith("schema")) return true;

        // Avoid matching normal analytical prompts that happen to mention schema in passing.
        return false;
    }

    private static bool LooksLikeBlobRequest(string userQuery)
    {
        var q = (userQuery ?? "").Trim().ToLowerInvariant();
        if (q.Length == 0) return false;

        // Direct cues
        if (q.Contains("azurite")) return true;

        bool mentionsBlob = Regex.IsMatch(q, @"\bblob(s)?\b") || q.Contains("blob storage");
        if (!mentionsBlob) return false;

        // Strong intent: listing/inventorying files
        if (q.Contains("list") || q.Contains("show") || q.Contains("inventory") || q.Contains("what files") || q.Contains("what is in"))
            return true;

        // Container/file phrasing
        if (q.Contains("container") || q.Contains("prefix") || q.Contains("file") || q.Contains("files"))
            return true;

        return false;
    }

    private async Task<AgentRunResult> RunSchemaSnapshotAsync(string userQuery, CancellationToken ct)
    {
        return await RunAzureSqlSchemaSnapshotAsync(userQuery, ct);
    }

    private async Task<AgentRunResult> RunAzureSqlSchemaSnapshotAsync(string userQuery, CancellationToken ct)
    {
        var schema = await _schemaService.GetSchemaAsync(ct);
        var schemaText = schema.ToSchemaSnapshot(includeSampleData: false);
        return await WriteSchemaArtifactAsync("azure_sql", schemaText, ct);
    }

    private async Task<AgentRunResult> WriteSchemaArtifactAsync(string source, string schemaText, CancellationToken ct)
    {
        var artifactsDir = ResolveArtifactsDir();
        Directory.CreateDirectory(artifactsDir);

        var timestamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
        var fileName = $"schema_{source}_{timestamp}.txt";
        var path = Path.Combine(artifactsDir, fileName);
        await File.WriteAllTextAsync(path, schemaText, ct);

        var url = BuildPublicUrl(path, artifactsDir);
        var previewMax = 12000;
        var preview = schemaText.Length <= previewMax ? schemaText : schemaText[..previewMax] + "\n... (truncated)";

        var info = new AgentSchemaInfo(
            Source: source,
            SchemaUrl: url,
            Preview: preview);

        var summary =
            $"- Schema source: {source}\n" +
            "- Returned schema snapshot in-card (may be truncated for large schemas).";

        return new AgentRunResult(
            Mode: "schema_snapshot",
            UserQuery: "schema",
            Steps: Array.Empty<AgentStepResult>(),
            Summary: summary,
            Report: null,
            Payload: info);
    }

    private static bool LooksLikeAzureSqlAuthFailure(Exception ex)
    {
        // We wrap SqlException into ConnectionFactoryException; message often contains 18456.
        var msg = ex.ToString();
        return msg.Contains("Error Number:18456", StringComparison.OrdinalIgnoreCase) ||
               msg.Contains("Error #18456", StringComparison.OrdinalIgnoreCase) ||
               msg.Contains("Login failed", StringComparison.OrdinalIgnoreCase) ||
               msg.Contains("18456", StringComparison.OrdinalIgnoreCase);
    }

    private string ResolveArtifactsDir()
    {
        var configured = (_artifactsOptions.Directory ?? "").Trim();
        if (configured.Length > 0) return configured;

        var home = Environment.GetEnvironmentVariable("HOME");
        return !string.IsNullOrWhiteSpace(home)
            ? Path.Combine(home, "data", "sqlcopilot", "artifacts")
            : Path.Combine(Path.GetTempPath(), "sqlcopilot", "artifacts");
    }

    private async Task<AgentRunResult> RunBlobAsync(string userQuery, CancellationToken ct)
    {
        var artifactsDir = ResolveArtifactsDir();
        Directory.CreateDirectory(artifactsDir);

        var blob = new BlobSource(_jsonLlm, _pngChartRenderer, artifactsDir);
        var result = await blob.RunAsync(userQuery, ct);

        // Best-effort extract summary
        string summary = "Generated a response from blob previews.";
        try
        {
            var json = JsonSerializer.Serialize(result);
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("summary", out var s) && s.ValueKind == JsonValueKind.String)
                summary = (s.GetString() ?? summary).Trim();
        }
        catch { }

        return new AgentRunResult(
            Mode: "blob_query",
            UserQuery: userQuery,
            Steps: Array.Empty<AgentStepResult>(),
            Summary: summary,
            Report: null,
            Payload: result);
    }

    private async Task<AgentRunResult> RunAzureSqlAsync(string userQuery, CancellationToken ct)
    {
        _logger.LogInformation("AGENT_AZURESQL_START userQueryPreview=\"{Preview}\"",
            SqlCopilot.Core.Services.LogText.OneLine(userQuery, 220));
        _trace.Step("AGENT_START", "sql_agent", outgoing: new { userQueryPreview = LogText.OneLine(userQuery, 400) });
        var schema = await _schemaService.GetSchemaAsync(ct);
        var schemaPrompt = schema.ToSchemaPrompt();

        var plans = await PlanStepsAsync(schemaPrompt, userQuery, ct);
        if (plans.Count == 0)
            plans = new List<AgentStepPlan> { new("Answer the question", userQuery) };

        var executed = new List<AgentStepResult>();
        for (int i = 0; i < plans.Count; i++)
        {
            var step = plans[i];
            var stepQuery = step.Question.Trim();
            if (stepQuery.Length == 0) continue;

            _logger.LogInformation("Agent(AzureSQL) step {Index}/{Total}: {Name}", i + 1, plans.Count, step.Name);
            _trace.Step("AGENT_STEP_START", "sql_agent",
                outgoing: new { index = i + 1, total = plans.Count, name = step.Name, question = LogText.OneLine(stepQuery, 800) });

            var (sqlResponse, queryResult) = await _sqlGenerator.GenerateAndValidateAsync(
                stepQuery, schema, _queryExecutor, ct);

            queryResult ??= new QueryResult
            {
                IsSuccess = false,
                ErrorMessage = sqlResponse.ErrorMessage ?? "Query failed to execute.",
                SqlQuery = sqlResponse.GeneratedSql
            };

            // Optional refinement loop for readability (bound attempts).
            if (queryResult.IsSuccess)
            {
                var candidateSql = (sqlResponse.GeneratedSql ?? queryResult.SqlQuery ?? "").Trim();
                var refined = await TryRefineAzureSqlAsync(
                    userQuery: stepQuery,
                    schemaPrompt: schemaPrompt,
                    candidateSql: candidateSql,
                    initial: queryResult,
                    maxRefinements: Math.Clamp(_agentOptions.MaxRefinements, 0, 4),
                    ct: ct);

                if (!string.Equals(refined.Sql, candidateSql, StringComparison.Ordinal) || !ReferenceEquals(refined.Result, queryResult))
                {
                    sqlResponse.GeneratedSql = refined.Sql;
                    queryResult = refined.Result;
                }
            }

            string? chartUrl = null;
            if (queryResult.IsSuccess &&
                sqlResponse.SuggestedChart != ChartType.Table &&
                _chartService.CanRenderChart(queryResult, sqlResponse.SuggestedChart))
            {
                chartUrl = _chartService.GenerateChartUrl(queryResult, sqlResponse.SuggestedChart);
            }

            executed.Add(new AgentStepResult(
                Index: i + 1,
                Name: string.IsNullOrWhiteSpace(step.Name) ? $"Step {i + 1}" : step.Name.Trim(),
                Question: stepQuery,
                SqlResponse: sqlResponse,
                QueryResult: queryResult,
                ChartUrl: chartUrl));

            _trace.Step("AGENT_STEP_DONE", "sql_agent",
                outgoing: new { index = i + 1, name = step.Name },
                incoming: new { success = queryResult.IsSuccess, rows = queryResult.TotalRowCount, cols = queryResult.Columns.Count, chart = sqlResponse.SuggestedChart.ToString() },
                success: queryResult.IsSuccess,
                error: queryResult.ErrorMessage,
                sqlText: sqlResponse.GeneratedSql,
                dbRows: queryResult.TotalRowCount,
                dbCols: queryResult.Columns.Count,
                dbTruncated: queryResult.IsTruncated);
        }

        var summary = await SummarizeAsync(userQuery, executed, ct);
        var report = await TryBuildReportAsync(userQuery, executed, ct);

        _trace.Step("AGENT_SUMMARY", "sql_agent", incoming: new { summaryPreview = LogText.OneLine(summary, 800), steps = executed.Count });

        return new AgentRunResult(
            Mode: "agent_generate_report",
            UserQuery: userQuery,
            Steps: executed,
            Summary: summary,
            Report: report);
    }

    private sealed record RefineResult(string Sql, QueryResult Result);

    private async Task<RefineResult> TryRefineAzureSqlAsync(
        string userQuery,
        string schemaPrompt,
        string candidateSql,
        QueryResult initial,
        int maxRefinements,
        CancellationToken ct)
    {
        var sql = candidateSql;
        var current = initial;

        for (int attempt = 0; attempt < Math.Max(0, maxRefinements); attempt++)
        {
            var issues = ReadabilityIssues(current);
            if (issues.Count == 0) break;

            var issueText = string.Join("; ", issues);
            var refinedSql = await RefineTSqlAsync(schemaPrompt, userQuery, sql, issueText, ct);
            if (string.IsNullOrWhiteSpace(refinedSql) || string.Equals(refinedSql, sql, StringComparison.Ordinal))
                break;

            var refinedResult = await _queryExecutor.ExecuteQueryAsync(refinedSql, ct);
            if (!refinedResult.IsSuccess)
                break;

            sql = refinedSql;
            current = refinedResult;
        }

        return new RefineResult(sql, current);
    }

    private static List<string> ReadabilityIssues(QueryResult result)
    {
        var issues = new List<string>();
        if (result.IsTruncated) issues.Add("result truncated");
        if (result.Columns.Count > 3) issues.Add($"too many columns ({result.Columns.Count})");
        if (result.TotalRowCount > 12) issues.Add($"too many rows ({result.TotalRowCount})");
        return issues;
    }

    private async Task<string> RefineTSqlAsync(string schemaPrompt, string userQuery, string candidateSql, string issue, CancellationToken ct)
    {
        var prompt =
            "You are a senior T-SQL assistant helping refine a query for readability and correctness.\n\n" +
            "Return ONLY valid JSON with keys:\n" +
            "- sql: a revised single read-only T-SQL query (SQL Server / Azure SQL)\n\n" +
            "Rules:\n" +
            "- Read-only: SELECT or WITH only.\n" +
            "- Make results chart-friendly and readable when possible (2-3 columns, <= 12 rows) using TOP, aggregation, bucketing.\n" +
            "- Always include ORDER BY when returning TOP.\n\n" +
            "DATABASE SCHEMA:\n" +
            schemaPrompt +
            "\n\nUSER REQUEST:\n" +
            userQuery +
            "\n\nCANDIDATE SQL:\n" +
            candidateSql +
            "\n\nISSUE:\n" +
            issue +
            "\n";

        var el = await _jsonLlm.CallJsonAsync(prompt, ct);
        var sql = el.TryGetProperty("sql", out var s) ? (s.GetString() ?? "") : "";
        return sql.Trim();
    }

    private async Task<AgentReportLinks?> TryBuildReportAsync(string userQuery, List<AgentStepResult> steps, CancellationToken ct)
    {
        var artifactsDir = ResolveArtifactsDir();
        Directory.CreateDirectory(artifactsDir);

        var primary = steps.FirstOrDefault(s => s.QueryResult.IsSuccess) ?? steps.FirstOrDefault();
        if (primary is null) return null;

        var qr = primary.QueryResult;
        if (!qr.IsSuccess) return null;

        // Render charts from the primary step for the report (PNG), using the ported renderer.
        var columns = qr.Columns.Select(c => c.Name).ToList();
        var rows = qr.Rows;
        var specs = ChartAnalyzer.InferCharts(columns, rows);
        var chartPngPaths = specs.Count == 0 ? new List<string>() : _pngChartRenderer.RenderChartsPng(columns, rows, specs, artifactsDir, filePrefix: "chart_report");

        var rep = _reportBuilder.BuildPdf(
            outDir: artifactsDir,
            reportTitle: "SqlCopilot Agent Report",
            userQuery: userQuery,
            sql: primary.SqlResponse.GeneratedSql,
            executiveSummary: await SummarizeAsync(userQuery, steps, ct),
            chartPngPaths: chartPngPaths,
            tableColumns: columns,
            tableRows: rows,
            alsoWriteHtml: true);

        var pdfUrl = BuildPublicUrl(rep.PdfPath, artifactsDir);
        var htmlUrl = rep.HtmlPath is null ? null : BuildPublicUrl(rep.HtmlPath, artifactsDir);
        var chartUrls = rep.ChartPngPaths.Select(p => BuildPublicUrl(p, artifactsDir)).ToList();
        return new AgentReportLinks(pdfUrl, htmlUrl, chartUrls);
    }

    private string BuildPublicUrl(string absolutePath, string artifactsDir)
    {
        var fileName = Path.GetFileName(absolutePath);
        var basePath = (_artifactsOptions.PublicBasePath ?? "/artifacts").Trim();
        if (!basePath.StartsWith("/")) basePath = "/" + basePath;
        if (basePath.EndsWith("/")) basePath = basePath.TrimEnd('/');
        // Generate a signed token for secure access
        var token = _artifactTokenService.GenerateToken(fileName);
        var relative = $"{basePath}/{Uri.EscapeDataString(fileName)}?token={Uri.EscapeDataString(token)}";

        var baseUrl = (_artifactsOptions.PublicBaseUrl ?? "").Trim();
        if (baseUrl.Length == 0) return relative;
        return $"{baseUrl.TrimEnd('/')}{relative}";
    }

    private async Task<List<AgentStepPlan>> PlanStepsAsync(string schemaPrompt, string userQuery, CancellationToken ct)
    {
        try
        {
            var prompt = AgentPrompts.BuildPlannerPrompt(schemaPrompt, userQuery, _agentOptions.MaxSteps);

            if (DebugContext.IsEnabled())
            {
                await DebugContext.WriteAsync("sql_agent: planning steps (LLM).");
                await DebugContext.WriteBlockAsync("sql_agent planner prompt (truncated)", LogText.Trunc(prompt, 3500));
            }

            var chatOptions = new ChatCompletionOptions
            {
                Temperature = _agentOptions.PlannerTemperature,
                MaxOutputTokenCount = _agentOptions.PlannerMaxTokens
            };

            var response = await _chatClient.CompleteChatAsync(
                new ChatMessage[]
                {
                    new SystemChatMessage("You are a careful planner. Return JSON only."),
                    new UserChatMessage(prompt)
                },
                chatOptions,
                ct);

            var raw = response.Value.Content[0].Text ?? "";
            raw = StripCodeFences(raw);

            if (DebugContext.IsEnabled())
                await DebugContext.WriteBlockAsync("sql_agent planner JSON (truncated)", LogText.Trunc(raw, 3500));

            using var doc = JsonDocument.Parse(raw);
            if (!doc.RootElement.TryGetProperty("steps", out var stepsEl) || stepsEl.ValueKind != JsonValueKind.Array)
                return new List<AgentStepPlan>();

            var list = new List<AgentStepPlan>();
            foreach (var el in stepsEl.EnumerateArray())
            {
                if (el.ValueKind != JsonValueKind.Object) continue;
                var name = el.TryGetProperty("name", out var n) ? (n.GetString() ?? "") : "";
                var question = el.TryGetProperty("question", out var q) ? (q.GetString() ?? "") : "";
                if (string.IsNullOrWhiteSpace(question)) continue;
                list.Add(new AgentStepPlan(name.Trim(), question.Trim()));
                if (list.Count >= Math.Clamp(_agentOptions.MaxSteps, 1, 3)) break;
            }

            if (DebugContext.IsEnabled())
            {
                var lines = new List<string>();
                for (int i = 0; i < list.Count; i++)
                    lines.Add($"{i + 1}. {(string.IsNullOrWhiteSpace(list[i].Name) ? $"Step {i + 1}" : list[i].Name)} — {list[i].Question}");
                await DebugContext.WriteBlockAsync("sql_agent plan (steps)", string.Join("\n", lines));
            }

            return list;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "Agent planning failed; falling back to single-step execution.");
            return new List<AgentStepPlan>();
        }
    }

    private async Task<string> SummarizeAsync(string userQuery, List<AgentStepResult> steps, CancellationToken ct)
    {
        var evidence = BuildEvidence(steps);

        try
        {
            var prompt = AgentPrompts.BuildSummaryPrompt(userQuery, evidence);

            var chatOptions = new ChatCompletionOptions
            {
                Temperature = _agentOptions.SummaryTemperature,
                MaxOutputTokenCount = _agentOptions.SummaryMaxTokens
            };

            var response = await _chatClient.CompleteChatAsync(
                new ChatMessage[]
                {
                    new SystemChatMessage("Return JSON only."),
                    new UserChatMessage(prompt)
                },
                chatOptions,
                ct);

            var raw = response.Value.Content[0].Text ?? "";
            raw = StripCodeFences(raw);

            using var doc = JsonDocument.Parse(raw);
            var summary = doc.RootElement.TryGetProperty("summary", out var s) ? (s.GetString() ?? "") : "";
            summary = (summary ?? "").Trim();
            if (summary.Length > 0) return summary;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "Agent summary failed; using deterministic fallback.");
        }

        // Deterministic fallback
        var okSteps = steps.Count(s => s.QueryResult.IsSuccess);
        var totalRows = steps.Where(s => s.QueryResult.IsSuccess).Sum(s => s.QueryResult.TotalRowCount);
        return $"- Ran {steps.Count} step(s) ({okSteps} succeeded).\n- Retrieved {totalRows} total row(s) across successful steps.";
    }

    private string BuildEvidence(List<AgentStepResult> steps)
    {
        var maxRows = Math.Clamp(_agentOptions.EvidenceMaxRowsPerStep, 1, 50);
        var blocks = new List<string>();

        foreach (var s in steps)
        {
            var qr = s.QueryResult;
            var sql = (s.SqlResponse.GeneratedSql ?? qr.SqlQuery ?? "").Trim();
            if (sql.Length > 4000) sql = sql[..4000] + "...";

            var header = $"Step {s.Index}: {s.Name}\nQuestion: {s.Question}\nSQL: {sql}\n";
            if (!qr.IsSuccess)
            {
                blocks.Add(header + $"Error: {qr.ErrorMessage}\n");
                continue;
            }

            var cols = qr.Columns.Select(c => c.Name).ToList();
            var rows = qr.Rows.Take(maxRows).ToList();

            var lines = new List<string> { string.Join("\t", cols) };
            foreach (var row in rows)
            {
                lines.Add(string.Join("\t", cols.Select(c => row.TryGetValue(c, out var v) ? (v?.ToString() ?? "") : "")));
            }
            if (qr.TotalRowCount > rows.Count)
                lines.Add($"... ({qr.TotalRowCount - rows.Count} more rows)");

            blocks.Add(header + "Result:\n" + string.Join("\n", lines) + "\n");
        }

        return string.Join("\n---\n", blocks);
    }

    private static string StripCodeFences(string content)
    {
        content = (content ?? "").Trim();
        if (!content.StartsWith("```", StringComparison.Ordinal)) return content;

        var firstNewline = content.IndexOf('\n');
        if (firstNewline < 0) return content.Trim('`').Trim();

        content = content[(firstNewline + 1)..];
        var lastFence = content.LastIndexOf("```", StringComparison.Ordinal);
        if (lastFence >= 0) content = content[..lastFence];
        return content.Trim();
    }
}

