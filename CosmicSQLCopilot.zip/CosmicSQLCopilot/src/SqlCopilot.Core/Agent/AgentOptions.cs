namespace SqlCopilot.Core.Agent;

/// <summary>
/// Configuration for the multi-step SQL agent.
///
/// The agent is optimized for *readable, chart-friendly* outputs in chat:
/// small step count, bounded evidence rows, and conservative temperatures for
/// predictable JSON outputs.
///
/// See also:
/// - Agent runner: `src/SqlCopilot.Core/Agent/AgentOrchestratorService.cs`
/// - Planner prompt: `src/SqlCopilot.Core/Agent/AgentPrompts.cs`
/// - Developer map: `docs/CODE_TOUR.md`
/// </summary>
public sealed class AgentOptions
{
    public const string SectionName = "Agent";

    /// <summary>
    /// Maximum number of investigative steps the planner may produce.
    /// Keeping this small prevents chat spam and keeps the investigation focused.
    /// </summary>
    public int MaxSteps { get; set; } = 3;

    /// <summary>
    /// Maximum number of refinement attempts per step to improve readability and chartability.
    /// Refinement is best-effort and stops early when the output is already clean.
    /// </summary>
    public int MaxRefinements { get; set; } = 2;

    /// <summary>
    /// Hard cap on evidence rows retained per step for summarization and reporting.
    /// This is distinct from the DB execution row limit (see `AzureSqlOptions`).
    /// </summary>
    public int EvidenceMaxRowsPerStep { get; set; } = 12;

    /// <summary>
    /// Temperature used for step planning (lower = more deterministic plans).
    /// </summary>
    public float PlannerTemperature { get; set; } = 0.2f;

    /// <summary>
    /// Max tokens for the planner completion.
    /// </summary>
    public int PlannerMaxTokens { get; set; } = 1200;

    /// <summary>
    /// Temperature used for evidence summarization (lower = fewer creative leaps).
    /// </summary>
    public float SummaryTemperature { get; set; } = 0.2f;

    /// <summary>
    /// Max tokens for the summary completion.
    /// </summary>
    public int SummaryMaxTokens { get; set; } = 800;
}

