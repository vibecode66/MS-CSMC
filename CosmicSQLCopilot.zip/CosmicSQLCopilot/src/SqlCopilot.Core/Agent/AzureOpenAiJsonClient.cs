// ============================================================================
// AzureOpenAiJsonClient.cs — Minimal JSON-only LLM wrapper
//
// Several parts of the system want *deterministic JSON outputs* rather than free-form
// text (router decisions, agent planning/summaries, case prediction decisioning).
//
// This client provides a tiny abstraction:
// - Always injects a "JSON only" system message
// - Strips common markdown code fences (models sometimes wrap JSON in ``` blocks)
// - Throws when JSON parsing fails, so callers can decide whether to retry/fallback
//
// This is intentionally separate from `SqlGeneratorService`:
// - `SqlGeneratorService` owns the NL→SQL system prompt and response schema
// - `AzureOpenAiJsonClient` is a generic "return JSON" utility used across features
//
// See also:
// - Interface: `Agent/IJsonLlmClient.cs`
// - Router + prediction prompts: `Services/ConversationOrchestratorService.cs`, `Services/CasePredictionAgent.cs`
// - Agent planning prompts: `Agent/AgentPrompts.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using System.ClientModel;
using System.Diagnostics;
using System.Text.Json;
using Azure.AI.OpenAI;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using OpenAI.Chat;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Services;

namespace SqlCopilot.Core.Agent;

/// <summary>
/// Azure OpenAI chat wrapper that returns parsed JSON.
/// </summary>
public sealed class AzureOpenAiJsonClient : IJsonLlmClient
{
    private readonly ChatClient _chatClient;
    private readonly ILogger<AzureOpenAiJsonClient> _logger;

    public AzureOpenAiJsonClient(IOptions<AzureOpenAIOptions> options, ILogger<AzureOpenAiJsonClient> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        var o = (options ?? throw new ArgumentNullException(nameof(options))).Value;

        var client = new AzureOpenAIClient(new Uri(o.Endpoint), new ApiKeyCredential(o.ApiKey));
        _chatClient = client.GetChatClient(o.DeploymentName);
    }

    public async Task<JsonElement> CallJsonAsync(string prompt, CancellationToken cancellationToken = default)
    {
        prompt ??= "";
        var sw = Stopwatch.StartNew();
        _logger.LogInformation(
            "LLM_JSON_CALL_START promptChars={PromptChars} promptPreview=\"{PromptPreview}\"",
            prompt.Length,
            LogText.OneLine(prompt, 280));
        _logger.LogDebug("LLM_JSON_CALL_PROMPT (truncated) {Prompt}", LogText.Trunc(prompt, 6000));

        var response = await _chatClient.CompleteChatAsync(
            new ChatMessage[]
            {
                new SystemChatMessage("Return JSON only. No markdown. No code fences."),
                new UserChatMessage(prompt)
            },
            // Deterministic JSON decisions reduce "random" routing/supervision behavior.
            new ChatCompletionOptions { Temperature = 0.0f, MaxOutputTokenCount = 1400 },
            cancellationToken);

        var raw = response.Value.Content[0].Text ?? "";
        raw = StripCodeFences(raw);
        sw.Stop();
        _logger.LogInformation(
            "LLM_JSON_CALL_DONE elapsedMs={ElapsedMs} responseChars={ResponseChars} responsePreview=\"{Preview}\"",
            sw.ElapsedMilliseconds,
            raw.Length,
            LogText.OneLine(raw, 280));
        _logger.LogDebug("LLM_JSON_CALL_RAW (truncated) {Raw}", LogText.Trunc(raw, 6000));

        try
        {
            using var doc = JsonDocument.Parse(raw);
            return doc.RootElement.Clone();
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex, "Failed to parse JSON from model output. First 400 chars: {Text}",
                raw.Length > 400 ? raw[..400] : raw);
            throw;
        }
    }

    private static string StripCodeFences(string content)
    {
        content = (content ?? "").Trim();
        if (!content.StartsWith("```", StringComparison.Ordinal)) return content;

        var firstNewline = content.IndexOf('\n');
        if (firstNewline < 0) return content.Trim('`').Trim();

        content = content[(firstNewline + 1)..];
        var lastFence = content.LastIndexOf("```", StringComparison.Ordinal);
        if (lastFence >= 0) content = content[..lastFence];
        return content.Trim();
    }
}

