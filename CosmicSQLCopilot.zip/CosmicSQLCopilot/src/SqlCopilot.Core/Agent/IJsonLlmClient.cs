using System.Text.Json;

namespace SqlCopilot.Core.Agent;

/// <summary>
/// Minimal abstraction for calling an LLM and receiving structured JSON.
///
/// This is used for non-NL→SQL prompts where deterministic parsing is important:
/// routing decisions, agent planning, agent summaries, and prediction decisioning.
///
/// See implementation: `Agent/AzureOpenAiJsonClient.cs`.
/// </summary>
public interface IJsonLlmClient
{
    Task<JsonElement> CallJsonAsync(string prompt, CancellationToken cancellationToken = default);
}

