// ============================================================================
// AgentPrompts.cs — Prompt text for agent planning and summarization
//
// Unlike `Services/SqlGeneratorService.cs` (which contains the NL→SQL system prompt),
// this file contains prompts that help the agent:
// - Plan a small number of chart-friendly investigative steps (plain English sub-questions)
// - Summarize collected evidence into a concise executive summary (bullets)
//
// The agent uses a JSON-only contract so downstream parsing is deterministic.
//
// See also:
// - Agent runner: `Agent/AgentOrchestratorService.cs`
// - NL→SQL prompt (separate responsibility): `Services/SqlGeneratorService.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

namespace SqlCopilot.Core.Agent;

internal static class AgentPrompts
{
    public static string BuildPlannerPrompt(string schemaPrompt, string userQuery, int maxSteps)
    {
        maxSteps = Math.Clamp(maxSteps, 1, 3);

        return
            "You are a data investigation planner for a Text-to-SQL assistant.\n" +
            "Given the user's request and the database schema, produce a JSON object with:\n" +
            $"- \"steps\": a list of 1-{maxSteps} investigation steps.\n\n" +
            "Each step must be an object with:\n" +
            "- \"name\": short label (e.g., \"Trend over time\")\n" +
            "- \"question\": a concrete sub-question phrased in plain English that can be answered with a single read-only SQL Server SELECT.\n" +
            "- \"tables\": list of table names you expect to use (from the schema)\n" +
            "- \"joins\": list of join relationships you expect (e.g., \"dbo.eh_incident.incidentid = dbo.eh_msdyn_caseaction.msdyn_case\")\n" +
            "- \"notes\": brief notes about filters/denominators/edge-cases (optional)\n\n" +
            "Hard constraints for EVERY step:\n" +
            "- Steps must be chart-friendly and readable.\n" +
            "- Prefer 2 columns (category/time + metric) and <= 12 rows for breakdowns.\n" +
            "- Prefer time bucketing by week or month for trends.\n" +
            "- Avoid high-cardinality groupings.\n\n" +
            "Output rules:\n" +
            "- Return ONLY valid JSON (no markdown, no code fences).\n" +
            "- Do not include SQL.\n\n" +
            "DATABASE SCHEMA:\n" +
            schemaPrompt +
            "\n\nUSER REQUEST:\n" +
            userQuery;
    }

    public static string BuildSummaryPrompt(string userQuery, string evidence)
    {
        return
            "You are a data analyst writing a concise executive summary for an investigation.\n\n" +
            "Return a JSON object:\n" +
            "- \"summary\": 3-6 bullets (as a single string with newlines, each bullet starting with \"- \")\n\n" +
            "Be specific (numbers, categories, time windows) and avoid generic statements.\n" +
            "If evidence is insufficient, say what is missing and what to check next.\n\n" +
            "USER REQUEST:\n" +
            userQuery +
            "\n\nEVIDENCE:\n" +
            evidence +
            "\n\nReturn ONLY valid JSON (no markdown, no code fences).";
    }
}

