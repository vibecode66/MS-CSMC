using SqlCopilot.Core.Models;

namespace SqlCopilot.Core.Agent;

/// <summary>
/// Shared contracts used by the multi-step agent pipeline.
///
/// These record types are intentionally simple and serializable:
/// - They flow between the agent runner (`AgentOrchestratorService`) and the conversation
///   layer (`ConversationOrchestratorService`) which decides what to show in chat.
/// - They are also used when building report artifacts (PDF/HTML + chart images).
///
/// See also:
/// - Agent runner: `src/SqlCopilot.Core/Agent/AgentOrchestratorService.cs`
/// - Conversation routing: `src/SqlCopilot.Core/Services/ConversationOrchestratorService.cs`
/// - Developer map: `docs/CODE_TOUR.md`
/// </summary>
public sealed record AgentStepPlan(
    string Name,
    string Question
);

/// <summary>
/// Execution result for a single agent step.
///
/// <paramref name="SqlResponse"/> contains the generated SQL plus explanation and chart hint.
/// <paramref name="QueryResult"/> contains the executed rows/columns (or error).
/// <paramref name="ChartUrl"/> is an optional QuickChart URL used by the chat card renderer.
/// </summary>
public sealed record AgentStepResult(
    int Index,
    string Name,
    string Question,
    NL2SqlResponse SqlResponse,
    QueryResult QueryResult,
    string? ChartUrl
);

/// <summary>
/// Public links for downloadable report artifacts produced by the agent.
/// These are typically served via the web host static files middleware.
///
/// See: `src/SqlCopilot.Web/Program.cs` and `src/SqlCopilot.Core/AgentPort/Reports/ReportBuilder.cs`.
/// </summary>
public sealed record AgentReportLinks(
    string? PdfUrl,
    string? HtmlUrl,
    IReadOnlyList<string> ChartImageUrls
);

/// <summary>
/// Response payload for schema inspection requests in agent mode.
/// </summary>
public sealed record AgentSchemaInfo(
    string Source,
    string SchemaUrl,
    string Preview
);

/// <summary>
/// Top-level agent run result: step outputs + summary + optional report links.
/// </summary>
public sealed record AgentRunResult(
    string Mode,
    string UserQuery,
    IReadOnlyList<AgentStepResult> Steps,
    string Summary,
    AgentReportLinks? Report = null,
    object? Payload = null
);

