// ============================================================================
// SlaPredictionAccessHandler.cs — Authorization handler for SLA prediction
//
// Allows all authenticated users to access SLA prediction.
// ============================================================================

using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Web.Security;

/// <summary>
/// Authorization requirement marker for SLA prediction access.
/// </summary>
public class SlaPredictionAccessRequirement : IAuthorizationRequirement { }

/// <summary>
/// Allows all authenticated users to access SLA prediction.
/// </summary>
public class SlaPredictionAccessHandler : AuthorizationHandler<SlaPredictionAccessRequirement>
{
    public SlaPredictionAccessHandler(IOptions<SlaPredictionAccessOptions> options)
    {
    }

    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        SlaPredictionAccessRequirement requirement)
    {
        if (context.User.Identity?.IsAuthenticated ?? false)
        {
            context.Succeed(requirement);
        }

        return Task.CompletedTask;
    }
}
