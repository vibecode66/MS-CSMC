// ============================================================================
// ArtifactTokenService.cs — Signed short-lived token for artifact downloads
//
// Generates and validates HMAC-signed tokens so that artifact URLs shared in
// Teams adaptive cards can be accessed without bearer auth (browser click-through)
// while remaining time-limited and tamper-proof.
// ============================================================================

using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.WebUtilities;
using SqlCopilot.Core.Interfaces;

namespace SqlCopilot.Web.Security;

/// <summary>
/// Service interface kept in Web layer for DI registration convenience.
/// The canonical interface is <see cref="IArtifactTokenService"/> in Core.
/// </summary>

/// <summary>
/// HMAC-SHA256 signed token service. Tokens encode filename + expiry and are
/// verified server-side. Default expiry is 24 hours.
/// </summary>
public class ArtifactTokenService : IArtifactTokenService
{
    private static readonly TimeSpan DefaultExpiry = TimeSpan.FromHours(24);
    private readonly byte[] _key;

    public ArtifactTokenService(IConfiguration configuration)
    {
        var secret = configuration.GetValue<string>("ArtifactTokenSecret") ?? string.Empty;
        if (string.IsNullOrWhiteSpace(secret))
        {
            throw new InvalidOperationException(
                "ArtifactTokenSecret is not configured. " +
                "Set it in App Service Configuration or appsettings.json to enable secure artifact token signing.");
        }
        _key = SHA256.HashData(Encoding.UTF8.GetBytes(secret));
    }

    public string GenerateToken(string filename, TimeSpan? expiry = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filename);

        var expiresAt = DateTimeOffset.UtcNow.Add(expiry ?? DefaultExpiry).ToUnixTimeSeconds();
        // Base64Url-encode the filename to avoid delimiter collisions
        var encodedFilename = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(filename));
        var payload = $"{encodedFilename}|{expiresAt}";
        var signature = ComputeSignature(payload);
        var token = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes($"{payload}|{signature}"));
        return token;
    }

    public string? ValidateToken(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        try
        {
            var decoded = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(token));
            var parts = decoded.Split('|');
            if (parts.Length != 3)
                return null;

            var encodedFilename = parts[0];
            if (!long.TryParse(parts[1], out var expiresAt))
                return null;

            var signature = parts[2];

            // Check expiry
            if (DateTimeOffset.UtcNow.ToUnixTimeSeconds() > expiresAt)
                return null;

            // Verify signature over the encoded payload (same as generation)
            var payload = $"{encodedFilename}|{expiresAt}";
            var expectedSignature = ComputeSignature(payload);

            if (!CryptographicOperations.FixedTimeEquals(
                Encoding.UTF8.GetBytes(signature),
                Encoding.UTF8.GetBytes(expectedSignature)))
                return null;

            // Decode the filename after signature verification
            var filenameBytes = WebEncoders.Base64UrlDecode(encodedFilename);
            return Encoding.UTF8.GetString(filenameBytes);
        }
        catch
        {
            return null;
        }
    }

    private string ComputeSignature(string payload)
    {
        using var hmac = new HMACSHA256(_key);
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
}
