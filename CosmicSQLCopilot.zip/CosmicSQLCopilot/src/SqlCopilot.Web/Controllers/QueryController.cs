// ============================================================================
// QueryController.cs — REST API endpoint for M365 Copilot plugin
//
// Purpose:
//   Provides a REST API that the M365 Copilot declarative agent calls via
//   the OpenAPI plugin specification. Accepts natural language queries,
//   generates SQL, executes it, and returns structured JSON results.
//
// Route: POST /api/query
//
// Request body: { "query": "natural language question" }
// Response: JSON with success status, explanation, SQL, columns, rows, timing
//
// This endpoint is separate from the Bot Framework /api/messages endpoint.
// The bot handles Teams chat; this API handles the Copilot plugin flow.
// ============================================================================

using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Tracing;

namespace SqlCopilot.Web.Controllers;

/// <summary>
/// REST API endpoint for the M365 Copilot declarative agent plugin.
/// Accepts natural language queries and returns structured query results.
/// </summary>
[Route("api/query")]
[ApiController]
[Microsoft.AspNetCore.Authorization.Authorize(Policy = "QueryApiAccess")]
public class QueryController : ControllerBase
{
    private readonly ISchemaDiscoveryService _schemaService;
    private readonly ISqlGeneratorService _sqlGenerator;
    private readonly IQueryExecutionService _queryExecutor;
    private readonly IConversationTraceSink _trace;
    private readonly ILogger<QueryController> _logger;

    /// <summary>
    /// Initializes the query controller with required services.
    /// </summary>
    /// <param name="schemaService">Service for database schema discovery.</param>
    /// <param name="sqlGenerator">Service for NL→SQL conversion.</param>
    /// <param name="queryExecutor">Service for SQL query execution.</param>
    /// <param name="logger">Logger for request diagnostics.</param>
    public QueryController(
        ISchemaDiscoveryService schemaService,
        ISqlGeneratorService sqlGenerator,
        IQueryExecutionService queryExecutor,
        IConversationTraceSink trace,
        ILogger<QueryController> logger)
    {
        _schemaService = schemaService ?? throw new ArgumentNullException(nameof(schemaService));
        _sqlGenerator = sqlGenerator ?? throw new ArgumentNullException(nameof(sqlGenerator));
        _queryExecutor = queryExecutor ?? throw new ArgumentNullException(nameof(queryExecutor));
        _trace = trace ?? throw new ArgumentNullException(nameof(trace));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Processes a natural language query: generates SQL, executes it,
    /// and returns the structured results.
    /// </summary>
    /// <param name="request">The query request containing the natural language question.</param>
    /// <param name="cancellationToken">Cancellation token for async operations.</param>
    /// <returns>
    /// JSON response with: success flag, explanation, generated SQL,
    /// column definitions, row data, total row count, execution time,
    /// and truncation status.
    /// </returns>
    [HttpPost]
    [Microsoft.AspNetCore.Mvc.RequestSizeLimit(65_536)] // 64 KB max request body
    public async Task<IActionResult> QueryAsync(
        [FromBody] QueryRequest request,
        CancellationToken cancellationToken)
    {
        var requestStopwatch = Stopwatch.StartNew();
        var traceStarted = false;
        string? finalAnswer = null;

        // ---- Validate input ----
        if (string.IsNullOrWhiteSpace(request.Query))
        {
            _logger.LogWarning("Empty query received at /api/query");
            return BadRequest(new { error = "Query is required." });
        }

        if (_trace.IsEnabled)
        {
            var turnId = DateTimeOffset.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "-" + Guid.NewGuid().ToString("N")[..6];
            _trace.StartTurn("api", HttpContext.TraceIdentifier, turnId, request.Query);
            traceStarted = true;
        }

        _logger.LogInformation(
            "API query received (length={QueryLength})",
            request.Query.Length);

        try
        {
            // Step 1: Get the database schema (cached)
            _logger.LogDebug("Step 1: Retrieving database schema...");
            var schema = await _schemaService.GetSchemaAsync(cancellationToken);

            if (schema.Tables.Count == 0)
            {
                _logger.LogWarning("No tables found in the database");
                finalAnswer = "No tables found in the database. Check connection and permissions.";
                return Ok(new
                {
                    success = false,
                    error = "No tables found in the database. Check connection and permissions."
                });
            }

            // Step 2: Generate SQL from natural language
            _logger.LogDebug("Step 2: Generating SQL...");
            var sqlResponse = await _sqlGenerator.GenerateSqlAsync(
                request.Query, schema, cancellationToken);

            if (!sqlResponse.IsSuccess)
            {
                _logger.LogWarning(
                    "SQL generation failed: {Error}", sqlResponse.ErrorMessage);
                finalAnswer = (sqlResponse.ErrorMessage ?? sqlResponse.Explanation ?? "").Trim();
                return Ok(new
                {
                    success = false,
                    error = sqlResponse.ErrorMessage,
                    explanation = sqlResponse.Explanation
                });
            }

            // Step 3: Execute the generated query
            _logger.LogDebug("Step 3: Executing SQL: {Sql}", sqlResponse.GeneratedSql);
            var result = await _queryExecutor.ExecuteQueryAsync(
                sqlResponse.GeneratedSql, cancellationToken);

            requestStopwatch.Stop();

            _logger.LogInformation(
                "API query completed in {TotalMs}ms — Success: {Success}, " +
                "Rows: {Rows}, SqlGenTime + ExecTime: {ExecMs}ms",
                requestStopwatch.ElapsedMilliseconds,
                result.IsSuccess, result.TotalRowCount,
                result.ExecutionTime.TotalMilliseconds);

            // Step 4: Return structured result
            var payload = new
            {
                success = result.IsSuccess,
                explanation = sqlResponse.Explanation,
                sql = sqlResponse.GeneratedSql,
                columns = result.Columns.Select(c => new { c.Name, c.DataType }),
                rows = result.Rows,
                totalRows = result.TotalRowCount,
                executionTimeMs = result.ExecutionTime.TotalMilliseconds,
                isTruncated = result.IsTruncated,
                error = result.ErrorMessage
            };

            finalAnswer = result.IsSuccess
                ? (sqlResponse.Explanation ?? "").Trim()
                : (result.ErrorMessage ?? "").Trim();

            return Ok(payload);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning(
                "API query cancelled after {ElapsedMs}ms",
                requestStopwatch.ElapsedMilliseconds);
            finalAnswer = "Request was cancelled.";
            return StatusCode(499, new { error = "Request was cancelled." });
        }
        catch (Exception ex)
        {
            requestStopwatch.Stop();
            _logger.LogError(ex,
                "Unhandled error processing API query after {ElapsedMs}ms",
                requestStopwatch.ElapsedMilliseconds);

            finalAnswer = "An internal error occurred while processing your query.";
            return StatusCode(500, new
            {
                error = "An internal error occurred while processing your query."
            });
        }
        finally
        {
            if (traceStarted)
                await _trace.EndTurnAsync(finalAnswer, cancellationToken: cancellationToken);
        }
    }
}

/// <summary>
/// Request model for the /api/query endpoint.
/// Contains the user's natural language question.
/// </summary>
public class QueryRequest
{
    /// <summary>
    /// The natural language question to convert to SQL and execute.
    /// Example: "How many cases were created this month?"
    /// </summary>
    [System.ComponentModel.DataAnnotations.Required]
    [System.ComponentModel.DataAnnotations.StringLength(2000, MinimumLength = 1)]
    public string Query { get; set; } = string.Empty;
}
