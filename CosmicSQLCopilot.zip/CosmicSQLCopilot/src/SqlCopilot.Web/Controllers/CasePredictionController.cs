// ============================================================================
// CasePredictionController.cs — REST endpoint for SLA prediction calls
//
// This controller is a thin HTTP wrapper around `ICasePredictionClient`.
// It validates the request payload shape (record count, required TicketNumber)
// and translates upstream failures into appropriate HTTP status codes.
//
// See also:
// - Prediction client: `src/SqlCopilot.Core/Services/CasePredictionClient.cs`
// - Decisioning + orchestration in chat: `src/SqlCopilot.Core/Services/ConversationOrchestratorService.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using Microsoft.AspNetCore.Mvc;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;

namespace SqlCopilot.Web.Controllers;

[Route("api/case-prediction")]
[ApiController]
[Microsoft.AspNetCore.Authorization.Authorize(Policy = "SlaPredictionAccess")]
public sealed class CasePredictionController : ControllerBase
{
    private readonly ICasePredictionClient _client;
    private readonly ILogger<CasePredictionController> _logger;

    public CasePredictionController(
        ICasePredictionClient client,
        ILogger<CasePredictionController> logger)
    {
        _client = client ?? throw new ArgumentNullException(nameof(client));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    [HttpPost]
    public async Task<IActionResult> PredictAsync(
        [FromBody] CasePredictionInvokeRequest request,
        CancellationToken cancellationToken)
    {
        if (request?.Records is null || request.Records.Count == 0)
            return BadRequest(new { error = "At least one record is required." });

        if (request.Records.Count > 500)
            return BadRequest(new { error = "Too many records. Max is 500 per request." });

        if (request.Records.Any(r => string.IsNullOrWhiteSpace(r.TicketNumber)))
            return BadRequest(new { error = "All records must include a non-empty TicketNumber." });

        try
        {
            var response = await _client.PredictAsync(request, cancellationToken);
            return Ok(response);
        }
        catch (OperationCanceledException)
        {
            return StatusCode(499, new { error = "Request was cancelled." });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogWarning(ex, "Upstream case prediction call failed");
            return StatusCode(502, new { error = "Upstream prediction service failed." });
        }
        catch (InvalidOperationException ex)
        {
            _logger.LogError(ex, "Case prediction is misconfigured");
            return StatusCode(500, new { error = "Case prediction is not configured correctly." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled error during case prediction");
            return StatusCode(500, new { error = "An internal error occurred." });
        }
    }
}

