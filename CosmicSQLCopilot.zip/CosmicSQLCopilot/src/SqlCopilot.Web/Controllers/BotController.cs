// ============================================================================
// BotController.cs — Bot Framework HTTP endpoint
//
// Purpose:
//   Receives incoming HTTP POST requests from the Bot Framework Service
//   (Azure Bot) and routes them to the bot's activity handler.
//   This is the entry point for all Teams/M365 Copilot messages.
//
// Route: POST /api/messages
//
// The controller is minimal by design — all business logic lives in the
// SqlCopilotBot class. Authentication is handled by the Bot Framework SDK.
// ============================================================================

using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;

namespace SqlCopilot.Web.Controllers;

/// <summary>
/// Bot Framework endpoint controller.
/// Receives incoming activities from the Bot Framework Service and routes
/// them to the registered <see cref="IBot"/> implementation.
/// </summary>
[Route("api/messages")]
[ApiController]
[Microsoft.AspNetCore.Authorization.AllowAnonymous] // Bot Framework SDK handles its own auth via the adapter
public class BotController : ControllerBase
{
    private readonly IBotFrameworkHttpAdapter _adapter;
    private readonly IBot _bot;
    private readonly ILogger<BotController> _logger;

    /// <summary>
    /// Initializes the controller with the Bot Framework adapter and bot instance.
    /// </summary>
    /// <param name="adapter">The Bot Framework HTTP adapter for processing activities.</param>
    /// <param name="bot">The bot implementation that handles incoming activities.</param>
    /// <param name="logger">Logger for request diagnostics.</param>
    public BotController(
        IBotFrameworkHttpAdapter adapter,
        IBot bot,
        ILogger<BotController> logger)
    {
        _adapter = adapter ?? throw new ArgumentNullException(nameof(adapter));
        _bot = bot ?? throw new ArgumentNullException(nameof(bot));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Processes incoming Bot Framework activities (messages, events, etc.).
    /// The Bot Framework SDK handles authentication, deserialization, and
    /// routing to the appropriate handler method on the bot.
    /// </summary>
    [HttpPost]
    public async Task PostAsync()
    {
        _logger.LogDebug("Incoming Bot Framework activity received at /api/messages");

        try
        {
            await _adapter.ProcessAsync(Request, Response, _bot);
        }
        catch (Exception ex)
        {
            // This should rarely fire — the adapter has its own error handling.
            // But log it in case the adapter itself throws (e.g., auth failure).
            _logger.LogError(ex,
                "Error processing Bot Framework activity: {Error}", ex.Message);
            throw; // Let ASP.NET Core handle the HTTP response
        }
    }
}
