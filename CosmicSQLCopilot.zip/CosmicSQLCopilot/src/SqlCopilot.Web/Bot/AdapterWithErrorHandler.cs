// ============================================================================
// AdapterWithErrorHandler.cs — Bot Framework adapter with global error handling
//
// Purpose:
//   Extends the CloudAdapter to provide a global error handler for the bot.
//   When any unhandled exception escapes the bot's message handler, this
//   adapter catches it, logs the full error, sends a friendly message to
//   the user, and emits a trace activity for debugging in Bot Framework tools.
//
// This is the last line of defense — individual handlers should catch their
// own errors, but this ensures the bot never silently fails.
// ============================================================================

using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Builder.TraceExtensions;
using Microsoft.Bot.Connector.Authentication;

namespace SqlCopilot.Web.Bot;

/// <summary>
/// Bot adapter with global error handling.
/// Logs errors and sends a friendly message to the user when an unhandled
/// exception occurs during turn processing.
/// </summary>
public class AdapterWithErrorHandler : CloudAdapter
{
    /// <summary>
    /// Initializes the adapter and configures the global error handler.
    /// </summary>
    /// <param name="auth">Bot Framework authentication configuration.</param>
    /// <param name="logger">Logger for error diagnostics.</param>
    public AdapterWithErrorHandler(
        BotFrameworkAuthentication auth,
        ILogger<AdapterWithErrorHandler> logger)
        : base(auth, logger)
    {
        // This handler fires when any unhandled exception escapes the bot's turn handler.
        // It's the global safety net that ensures the user always gets a response.
        OnTurnError = async (turnContext, exception) =>
        {
            // Log the full exception with stack trace for troubleshooting
            logger.LogError(exception,
                "[OnTurnError] Unhandled error in bot turn. " +
                "ConversationId: {ConversationId}, ActivityType: {ActivityType}, " +
                "Error: {ErrorMessage}",
                turnContext.Activity?.Conversation?.Id ?? "unknown",
                turnContext.Activity?.Type ?? "unknown",
                exception.Message);

            // Send a friendly error message to the user
            try
            {
                await turnContext.SendActivityAsync(
                    "\u26a0\ufe0f Sorry, something went wrong processing your request. Please try again.");
            }
            catch (Exception sendEx)
            {
                // If even sending the error message fails, log it but don't rethrow
                logger.LogCritical(sendEx,
                    "[OnTurnError] Failed to send error message to user: {Error}",
                    sendEx.Message);
            }

            // Emit a trace activity visible in Bot Framework Emulator for debugging
            try
            {
                await turnContext.TraceActivityAsync(
                    "OnTurnError Trace",
                    exception.Message,
                    "https://www.botframework.com/schemas/error",
                    "TurnError");
            }
            catch (Exception traceEx)
            {
                logger.LogWarning(traceEx,
                    "[OnTurnError] Failed to send trace activity: {Error}",
                    traceEx.Message);
            }
        };
    }
}
