// ============================================================================
// SqlCopilotBot.cs — Teams ActivityHandler bridge to Core orchestration
//
// This bot class is intentionally thin:
// - It performs *channel-specific* UX tasks (typing indicator, mention stripping)
// - It passes the cleaned user text to the Core orchestrator, which owns routing,
//   tool execution, and response formatting
//
// This separation keeps the chat surface simple and makes it easy to reuse the
// same logic from other entrypoints (e.g., the REST API controller).
//
// See also:
// - Orchestrator: `src/SqlCopilot.Core/Services/ConversationOrchestratorService.cs`
// - Bot HTTP endpoint: `src/SqlCopilot.Web/Controllers/BotController.cs`
// - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Teams;
using Microsoft.Bot.Schema;
using Microsoft.Bot.Schema.Teams;
using System.Text.Json;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Tracing;

namespace SqlCopilot.Web.Bot;

/// <summary>
/// Thin Teams bot wrapper. All routing + planning + tool execution lives in Core
/// (<see cref="IConversationOrchestratorService"/>).
/// </summary>
public sealed class SqlCopilotBot : TeamsActivityHandler
{
    private readonly IConversationOrchestratorService _orchestrator;
    private readonly IConversationTraceSink _trace;
    private readonly ILogger<SqlCopilotBot> _logger;

    public SqlCopilotBot(
        IConversationOrchestratorService orchestrator,
        IConversationTraceSink trace,
        ILogger<SqlCopilotBot> logger)
    {
        _orchestrator = orchestrator ?? throw new ArgumentNullException(nameof(orchestrator));
        _trace = trace ?? throw new ArgumentNullException(nameof(trace));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    protected override async Task OnMessageActivityAsync(
        ITurnContext<IMessageActivity> turnContext,
        CancellationToken cancellationToken)
    {
        var turnId = DateTimeOffset.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "-" + Guid.NewGuid().ToString("N")[..6];
        var userText = (turnContext.Activity.Text ?? "").Trim();
        userText = turnContext.Activity.RemoveRecipientMention()?.Trim() ?? userText;

        await turnContext.SendActivityAsync(new Activity { Type = ActivityTypes.Typing }, cancellationToken);

        // Diagnostic command: show user identity values that matter for allowlists.
        if (userText.Equals("/whoami", StringComparison.OrdinalIgnoreCase) ||
            userText.Equals("whoami", StringComparison.OrdinalIgnoreCase))
        {
            var aadObjectId = (turnContext.Activity.From?.AadObjectId ?? "").Trim();
            var fromId = (turnContext.Activity.From?.Id ?? "").Trim();

            string tenantId = "";
            try
            {
                var channelData = turnContext.Activity.GetChannelData<TeamsChannelData>();
                tenantId = (channelData?.Tenant?.Id ?? "").Trim();
            }
            catch
            {
                tenantId = "";
            }

            var text =
                "Here are the identity fields I see for your message:\n" +
                $"- aadObjectId: {(aadObjectId.Length == 0 ? "<empty>" : aadObjectId)}\n" +
                $"- from.id: {(fromId.Length == 0 ? "<empty>" : fromId)}\n" +
                $"- tenantId: {(tenantId.Length == 0 ? "<empty>" : tenantId)}\n\n" +
                "Use `aadObjectId` for allowlists when available.";

            await turnContext.SendActivityAsync(MessageFactory.Text(text), cancellationToken);
            return;
        }

        _logger.LogInformation("Teams message: {Text}",
            userText.Length > 200 ? userText[..200] + "..." : userText);

        _trace.StartTurn("teams", turnContext.Activity.Conversation?.Id, turnId: turnId, userText: userText);

        await turnContext.SendActivityAsync(
            MessageFactory.Text("Got it - I'm working on your request. This can take a bit for larger queries."),
            cancellationToken);

        var conversationId = turnContext.Activity.Conversation?.Id;
        var userAadObjectId = (turnContext.Activity.From?.AadObjectId ?? "").Trim();
        var channelId = (turnContext.Activity.ChannelId ?? "").Trim().ToLowerInvariant();
        var supportsAdaptiveCards = channelId == "msteams";
        using var typingCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        var typingTask = SendTypingLoopAsync(turnContext, typingCts.Token);

        var finalText = "";
        var result = new ConversationTurnResult(Array.Empty<BotReply>());
        try
        {
            result = await _orchestrator.HandleAsync(
                userText,
                conversationId,
                cancellationToken,
                progress: async msg =>
                {
                    msg = (msg ?? "").Trim();
                    if (msg.Length == 0) return;
                    try
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Text(msg), cancellationToken);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to send progress activity: {Error}", ex.Message);
                    }
                },
                userAadObjectId: userAadObjectId);

            // Record final user-visible text (best-effort).
            finalText = string.Join("\n", result.Replies.Select(r => (r.Text ?? "").Trim()).Where(t => t.Length > 0));
        }
        finally
        {
            try
            {
                await _trace.EndTurnAsync(finalText, cancellationToken: cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to finalize trace turn: {Error}", ex.Message);
            }

            await typingCts.CancelAsync();
            await typingTask;
        }

        foreach (var reply in result.Replies)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(reply.Text))
                    await turnContext.SendActivityAsync(MessageFactory.Text(reply.Text), cancellationToken);
                if (reply.Attachment is not null)
                {
                    if (supportsAdaptiveCards)
                    {
                        await turnContext.SendActivityAsync(MessageFactory.Attachment(reply.Attachment), cancellationToken);
                    }
                    else
                    {
                        // Some channels (e.g. Skype) do not render Adaptive Cards and show "cards.unsupported".
                        // In those cases, send a best-effort plain text fallback instead of the attachment.
                        var fallback = TryExtractTextFromAdaptiveCard(reply.Attachment);
                        if (string.IsNullOrWhiteSpace(fallback))
                        {
                            fallback =
                                "I generated a rich result card, but this chat client doesn't support it. " +
                                "Please open this conversation in Microsoft Teams (desktop/web) to view the card.";
                        }
                        await turnContext.SendActivityAsync(MessageFactory.Text(fallback), cancellationToken);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to send bot reply activity: {Error}", ex.Message);
            }
        }
    }

    private static string? TryExtractTextFromAdaptiveCard(Attachment attachment)
    {
        if (attachment is null) return null;
        if (!string.Equals(attachment.ContentType, "application/vnd.microsoft.card.adaptive", StringComparison.OrdinalIgnoreCase))
            return null;
        if (attachment.Content is null) return null;

        try
        {
            // Attachment.Content is an untyped object; serialize and traverse for any useful "text" fields.
            var json = JsonSerializer.Serialize(attachment.Content);
            using var doc = JsonDocument.Parse(json);
            var lines = new List<string>();
            CollectTextLines(doc.RootElement, lines);

            // De-dupe, keep order, and keep message bounded.
            var unique = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var l in lines)
            {
                var s = (l ?? "").Trim();
                if (s.Length == 0) continue;
                if (seen.Add(s)) unique.Add(s);
                if (unique.Count >= 40) break;
            }

            var joined = string.Join("\n", unique);
            joined = joined.Trim();
            if (joined.Length == 0) return null;
            if (joined.Length > 3500) joined = joined[..3500] + "…";
            return joined;
        }
        catch
        {
            return null;
        }
    }

    private static void CollectTextLines(JsonElement el, List<string> outLines)
    {
        switch (el.ValueKind)
        {
            case JsonValueKind.Object:
            {
                // Special-case: "facts" arrays are common in Adaptive Cards.
                if (el.TryGetProperty("facts", out var facts) && facts.ValueKind == JsonValueKind.Array)
                {
                    foreach (var f in facts.EnumerateArray())
                    {
                        if (f.ValueKind != JsonValueKind.Object) continue;
                        var title = f.TryGetProperty("title", out var t) && t.ValueKind == JsonValueKind.String ? (t.GetString() ?? "") : "";
                        var value = f.TryGetProperty("value", out var v) && v.ValueKind == JsonValueKind.String ? (v.GetString() ?? "") : "";
                        title = title.Trim().TrimEnd(':');
                        value = value.Trim();
                        if (title.Length > 0 && value.Length > 0) outLines.Add($"{title}: {value}");
                        else if (value.Length > 0) outLines.Add(value);
                    }
                }

                foreach (var p in el.EnumerateObject())
                {
                    if ((p.NameEquals("text") || p.NameEquals("title")) && p.Value.ValueKind == JsonValueKind.String)
                    {
                        var s = (p.Value.GetString() ?? "").Trim();
                        if (s.Length > 0) outLines.Add(s);
                        continue;
                    }

                    CollectTextLines(p.Value, outLines);
                }

                break;
            }
            case JsonValueKind.Array:
                foreach (var x in el.EnumerateArray())
                    CollectTextLines(x, outLines);
                break;
        }
    }

    private async Task SendTypingLoopAsync(ITurnContext turnContext, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(TimeSpan.FromSeconds(8), cancellationToken);
                await turnContext.SendActivityAsync(new Activity { Type = ActivityTypes.Typing }, cancellationToken);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to send typing activity: {Error}", ex.Message);
            }
        }
    }
}

