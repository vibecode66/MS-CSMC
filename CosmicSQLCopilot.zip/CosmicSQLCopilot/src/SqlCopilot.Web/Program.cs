// ============================================================================
// Program.cs — Application entry point and dependency injection configuration
//
// Purpose:
//   Configures and starts the ASP.NET Core web host for the SQL Copilot
//   application. Registers all services, middleware, and endpoints:
//
//   Services registered:
//     - ISqlConnectionFactory   — Azure SQL connections (MI or SQL auth)
//     - ISchemaDiscoveryService — Database schema discovery with caching
//     - ISqlGeneratorService    — NL→SQL via Azure OpenAI
//     - IQueryExecutionService  — Safe SQL execution with guardrails
//     - IChartService           — Chart image generation via QuickChart.io
//     - IAdaptiveCardService    — Adaptive Card rendering for Teams
//     - Bot Framework services  — Authentication, adapter, bot handler
//
//   Endpoints:
//     GET  /         — Health check
//     POST /api/messages — Bot Framework activity endpoint (Teams)
//     POST /api/query    — REST API for M365 Copilot plugin
//     GET  /swagger      — Swagger UI for API documentation
//
// See also:
//   - Orchestration layer: `src/SqlCopilot.Core/Services/ConversationOrchestratorService.cs`
//   - Developer map: `docs/CODE_TOUR.md`
// ============================================================================

using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Identity.Web;
using QuestPDF.Infrastructure;
using Serilog;
using Serilog.Events;
using SqlCopilot.Core.Agent;
using SqlCopilot.Core.Interfaces;
using SqlCopilot.Core.Models;
using SqlCopilot.Core.Services;
using SqlCopilot.Core.Tracing;
using SqlCopilot.Web.Bot;
using SqlCopilot.Web.Security;

var builder = WebApplication.CreateBuilder(args);

// QuestPDF community license (set once at startup)
QuestPDF.Settings.License = LicenseType.Community;

// ---- Logging configuration ----
// Portal toggles for "App Service logs" are not always available (RBAC). So we also write logs to
// a rolling file under HOME/LogFiles/Application, which you can read via Kudu even without enabling
// App Service logging in the Azure Portal.
var appHome = (Environment.GetEnvironmentVariable("HOME") ?? "").Trim();
var logRoot = appHome.Length > 0 ? appHome : Path.GetTempPath();
var logDir = Path.Combine(logRoot, "LogFiles", "Application");
Directory.CreateDirectory(logDir);
var logPath = Path.Combine(logDir, "sqlcopilot-.log"); // rolling daily

builder.Host.UseSerilog((context, services, cfg) =>
{
    var minLevel = LogEventLevel.Information;
    var envMin = (Environment.GetEnvironmentVariable("SQLCOPILOT_LOG_LEVEL") ?? "").Trim();
    if (Enum.TryParse<LogEventLevel>(envMin, ignoreCase: true, out var parsed))
        minLevel = parsed;

    var template =
        "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] " +
        "{SourceContext} " +
        "{Message:lj} {Properties:j}{NewLine}{Exception}";

    cfg.MinimumLevel.Is(minLevel)
        .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
        .MinimumLevel.Override("System", LogEventLevel.Warning)
        .Enrich.FromLogContext()
        .Enrich.WithProperty("App", "SqlCopilotWeb")
        .WriteTo.Console(outputTemplate: template)
        .WriteTo.File(
            path: logPath,
            rollingInterval: RollingInterval.Day,
            retainedFileCountLimit: 14,
            fileSizeLimitBytes: 50_000_000,
            rollOnFileSizeLimit: true,
            shared: true,
            flushToDiskInterval: TimeSpan.FromSeconds(1),
            outputTemplate: template);
});

// ---- Bind configuration sections to strongly-typed options ----
builder.Services.Configure<AzureSqlOptions>(
    builder.Configuration.GetSection(AzureSqlOptions.SectionName));
builder.Services.Configure<AzureOpenAIOptions>(
    builder.Configuration.GetSection(AzureOpenAIOptions.SectionName));
builder.Services.Configure<SqlCopilotOptions>(
    builder.Configuration.GetSection(SqlCopilotOptions.SectionName));
builder.Services.Configure<AgentOptions>(
    builder.Configuration.GetSection(AgentOptions.SectionName));
builder.Services.Configure<AgentArtifactsOptions>(
    builder.Configuration.GetSection(AgentArtifactsOptions.SectionName));
builder.Services.Configure<CasePredictionOptions>(
    builder.Configuration.GetSection(CasePredictionOptions.SectionName));
builder.Services.Configure<SlaPredictionAccessOptions>(
    builder.Configuration.GetSection(SlaPredictionAccessOptions.SectionName));
builder.Services.Configure<ConversationTraceOptions>(
    builder.Configuration.GetSection(ConversationTraceOptions.SectionName));

// ---- Entra ID (Azure AD) JWT Bearer Authentication for REST API endpoints ----
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));

builder.Services.AddAuthorizationBuilder()
    .AddPolicy("QueryApiAccess", policy =>
        policy.RequireAuthenticatedUser()
              .RequireClaim("scp", "access_as_user"))
    .AddPolicy("SlaPredictionAccess", policy =>
        policy.RequireAuthenticatedUser()
              .AddRequirements(new SlaPredictionAccessRequirement()));

builder.Services.AddSingleton<Microsoft.AspNetCore.Authorization.IAuthorizationHandler,
    SlaPredictionAccessHandler>();

// ---- Artifact Token Service (signed short-lived URLs) ----
builder.Services.AddSingleton<IArtifactTokenService, ArtifactTokenService>();

// ---- Memory Cache (for schema caching) ----
builder.Services.AddMemoryCache();

// ---- Core Services (singleton — stateless, thread-safe) ----
builder.Services.AddSingleton<ISqlConnectionFactory, SqlConnectionFactory>();
builder.Services.AddSingleton<ISchemaDiscoveryService, SchemaDiscoveryService>();
builder.Services.AddSingleton<ISqlGeneratorService, SqlGeneratorService>();
builder.Services.AddSingleton<IQueryExecutionService, QueryExecutionService>();
builder.Services.AddSingleton<ITicketActionQueryService, TicketActionQueryService>();
builder.Services.AddSingleton<IChartService, ChartService>();
builder.Services.AddSingleton<IAdaptiveCardService, AdaptiveCardService>();
builder.Services.AddSingleton<IAgentOrchestratorService, AgentOrchestratorService>();
builder.Services.AddSingleton<IJsonLlmClient, AzureOpenAiJsonClient>();
builder.Services.AddSingleton<IResultSupervisorService, ResultSupervisorService>();
builder.Services.AddSingleton<CasePredictionAgent>();
builder.Services.AddSingleton<ICaseFeatureService, CaseFeatureService>();
builder.Services.AddSingleton<IConversationOrchestratorService, ConversationOrchestratorService>();

// ---- Conversation tracing (optional) ----
// Writes per-turn NDJSON files locally and (optionally) uploads to blob storage.
builder.Services.AddSingleton<LocalNdjsonConversationTraceSink>();
builder.Services.AddSingleton<IConversationTraceSink>(sp =>
{
    var opts = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<ConversationTraceOptions>>().Value;
    var local = sp.GetRequiredService<LocalNdjsonConversationTraceSink>();
    if (!opts.Enabled) return new NoopConversationTraceSink();
    if (!opts.Blob.Enabled) return local;
    return new BlobUploadConversationTraceSink(
        sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<ConversationTraceOptions>>(),
        sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<CasePredictionOptions>>(),
        local,
        sp.GetRequiredService<ILogger<BlobUploadConversationTraceSink>>());
});

// ---- Case prediction (anonymous Azure Function) ----
builder.Services.AddHttpClient<ICasePredictionClient, CasePredictionClient>()
    .ConfigureHttpClient((sp, http) =>
    {
        var opts = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<CasePredictionOptions>>().Value;
        http.Timeout = TimeSpan.FromSeconds(Math.Clamp(opts.TimeoutSeconds, 1, 300));
    });

// ---- Bot Framework ----
// ConfigurationBotFrameworkAuthentication reads MicrosoftAppId, MicrosoftAppType, etc.
// from appsettings.json. Supports UserAssignedMSI for passwordless auth.
builder.Services.AddSingleton<BotFrameworkAuthentication, ConfigurationBotFrameworkAuthentication>();
builder.Services.AddSingleton<IBotFrameworkHttpAdapter, AdapterWithErrorHandler>();
// Bot is transient — new instance per turn for clean state
builder.Services.AddTransient<IBot, SqlCopilotBot>();

// ---- Controllers ----
builder.Services.AddControllers();

// ---- HSTS (HTTP Strict Transport Security) ----
builder.Services.AddHsts(options =>
{
    options.MaxAge = TimeSpan.FromDays(365);
    options.IncludeSubDomains = true;
    options.Preload = true;
});

// ---- Swagger / OpenAPI documentation ----
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
    {
        Title = "SQL Copilot API",
        Version = "v1",
        Description = "Natural language to SQL query API for M365 Copilot. " +
            "Accepts plain English questions and returns structured query results."
    });
});

var app = builder.Build();

// Log startup information
var logger = app.Services.GetRequiredService<ILogger<Program>>();
logger.LogInformation("SQL Copilot starting up...");
logger.LogInformation("Environment: {Environment}", app.Environment.EnvironmentName);

// ---- Middleware pipeline ----

// Security headers
app.Use(async (context, next) =>
{
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "DENY";
    context.Response.Headers["X-XSS-Protection"] = "0";
    context.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
    context.Response.Headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
    context.Response.Headers["Cache-Control"] = "no-store";
    context.Response.Headers["Pragma"] = "no-cache";
    await next();
});

app.UseHttpsRedirection();
app.UseHsts();

// Enable Swagger in non-production environments only
if (!app.Environment.IsProduction())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "SQL Copilot API v1");
        options.RoutePrefix = "swagger";
    });
}

app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

// Artifacts directory setup (served via ArtifactsController with token validation, not static files)
var artifactsDir = builder.Configuration.GetSection(AgentArtifactsOptions.SectionName).GetValue<string>("Directory");
if (string.IsNullOrWhiteSpace(artifactsDir))
{
    var home = Environment.GetEnvironmentVariable("HOME");
    artifactsDir = !string.IsNullOrWhiteSpace(home)
        ? Path.Combine(home, "data", "sqlcopilot", "artifacts")
        : Path.Combine(Path.GetTempPath(), "sqlcopilot", "artifacts");
}
Directory.CreateDirectory(artifactsDir);

app.MapControllers();

// Health check endpoint — used by Azure App Service health probes
app.MapGet("/", () => Results.Ok(new
{
    status = "healthy",
    timestamp = DateTime.UtcNow
}));

logger.LogInformation("SQL Copilot started successfully");

app.Run();
